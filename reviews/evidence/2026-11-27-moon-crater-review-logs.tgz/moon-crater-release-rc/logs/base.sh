#!/bin/bash
export NODE_PATH=/home/claude/node_modules:/home/claude/spike/node_modules
L=/tmp/crs/rc/base; mkdir -p $L; echo "start $(date -u +%T)" > $L/summary.txt
# candidate reruns, alone (server 8899 from /tmp/wt-rc)
cd /tmp/wt-rc
for s in night-lights-ui osmc-reliability-ui; do timeout 1500 node phase1/$s.test.cjs > $L/cand-$s.log 2>&1; echo "candidate $s exit $?: $(grep -iE 'passed|pass,|[0-9]+ pass|crash' $L/cand-$s.log | tail -1 | cut -c1-120) | FAIL lines $(grep -c '^FAIL' $L/cand-$s.log)" >> $L/summary.txt; done
# main 67a615c on port 8898
cd /tmp/wt-main && (python3 -m http.server 8898 --bind 127.0.0.1 >/tmp/srv-main.log 2>&1 &) ; sleep 2
for s in kept-ui ux-round1 timeline-mixed-assets osmc-reliability-ui night-lights-ui; do timeout 1500 node phase1/$s.test.cjs http://127.0.0.1:8898 > $L/main-$s.log 2>&1; echo "main $s exit $?: $(grep -iE 'passed|pass,|[0-9]+ pass|crash' $L/main-$s.log | tail -1 | cut -c1-120) | FAIL lines $(grep -c '^FAIL' $L/main-$s.log)" >> $L/summary.txt; done
pkill -f "http.server 8898"
echo "end $(date -u +%T)" >> $L/summary.txt
