#!/bin/bash
export NODE_PATH=/home/claude/node_modules:/home/claude/spike/node_modules
export LOLA_SRC="/mnt/user-data/uploads/Documents--Mother Earth/_source-data/moon-lro-science-2026-11-26"
L=/tmp/crs/rc; cd /tmp/wt-rc
S="/mnt/user-data/uploads/Documents--Mother Earth/_source-data/moon-lro-science-crater"
echo "start $(date -u +%T) tree $(git rev-parse --short HEAD)" > $L/summary.txt
python3 -I phase1/moonsci/build_crater.py --src "$S" --check > $L/build-check.log 2>&1; echo "build --check exit $?: $(tail -1 $L/build-check.log)" >> $L/summary.txt
python3 -I phase1/moonsci/crater/test_build_crater.py "$S" > $L/test_build_crater.log 2>&1; echo "test_build_crater exit $?: $(tail -1 $L/test_build_crater.log)" >> $L/summary.txt
node phase1/moonsci/served_manifest.mjs --check > $L/manifest.log 2>&1; echo "served_manifest --check exit $?: $(tail -1 $L/manifest.log)" >> $L/summary.txt
for s in moon-crater-ui animals-tab-ui moon-globe moon-lit moon-lro-path moon-diviner-ui moon-lroc-ui moon-height-ui skycraft-ui sun-globe tides-ui timeline-ui timeline-mixed-assets backdrop-layer dustrgb-ui kept-ui nature-context-ui quakes-ships-status-ui ships-retain-ui soil-ui ux-round1 fire-status-ui freshness-wording-ui night-lights-ui optional-layers-status-ui osmc-reliability-ui tides-nav; do
  timeout 1500 node phase1/$s.test.cjs > $L/$s.log 2>&1; ec=$?
  echo "$s exit $ec: $(grep -iE 'passed|pass,|[0-9]+ pass|stopped early' $L/$s.log | tail -1) | FAIL lines $(grep -c '^FAIL' $L/$s.log)" >> $L/summary.txt
done
node phase1/timeline-changes-build.test.mjs > $L/timeline-changes-build.log 2>&1; echo "timeline-changes-build exit $?: $(tail -1 $L/timeline-changes-build.log)" >> $L/summary.txt
for b in eager nopin edge late nodeadline zero shape bench rev retry extra; do
  BREAK=$b timeout 900 node phase1/moon-crater-ui.test.cjs > $L/break-crater-$b.log 2>&1
  echo "crater break $b: FAIL lines $(grep -c '^FAIL  ' $L/break-crater-$b.log), $(grep -c 'BREAK applied (pattern found)' $L/break-crater-$b.log) applied, $(grep -c 'SETUP FAIL' $L/break-crater-$b.log) setup" >> $L/summary.txt
done
for b in cr-moon-panel-edited cr-sources-edited sk-sources-edited moon-page-edited; do
  BREAK=$b timeout 1500 node phase1/animals-tab-ui.test.cjs > $L/break-animals-$b.log 2>&1
  echo "animals break $b: $(grep -E 'BREAK (CAUGHT|MISSED)' $L/break-animals-$b.log | cut -c1-160)" >> $L/summary.txt
done
echo "end $(date -u +%T)" >> $L/summary.txt
