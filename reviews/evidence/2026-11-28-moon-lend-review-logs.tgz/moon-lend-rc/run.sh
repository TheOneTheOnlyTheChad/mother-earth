#!/bin/bash
# LEND release-candidate validation runner. Every exit code is captured into rc immediately after its command
# (the preview runner read $? after a $(date) substitution on the same line, so it always logged exit=0).
W=${W:-/tmp/wt-rc}; V=${V:-/tmp/val-rc}; cd "$W" || exit 9
export NODE_PATH=/home/claude/node_modules:/home/claude/spike/node_modules
now() { TZ=UTC date +%H:%M:%S; }
log() { echo "$(now) $*" >> "$V/summary.txt"; }
step() { local name=$1; shift; "$@" > "$V/$name.log" 2>&1; local rc=$?; log "$name exit=$rc | $(grep -E 'passed|failed|OK|match|CAUGHT|MISSED' "$V/$name.log" | tail -1 | cut -c1-160)"; }
rm -f "$V/summary.txt"; log "START $(git rev-parse HEAD) server=$(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:8899/moon.html)"
step build_check python3 -I phase1/moonsci/build_lend.py --src /home/claude/lenddata --check
step test_build_lend python3 -I phase1/moonsci/lend/test_build_lend.py /home/claude/lenddata
step break_build_lend python3 -I phase1/moonsci/lend/break_build_lend.py /home/claude/lenddata
step manifest node phase1/moonsci/served_manifest.mjs --check
step moon-lend-ui node phase1/moon-lend-ui.test.cjs
brk() { local b=$1; BREAK=$b node phase1/moon-lend-ui.test.cjs > "$V/brk-$b.log" 2>&1; local rc=$?
  echo "$(TZ=UTC date +%H:%M:%S) BREAK $b exit=$rc applied=$(grep -c 'BREAK applied (pattern found)' "$V/brk-$b.log") fails=$(grep -c '^FAIL ' "$V/brk-$b.log")" >> "$V/summary.txt"; }
export -f brk; export V
printf "%s\n" row col flip outside nocell nopayload nopin missval late leak nosave norestore noleavecancel deadline noerrtext nocaveat nofinite | xargs -P 3 -I{} bash -c 'brk {}'
step animals-tab-ui node phase1/animals-tab-ui.test.cjs
for b in le-moon-legend-edited le-moon-key-old le-sources-edited le-sources-shortcut-moved cr-moon-panel-edited cr-sources-edited sk-sources-edited moon-page-edited mh-sources-shortcut-gone; do BREAK=$b step animals-brk-$b node phase1/animals-tab-ui.test.cjs; done
for s in moon-globe moon-lit moon-lro-path moon-diviner-ui moon-lroc-ui moon-crater-ui skycraft-ui sky-moon-texture-ui sun-globe; do step $s node phase1/$s.test.cjs; done
step moon-light node phase1/moon-light.test.mjs
LOLA_SRC=/home/claude/lolasrc step moon-height-ui node phase1/moon-height-ui.test.cjs
for s in timeline-ui tides-nav backdrop-layer dustrgb-ui nature-context-ui quakes-ships-status-ui ships-retain-ui soil-ui fire-status-ui freshness-wording-ui optional-layers-status-ui night-lights-ui timeline-mixed-assets kept-ui ux-round1 osmc-reliability-ui tides-ui smoke-fixes; do step $s node phase1/$s.test.cjs; done
step timeline-changes-build node phase1/timeline-changes-build.test.mjs
log ALLDONE
