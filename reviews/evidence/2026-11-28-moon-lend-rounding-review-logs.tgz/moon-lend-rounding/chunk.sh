#!/bin/bash
# runs the named suites with the same step() as run.sh (exit code captured immediately)
W=/tmp/wt-rd; V=/tmp/val-rd; cd "$W" || exit 9
export NODE_PATH=/home/claude/node_modules:/home/claude/spike/node_modules
now() { TZ=UTC date +%H:%M:%S; }
log() { echo "$(now) $*" >> "$V/summary.txt"; }
step() { local name=$1; shift; "$@" > "$V/$name.log" 2>&1; local rc=$?; log "$name exit=$rc | $(grep -E 'passed|failed|pass,|OK|match|CAUGHT|MISSED' "$V/$name.log" | tail -1 | cut -c1-160)"; }
for s in "$@"; do if [ "$s" = timeline-changes-build ]; then step $s node phase1/$s.test.mjs; else step $s node phase1/$s.test.cjs; fi; done
