/* Mother Earth — the Animals tab: its own globe, one journey at a time (animals-tab-rc, stage 1, 20 Nov 2026;
 * docs/concepts/ANIMALS-BIRD-BUILD-PROPOSAL.md rev 3.1, Part A: criteria T1–T18 with the §A7 clarifications).
 * The REAL page files in Chromium, served by this suite's own server, with the committed journey list, manifests and display
 * files (assets/animals/). Expected values (which fix is last at a time, how many joins) are worked out here from the files,
 * separately from the page's code. This suite replaces phase1/animals-journey-ui.test.cjs, which tested the replay on Earth now.
 * What it does NOT prove: performance; a real phone; a screen reader (roles, names, states and focus are read from the page, not
 * heard); real NASA imagery (a small stand-in picture is served); a real lost graphics context on real hardware (the browser's
 * own lose-context extension is used); the full-source build checks (the source files are not in the repository).
 * The line-rule and bad-content fixtures are served with their own journey-list checksum pinned in place of the real one: a
 * harness substitution, stated here.
 * Sections 16 and 17 and checks 12h to 12m were added after GPT's Stage 1 review (phone reveal; the list Retry's lifecycle; the
 * sampled bar-text sweep carried over from the old suite).
 * Sections 18 and 19 are stage 2: the waved albatross (withheld fixes, the recording-period replay, the tag's accuracy estimate).
 * Breaks: BREAK=<name> edits one served file; the suite must then FAIL at the check named in EXPECT ("BREAK CAUGHT"), or it
 * prints BREAK MISSED. SECTIONS=1,4 runs parts.
 * Needs the npm packages playwright (with its Chromium), pngjs and globe.gl@2.45.0, found through NODE_PATH (or ME_GLOBE_JS for
 * the library file). Section 13 compares with main: from Git when the tree is a clone, or from BASE_DIR=<folder holding main's
 * files at BASE_MAIN>; with neither, its file comparisons are reported NOT RUN and the suite exits non-zero. The Timeline's files are
 * compared with main at TL_MAIN the same way (Git, or TL_DIR=<folder holding main's files at TL_MAIN>). The Nature context page files
 * are compared with NC_MAIN (Git, or NC_DIR=<folder holding the files at NC_MAIN>); its scope check 13j needs Git and fails closed without it.
 * Run: NODE_PATH=<node_modules with playwright, pngjs, globe.gl> node --no-warnings phase1/animals-tab-ui.test.cjs */
const { chromium } = require('playwright');
const fs = require('fs'), path = require('path'), http = require('http'), crypto = require('crypto'), cp = require('child_process');
const { PNG } = require('pngjs');
const ROOT = path.join(__dirname, '..'), HUB = 'mother-earth.chadoberholzer.workers.dev';
// the globe library is served from a local copy in place of unpkg: ME_GLOBE_JS=<path to globe.gl.min.js>, or the globe.gl package
// found through NODE_PATH. It must be the version the page pins (2.45.0); check 1k reads the version from the file's own banner.
const GLOBE_PATH = process.env.ME_GLOBE_JS || (process.env.NODE_PATH || '').split(path.delimiter).filter(Boolean).map(d => path.join(d, 'globe.gl', 'dist', 'globe.gl.min.js')).find(f => fs.existsSync(f));
if (!GLOBE_PATH) { console.log('FAIL  globe.gl@2.45.0 not found: set ME_GLOBE_JS or put the package on NODE_PATH'); process.exit(1); }
const GLOBE_JS = fs.readFileSync(GLOBE_PATH, 'utf8'), GLOBE_VER = (/Version (\d+\.\d+\.\d+) globe\.gl/.exec(GLOBE_JS.slice(0, 400)) || [])[1] || (() => { try { return require(path.join(path.dirname(GLOBE_PATH), '..', 'package.json')).version; } catch (_) { return null; } })();
const BASE_MAIN = process.env.BASE_MAIN || '0e620831b83b2ae7eed11a932edfd902d933f195';   // the exact main commit merged into this branch (T13 baseline)
// The Timeline's own files (timeline.js, timeline.html, the stylesheet's body.tl rules) are released by the Timeline thread and have
// moved on since BASE_MAIN. They are held to the main commit of the Timeline's latest release instead (checks 13f to 13i). Every
// other file stays on BASE_MAIN. A Timeline release moves TL_MAIN, and nothing else, in the commit that records the release.
const TL_MAIN = process.env.TL_MAIN || '643bb9a7e9c63045dec3eac87837212f05841a3f';   // Timeline R4 (Humans and human relatives), page commit H (24 Nov 2026); before it fbad1b6 (date label W1), 19f4e07 (merge of tl-2026-11-R3)
// Nature context (24 Nov 2026, the Animals owner's maintenance at the Nature context thread's request, docs/concepts/NATURE-CONTEXT-ANIMALS-PIN-REQUEST.md):
// its reviewed page commit changes app.js, index.html and sources.html. Those three are held to that commit, NC_MAIN, by 13b, 13e
// (sources.html) and 13k; the Animals guarantees on index.html and sources.html are checked on their own, not inherited from the pin;
// 13j checks that NC_MAIN changed no other production file since NC_PARENT. Only a Nature context release moves NC_MAIN (and
// NC_PARENT with it), in the commit that records the release. Every other file stays on BASE_MAIN or TL_MAIN.
const NC_MAIN = process.env.NC_MAIN || '90eb52203c23b26a7fe00382f30cf3453b00a583';     // Nature context page commit H, passed by GPT's recheck (24 Nov 2026)
const NC_PARENT = process.env.NC_PARENT || '6bebff18ffb0886719a3587a9199d9c158b39f50';   // the main commit H's work started from
// Organic-soil emissions (25 Nov 2026, Nature context thread; GPT's preview round-2 recheck, release-scope requirements 1–4):
// its reviewed payload commit SOIL_MAIN changes index.html, sources.html, layers.js, style.css and the Bare Earth suite, and adds soil.js
// and its table. index.html and sources.html (13b, 13e), layers.js and the Bare Earth suite (13c) are held to SOIL_MAIN; app.js stays
// on NC_MAIN (13k: soil does not touch it); 13j and its anchors are the 24 Nov guarantee and do not move. 13m checks that SOIL_MAIN
// changed exactly the literal file list since SOIL_PARENT (fresh main), and 13n that the maintenance commit after it changed only this
// suite. BASE_MAIN and TL_MAIN do not move. Only an organic-soil release moves SOIL_MAIN (and SOIL_PARENT with it).
const SOIL_MAIN = process.env.SOIL_MAIN || '86071bfc4d019cd400019e98eed3ab49c1cf6415';     // soil-release-rc payload: full table, fixture retired
const SOIL_PARENT = process.env.SOIL_PARENT || 'af89de247471c768f047e40fb4a749e0e69f1d7d';   // fresh main the release branched from
const SOIL_FILES = ['REGISTER.md', 'assets/soil/g4-soil-v1.0.1.json', 'docs/research/soil-c1/soil_controls.py', 'docs/research/soil-c1/soil_reference.py', 'index.html', 'layers.js',
  'phase1/bare-earth-ui.test.cjs', 'phase1/soil-ui.test.cjs', 'soil.js', 'sources.html', 'style.css'];   // literal: the exact changed-path set of SOIL_PARENT..SOIL_MAIN
const SOIL_TABLE_SHA = 'c5c01ff5a4300ace1e7348d6d25edb079ea424810e70d50a291afd0ffadb30cf';
// Tides navigation (25 Nov 2026, Tides thread; the Animals owner's narrow pin maintenance, as for the organic-soil release): its payload
// commit TIDES_MAIN adds the Tides page and puts a Tides tab (after Sun) and a Tides Menu item into every page's header, adds the six-tab
// header rules to style.css, wraps World View's promise text in a <span> and gives the six changed pages one new stylesheet key
// (payload 2), and adds the Sources Tides section, the REGISTER entry and the served-file manifest (payload 3, the release candidate).
// The range from fresh main ea8cffc then also holds this suite's earlier Tides maintenance (7dfae21, b01d394) and the Timeline guard's set-aside. index.html and sources.html (13b, 13e) are held to
// TIDES_MAIN; the step from SOIL_MAIN to TIDES_MAIN is checked to be exactly the Tides links (and, for index.html, the promise wrapper),
// so the organic-soil guarantee is kept. moon.html and sun.html (13e) and timeline.html (13h) are compared with their old baselines with
// the two Tides lines set aside, exactly as the Animals lines are. 13o checks that TIDES_MAIN changed exactly the literal TIDES_FILES since
// TIDES_PARENT (fresh main), and 13p that the maintenance after it changed only this suite. BASE_MAIN, TL_MAIN, NC_MAIN and SOIL_MAIN
// do not move. Only a Tides release moves TIDES_MAIN (and TIDES_PARENT with it).
const TIDES_MAIN = process.env.TIDES_MAIN || '54cbc0ddd20ea370f6a963bfc289ab38f3597c3c';     // tides-nav-rc payload 3, the release candidate (adds the Sources Tides section and the REGISTER entry); payloads 1 and 2 were 1784a71 and 8475452
const TIDES_PARENT = process.env.TIDES_PARENT || 'ea8cffc96c318920f7671d53fa6b201ac69c8778';   // fresh main merged into the branch before payload 3 (was a84a642)
const TIDES_FILES = ['REGISTER.md', 'animals.html', 'assets/tides/SOURCE.json', 'assets/tides/earth-2026-06-22.jpg', 'assets/tides/sun-2026-11-25.jpg', 'index.html', 'moon.html',
  'phase1/animals-tab-ui.test.cjs', 'phase1/desktop-overflow.test.cjs', 'phase1/tides-load-compare.cjs', 'phase1/tides-model.test.mjs', 'phase1/tides-nav.test.cjs', 'phase1/tides-ui.test.cjs',
  'phase1/tides/build_sun_reference.cjs', 'phase1/tides/build_tides.mjs', 'phase1/tides/check_sun_reference.py', 'phase1/tides/release_manifest.mjs', 'phase1/tides/source/sdo-hmiic-20261125T140006Z.jpg',
  'phase1/timeline-mixed-assets.test.cjs', 'phase1/timeline-ui.test.cjs', 'reviews/evidence/2026-11-25-tides-release-manifest.json', 'sources.html', 'style.css', 'sun.html', 'tides-model.js', 'tides.css',
  'tides.html', 'tides.js', 'timeline.html'];   // literal: the exact changed-path set of TIDES_PARENT..TIDES_MAIN
const TIDES_TAB = '    <a href="tides.html" data-view="tides">Tides</a>\n', TIDES_MENU = '      <li role="none"><a role="menuitem" href="tides.html" data-page="tides">Tides</a></li>\n';
const noTides = t => t.replace(TIDES_TAB, '').replace(TIDES_MENU, '');
const noKey = t => t.replace(/style\.css\?v=\d+/, 'style.css?v=X');   // the step from SOIL_MAIN also moves the stylesheet key (payload 2)
// payload 3 (release candidate): sources.html gains exactly one Tides section, placed just before the Animals section, and one shortcut before Animals'
const TIDES_SHORTCUT = ' · <a href="#tides">Tides</a>', TIDES_SEC = /  <h2 id="tides">[\s\S]*?(?=  <h2 id="animals">)/;
// Moon height (26 Nov 2026, Moon/LRO science thread; the Animals owner's narrow pin maintenance, as for Tides): its payload commit MH_MAIN
// adds an optional height layer to moon.html (one stylesheet link, two buttons, a legend block and readout, one scale line, one Sources
// line, one script tag, and a new moonglobe.js version key) and a small hook to moonglobe.js. moon.html (13e) is held to MH_MAIN and, with
// exactly those additions set aside, still to its old baseline; moonglobe.js left the 13c list and is held to MH_MAIN by 13q. 13r checks
// that MH_MAIN changed exactly the literal MH_FILES since MH_PARENT (fresh main), and 13s that the maintenance after it changed only this
// suite. BASE_MAIN, TL_MAIN, NC_MAIN, SOIL_MAIN and TIDES_MAIN do not move. Only a Moon height release moves MH_MAIN (and MH_PARENT with it).
// The range MH_PARENT..MH_MAIN also holds the preview's own records and this suite's preview pin maintenance (5e835de), listed literally.
const MH_MAIN = process.env.MH_MAIN || '83f7c32206eb3cf8916d4a76900958ac3724e70c';     // moon-height-rc release payload (26 Nov 2026); the preview payload was f884b7c
const MH_PARENT = process.env.MH_PARENT || '97815ddb3ab52a6d9be387cc0d24506172b98293';   // fresh main the branch started from
const MH_FILES = ['HANDOVER.md', 'REGISTER.md', 'STATUS.md', 'assets/moon/lola/SOURCE.json', 'assets/moon/lola/ldem4-colour-R1.png', 'assets/moon/lola/ldem4-m-R1.i16.gz', 'moon.html',
  'moonglobe.js', 'moonsci.css', 'moonsci.js', 'phase1/animals-tab-ui.test.cjs', 'phase1/moon-height-ui.test.cjs', 'phase1/moonsci/build_lola.py', 'phase1/moonsci/served_manifest.mjs',
  'reviews/2026-11-26-moon-height-rc-gpt-review.md', 'reviews/2026-11-26-moon-height-rc.md', 'reviews/evidence/2026-11-26-moon-height-manifest.json', 'sources.html'];   // literal: the exact changed-path set of MH_PARENT..MH_MAIN
const MH_ADD = [/\n<link rel="stylesheet" href="moonsci\.css\?v=\d+">/, /      <button type="button" id="mg-height" aria-pressed="false">Show height \(LOLA\)<\/button>\n      <button type="button" id="mg-height-centre" hidden>Read height at centre<\/button>\n/,
  /    <div id="mg-height-leg" class="mgh" hidden>\n[\s\S]*?\n    <\/div>\n    <p id="mg-height-read" class="mglro" aria-live="polite" hidden><\/p>\n/, /    <span>“Show height \(LOLA\)” [^\n]*<\/span>\n/,
  /      <li><b>Height \(optional\):<\/b>[^\n]*<\/li>\n/, /\n<script src="moonsci\.js\?v=\d+"><\/script>/];
// Release candidate (26 Nov 2026): MH_MAIN moves to the release payload, which also adds one Moon height section to sources.html (just
// before the Sun globe section) and one shortcut (just before Tides'). 13e sources.html holds the file to MH_MAIN and, with exactly
// those two additions set aside, to everything it held before (TIDES_MAIN and the chain behind it).
const MH_SRC_SHORTCUT = ' · <a href="#moonheight">Moon height</a>', MH_SRC_SEC = /  <h2 id="moonheight">[\s\S]*?\n\n(?=  <h2 id="sunglobe">)/;
const heightSourcesOk = t => t.split(MH_SRC_SHORTCUT).length === 2 && t.includes(MH_SRC_SHORTCUT + ' · <a href="#tides">Tides</a>') && (t.match(/<h2 id="moonheight">/g) || []).length === 1 && MH_SRC_SEC.test(t)
  && /Values north of 89\.5°N are withheld because inconsistencies were found in the source products[.:]/.test(t) && /doi:10\.17189\/tnyt-7007/.test(t);
const noHeightSources = t => t.replace(MH_SRC_SHORTCUT, '').replace(MH_SRC_SEC, '');
const heightOk = t => MH_ADD.every(re => (t.match(new RegExp(re.source, 'g')) || []).length === 1) && /moonglobe\.js\?v=202612260500/.test(t);
const noHeight = t => MH_ADD.reduce((a, re) => a.replace(re, ''), t).replace('moonglobe.js?v=202612260500', 'moonglobe.js?v=202612071200');
// Moon temperature (26 Nov 2026, Moon/LRO science thread, Diviner preview; narrow pin maintenance as for Moon height): its payload commit DV_MAIN
// adds an optional temperature layer to moon.html (two buttons and a two-option group after the height buttons, a legend block and readout
// after the height readout, one scale line, one Sources line, and new moonsci.css / moonsci.js version keys). moon.html (13e) is held to
// DV_MAIN and, with exactly those additions set aside and the two keys and one reworded zoom sentence put back, to the Moon height baseline MH_MAIN (and through it to
// everything before). 13t checks that DV_MAIN changed exactly the literal DV_FILES since DV_PARENT (fresh main), and 13u that the
// maintenance after it changed only this suite. MH_MAIN and the baselines behind it do not move. Only a Moon temperature release moves DV_MAIN.
const DV_MAIN = process.env.DV_MAIN || 'cc754072c03c321abfb88b159ceca038756861f5';     // moon-diviner-ui release candidate payload (26 Nov 2026; preview payloads 947dd14, 7a3aeb0, 1a842f9)
const DV_PARENT = process.env.DV_PARENT || '5efe200ad7118362e17c56acb95604342ee60135';   // fresh main merged into the branch for the release candidate (5efe200)
const DV_FILES = ['REGISTER.md', 'assets/moon/diviner/SOURCE.json', 'assets/moon/diviner/gcp-tbol-nm-R1.bin.gz', 'docs/research/moon-lro-science/SAMPLES.md', 'docs/research/moon-lro-science/diviner-acq/EXTRACTION-SCHEMA.md', 'docs/research/moon-lro-science/diviner-acq/TOOLING.md', 'docs/research/moon-lro-science/diviner-acq/checkpoints.jsonl', 'docs/research/moon-lro-science/diviner-acq/global_report_output-2026-11-26.txt', 'docs/research/moon-lro-science/diviner-acq/trial_compare_output-00n10n.txt', 'docs/research/moon-lro-science/diviner-ghrm/ghrm_compare_output-2026-11-26.txt', 'docs/research/moon-lro-science/diviner-ghrm/sites.json', 'moon.html', 'moonsci.css', 'moonsci.js', 'phase1/animals-tab-ui.test.cjs', 'phase1/moon-diviner-ui.test.cjs', 'phase1/moon-height-ui.test.cjs', 'phase1/moonsci/build_diviner.py', 'phase1/moonsci/diviner/diviner_ref.py', 'phase1/moonsci/diviner/gcp_stream.js', 'phase1/moonsci/diviner/ghrm_compare.py', 'phase1/moonsci/diviner/global_report.py', 'phase1/moonsci/diviner/mehash.js', 'phase1/moonsci/diviner/pane_job.js', 'phase1/moonsci/diviner/test_gcp_stream.cjs', 'phase1/moonsci/diviner/test_mehash.cjs', 'phase1/moonsci/diviner/test_pane_job.cjs', 'phase1/moonsci/diviner/trial_compare.py', 'phase1/moonsci/served_manifest.mjs', 'reviews/2026-11-26-moon-diviner-first-band-trial.md', 'reviews/2026-11-26-moon-diviner-global-report.md', 'reviews/2026-11-26-moon-diviner-ui-rc-rev2.md', 'reviews/2026-11-26-moon-diviner-ui-rc.md', 'reviews/2026-11-26-moon-diviner-ui-rev2-gpt-recheck.md', 'reviews/evidence/2026-11-26-moon-diviner-manifest.json', 'sources.html'];   // literal: the exact changed-path set of DV_PARENT..DV_MAIN
const DV_ADD = [/      <button type="button" id="mg-temp" aria-pressed="false">Show temperature \(Diviner\)<\/button>\n      <button type="button" id="mg-temp-centre" hidden>Read temperature at centre<\/button>\n      <fieldset id="mg-temp-mode"[\s\S]*?<\/fieldset>\n/,
  /    <div id="mg-temp-leg" class="mgh mgt" hidden>\n[\s\S]*?\n    <\/div>\n    <p id="mg-temp-read" class="mglro" aria-live="polite" hidden><\/p>\n/, /    <span>“Show temperature \(Diviner\)” [^\n]*<\/span>\n/,
  /      <li><b>Temperature \(optional\):<\/b>[^\n]*<\/li>\n/];
const DV_KEYS = [['moonsci.css?v=202612261100', 'moonsci.css?v=202612260500'], ['moonsci.js?v=202612261400', 'moonsci.js?v=202612260500'],
  // rev 2 (GPT's preview review): the existing zoom sentence now names the appearance picture and adds the temperature cell size
  ['The appearance picture holds about 5 km to a pixel at the equator, so it blurs up close. The temperature map’s cells are 0.5° (about 15 km north–south and at the equator, narrower east–west towards the poles).</span>', 'The map holds about 5 km to a pixel at the equator, so it blurs up close.</span>']];
// Release candidate (26 Nov 2026): DV_MAIN also adds one Moon temperature section to sources.html (after Moon height, before the Sun globe)
// and one shortcut (between Moon height's and Tides'). 13e sources.html holds the file to DV_MAIN and, with exactly those two additions set
// aside, to the Moon height baseline MH_MAIN (and through it to everything before).
const DV_SRC_SHORTCUT = ' · <a href="#moontemp">Moon temperature</a>', DV_SRC_SEC = /  <h2 id="moontemp">[\s\S]*?\n\n(?=  <h2 id="sunglobe">)/;
const tempSourcesOk = t => t.split(DV_SRC_SHORTCUT).length === 2 && t.includes(' · <a href="#moonheight">Moon height</a>' + DV_SRC_SHORTCUT + ' · <a href="#tides">Tides</a>') && (t.match(/<h2 id="moontemp">/g) || []).length === 1 && DV_SRC_SEC.test(t)
  && /our display policy<\/b>, not the edge of Diviner’s coverage/.test(t) && /causes of the differences have not been isolated/.test(t) && /doi:10\.17189\/wj0s-w188/.test(t);
const noTempSources = t => t.replace(DV_SRC_SHORTCUT, '').replace(DV_SRC_SEC, '');
const tempOk = t => DV_ADD.every(re => (t.match(new RegExp(re.source, 'g')) || []).length === 1) && DV_KEYS.every(([k]) => t.split(k).length === 2);
const noTemp = t => DV_KEYS.reduce((a, [k, o]) => a.replace(k, o), DV_ADD.reduce((a, re) => a.replace(re, ''), t));
// Moon LROC regional detail (26 Nov 2026, Moon/LRO science thread, item 4; narrow pin maintenance as for Moon temperature): its payload
// commit LR_MAIN adds to moon.html exactly one stylesheet link (moonlroc.css), one control row holding the detail toggle after the LRO
// readout (outside #mg-ctl since the release candidate, so it stays usable when the globe fails), one locator line and one panel after it,
// one scale line, one 'Detailed site (optional)' line in Sources and method, and one script tag (moonlroc.js); moonglobe.js, moonsci.js
// and style.css are untouched. moon.html (13e) is held to LR_MAIN and, with exactly those six additions set aside, to the Moon temperature
// baseline DV_MAIN (and through it to everything before). Release candidate: sources.html (13e) is held to LR_MAIN and, with its one
// Moon detailed-site section and shortcut set aside and the two lighting sentences put back (GPT's carried wording note), to DV_MAIN.
// 13v checks that LR_MAIN changed exactly the literal LR_FILES since LR_PARENT (fresh main), and 13w that the maintenance after it changed
// only this suite. DV_MAIN and the baselines behind it do not move.
const LR_MAIN = process.env.LR_MAIN || '998df30';       // moon-lroc-ui release candidate payload (26 Nov 2026; preview payload c99da22)
const LR_PARENT = process.env.LR_PARENT || 'd73a639';   // fresh main merged into the branch for the release candidate
const LR_FILES = ['REGISTER.md', 'assets/moon/lroc/SOURCE.json', 'assets/moon/lroc/a11-area-4m-mask.png', 'assets/moon/lroc/a11-area-4m.jpg', 'assets/moon/lroc/a11-site-0p5m.jpg',
  'moon.html', 'moonlroc.css', 'moonlroc.js', 'phase1/animals-tab-ui.test.cjs', 'phase1/moon-diviner-ui.test.cjs', 'phase1/moon-lroc-ui.test.cjs', 'phase1/moonsci/build_lroc.py', 'phase1/moonsci/served_manifest.mjs',
  'reviews/2026-11-26-moon-lroc-ui-rc.md', 'reviews/evidence/2026-11-26-moon-lroc-manifest.json', 'sources.html'];   // literal: the exact changed-path set of LR_PARENT..LR_MAIN
// Sky zoom-out Moon picture (27 Nov 2026, Moon item 10a; narrow pin maintenance as for Moon LROC): its payload commit SK_MAIN changes
// index.html (one moonlight.js script tag before skyscene.js, a new skyscene.js version key, and one #zoom-moonmap paragraph in "How this
// is drawn"), skyscene.js (the Moon's picture) and sources.html (one "The Moon's picture." paragraph in the Sky zoom-out section, and two
// sentences at the end of its Data path paragraph). moonlight.js is unchanged and stays in 13c. index.html (13b) is held to SK_MAIN and,
// with exactly those additions set aside and the old key put back, to the Tides baseline TIDES_MAIN as before; skyscene.js left the 13c
// list and is held to SK_MAIN by 13x; sources.html (13e) is held to SK_MAIN and, with its two additions set aside, to everything it held
// before (LR_MAIN and the chain behind it). 13y checks that SK_MAIN changed exactly the literal SK_FILES since SK_PARENT (fresh main), and
// 13z that the maintenance after it changed only this suite. LR_MAIN and the baselines behind it do not move.
const SK_MAIN = process.env.SK_MAIN || 'bc0afd06a48e209bd5abdacbed26226832033d4a';     // moon-sky-texture-ui release candidate payload (27 Nov 2026; preview payloads a391ed8, 6ba15ac)
const SK_PARENT = process.env.SK_PARENT || '018102cf03858502cf428b33b46670496fea60f6';   // fresh main the branch (and its docs branch) started from
const SK_FILES = ['HANDOVER.md', 'REGISTER.md', 'STATUS.md', 'docs/concepts/MOON-LRO-SCIENCE-CHECKLIST.md', 'docs/concepts/MOON-SKY-TEXTURE-PROPOSAL.md', 'docs/research/moon-sky-texture/orient-breaks.txt', 'docs/research/moon-sky-texture/shot-1280.json', 'docs/research/moon-sky-texture/shot-390.json', 'docs/research/moon-sky-texture/sky-moon-illustrate.py', 'docs/research/moon-sky-texture/sky-moon-orient.json', 'docs/research/moon-sky-texture/sky-moon-orient.mjs', 'docs/research/moon-sky-texture/sky-moon-size.cjs', 'docs/research/moon-sky-texture/sky-moon-size.json', 'index.html', 'phase1/moonsci/served_manifest.mjs', 'phase1/sky-moon-texture-ui.test.cjs', 'reviews/2026-11-27-moon-sky-texture-proposal-rev1-gpt-review.md', 'reviews/2026-11-27-moon-sky-texture-ui-gpt-review.md', 'reviews/2026-11-27-moon-sky-texture-ui-r1-gpt-recheck.md', 'reviews/2026-11-27-moon-sky-texture-ui-rc.md', 'reviews/evidence/2026-11-27-moon-sky-texture-manifest.json', 'skyscene.js', 'sources.html'];   // literal: the exact changed-path set of SK_PARENT..SK_MAIN
// Moon CRaTER event counts (27 Nov 2026, Moon item 5; narrow pin maintenance as for the Sky zoom-out Moon picture): its payload commit
// CR_MAIN adds to moon.html exactly one stylesheet link (mooncrater.css), one control row and one chart panel after the drawing's readout,
// one 'CRaTER event counts (optional)' line in Sources and method, and one script tag (mooncrater.js); craft.js, moonglobe.js, moonsci.js,
// moonlroc.js and style.css are untouched; the payload also carries a narrow maintenance of moon-diviner-ui H (the Sources shortcut order). moon.html (13e) is held to CR_MAIN and, with exactly those four additions set aside, to the Moon
// LROC baseline LR_MAIN (and through it to everything before). sources.html (13e) is held to CR_MAIN and, with its one Moon event-count
// section (before the Sun globe section) and its shortcut (after Moon detailed site's) set aside, to SK_MAIN and the chain behind it.
// 13aa checks that CR_MAIN changed exactly the literal CR_FILES since CR_PARENT (fresh main), and 13ab that the maintenance after it changed
// only this suite. SK_MAIN, LR_MAIN and the baselines behind them do not move.
const CR_MAIN = process.env.CR_MAIN || '4927a028a7554f4bc3239c387f0850fb7293ff95';     // moon-crater-ui release candidate payload (27 Nov 2026; preview payload d6f9a0f)
const CR_PARENT = process.env.CR_PARENT || '67a615c1c76b9a09e9154a643790910edcd9b6d2';   // fresh main merged into the branch for the release candidate
const CR_FILES = ['REGISTER.md', 'assets/moon/crater/crater-good-2026-06-10-R1.json', 'moon.html', 'mooncrater.css', 'mooncrater.js', 'phase1/moon-crater-ui.test.cjs', 'phase1/moon-diviner-ui.test.cjs', 'phase1/moonsci/build_crater.py', 'phase1/moonsci/crater/test_build_crater.py', 'phase1/moonsci/served_manifest.mjs', 'reviews/2026-11-27-moon-crater-proposal-rev2-gpt-recheck.md', 'reviews/2026-11-27-moon-crater-ui-gpt-review.md', 'reviews/2026-11-27-moon-crater-ui-rc.md', 'reviews/evidence/2026-11-27-moon-crater-manifest.json', 'sources.html'];   // literal: the exact changed-path set of CR_PARENT..CR_MAIN
const CR_ADD = [/\n<link rel="stylesheet" href="mooncrater\.css\?v=202612271200">/, /\n    <div class="crx-ctl">[\s\S]*?\n    <\/section>/,
  /\n      <li><b>CRaTER event counts \(optional\):<\/b>[^\n]*<\/li>/, /\n<script src="mooncrater\.js\?v=202612271200"><\/script>/];
const craterOk = t => CR_ADD.every(re => (t.match(new RegExp(re.source, 'g')) || []).length === 1);
const noCrater = t => CR_ADD.reduce((a, re) => a.replace(re, ''), t);
const CR_SRC_SHORTCUT = ' · <a href="#mooncrater">Moon event counts</a>', CR_SRC_SEC = /  <h2 id="mooncrater">[\s\S]*?\n\n(?=  <h2 id="sunglobe">)/;
const craterSourcesOk = t => t.split(CR_SRC_SHORTCUT).length === 2 && t.includes(' · <a href="#moonlroc">Moon detailed site</a>' + CR_SRC_SHORTCUT + ' · <a href="#tides">Tides</a>') && (t.match(/<h2 id="mooncrater">/g) || []).length === 1 && CR_SRC_SEC.test(t)
  && ['approximate one-standard-deviation Poisson counting benchmark', 'not a 95% interval', 'not a radiation dose, not a particle flux, and not conditions at any place on the Moon’s surface', '10.17189/2c1t-ph72', 'nothing on the chart is shifted by it'].every(x => (t.match(CR_SRC_SEC) || [''])[0].includes(x));
const noCrSrc = t => t.replace(CR_SRC_SHORTCUT, '').replace(CR_SRC_SEC, '');
// Moon south-polar neutron record (27 Nov 2026, Moon item 6; narrow pin maintenance as for CRaTER): its payload commit LE_MAIN changes
// moon.html by exactly the moonsci.css key (202612261100 -> 202612271700), three buttons in the globe controls, one legend block with its
// readout, one help-line span, one 'South-polar neutron record (optional)' line in Sources and method, and the moonsci.js key
// (202612261400 -> 202612272000); craft.js, moonglobe.js, moonlroc.js, mooncrater.js and style.css are untouched; the payload also carries a
// narrow maintenance of moon-diviner-ui H (the Sources shortcut order). moon.html (13e) is held to LE_MAIN and, with exactly those additions
// set aside and the two old keys put back, to CR_MAIN (and through it to everything before). sources.html (13e) is held to LE_MAIN and,
// with its one Moon neutron record section (after Moon event counts', before the Sun globe section) and its shortcut (after Moon event
// counts') set aside, to CR_MAIN and the chain behind it. 13ac checks that LE_MAIN changed exactly the literal LE_FILES since LE_PARENT
// (main), and 13ad that the maintenance after it changed only this suite. CR_MAIN, SK_MAIN, LR_MAIN and the baselines behind them do not move.
const LE_MAIN = process.env.LE_MAIN || '0db9f9ff56a8bb010cbab0154e689ad4e0657b22';     // moon-lend-ui release candidate payload (27 Nov 2026; preview payload cd3a9b6)
const LE_PARENT = process.env.LE_PARENT || 'b67358d53288864bae8cc254d238e78edc83660f';   // main merged into the branch for the release candidate
const LE_FILES = ['REGISTER.md', 'assets/moon/lend/lend-alds-2011-2016-R1.bin', 'moon.html', 'moonsci.css', 'moonsci.js', 'phase1/moon-diviner-ui.test.cjs', 'phase1/moon-lend-ui.test.cjs', 'phase1/moonsci/build_lend.py', 'phase1/moonsci/lend/break_build_lend.py', 'phase1/moonsci/lend/test_build_lend.py', 'phase1/moonsci/served_manifest.mjs', 'reviews/2026-11-27-moon-lend-proposal-rev2-gpt-recheck.md', 'reviews/2026-11-27-moon-lend-ui-gpt-review.md', 'reviews/2026-11-27-moon-lend-ui-rc.md', 'reviews/evidence/2026-11-27-moon-lend-manifest.json', 'sources.html'];   // literal: the exact changed-path set of LE_PARENT..LE_MAIN
const LE_KEYS = [['moonsci.css?v=202612271700', 'moonsci.css?v=202612261100'], ['moonsci.js?v=202612272000', 'moonsci.js?v=202612261400']];
const LE_ADD = [/\n      <button type="button" id="mg-lend" aria-pressed="false">[^\n]*<\/button>\n      <button type="button" id="mg-lend-pole" hidden>[^\n]*<\/button>\n      <button type="button" id="mg-lend-centre" hidden>[^\n]*<\/button>/,
  /\n    <div id="mg-lend-leg" class="mgh mgn" hidden>[\s\S]*?\n    <\/div>\n    <p id="mg-lend-read" class="mglro" aria-live="polite" hidden><\/p>/,
  /\n    <span>“Show south-polar neutron record \(LEND\)”[^\n]*<\/span>/, /\n      <li><b>South-polar neutron record \(optional\):<\/b>[^\n]*<\/li>/];
const lendOk = t => LE_ADD.every(re => (t.match(new RegExp(re.source, 'g')) || []).length === 1) && LE_KEYS.every(([k]) => t.split(k).length === 2)
  && t.includes('<a href="sources.html#moonlend">Details</a>');
const noLend = t => LE_KEYS.reduce((a, [k, o]) => a.replace(k, o), LE_ADD.reduce((a, re) => a.replace(re, ''), t));
const LE_SRC_SHORTCUT = ' · <a href="#moonlend">Moon neutron record</a>', LE_SRC_SEC = /  <h2 id="moonlend">[\s\S]*?\n\n(?=  <h2 id="sunglobe">)/;
const lendSourcesOk = t => t.split(LE_SRC_SHORTCUT).length === 2 && t.includes(' · <a href="#mooncrater">Moon event counts</a>' + LE_SRC_SHORTCUT + ' · <a href="#tides">Tides</a>') && (t.match(/<h2 id="moonlend">/g) || []).length === 1 && LE_SRC_SEC.test(t)
  && t.indexOf('<h2 id="mooncrater">') < t.indexOf('<h2 id="moonlend">')
  && ['we do not resolve them', 'not a calibrated change in lunar neutron flux, and not a measurement of hydrogen or of water ice', 'which is not established here', 'neither it, nor the colour scale, nor the ± establishes a detection or a physical accuracy', 'still unresolved debate', '10.17189/p89b-8w72', 'e6b1c2d54e3e00d649a1229b08507dd10c859039ae2df8e34cdf1480bb0031ef', '9f185cc38cb8f378220b30f212deec8daf1e639071dcfe0304cb743038d26cdf', 'not paired with LRO’s dated path'].every(x => (t.match(LE_SRC_SEC) || [''])[0].includes(x));
const noLeSrc = t => t.replace(LE_SRC_SHORTCUT, '').replace(LE_SRC_SEC, '');
// Moon LEND readout-rounding fix (28 Nov 2026, Moon item 6 follow-up; narrow pin maintenance): its payload commit RD_MAIN changes moon.html by
// exactly the moonsci.js key (202612272000 -> 202612280400); everything else in moon.html and all of sources.html are untouched. moon.html (13e)
// is held to RD_MAIN and, with the old key put back, to LE_MAIN (and through it to everything before). 13ae checks that RD_MAIN changed exactly
// the literal RD_FILES since RD_PARENT (main), and 13af that the maintenance after it changed only this suite. LE_MAIN and behind do not move.
const RD_MAIN = process.env.RD_MAIN || '065b8b55b24c8d71df53c0420572dbd7dd2fb4af';     // moon-lend-rounding payload (28 Nov 2026)
const RD_PARENT = process.env.RD_PARENT || '542b68969010354fbfd71bc1bc6e3456c161cd7a';   // main at the branch cut
const RD_FILES = ['moon.html', 'moonsci.js', 'phase1/moon-lend-ui.test.cjs', 'phase1/moonsci/served_manifest.mjs', 'reviews/evidence/2026-11-28-moon-lend-rounding-manifest.json'];   // literal
const RD_KEY = ['moonsci.js?v=202612280400', 'moonsci.js?v=202612272000'];
const roundOk = t => t.split(RD_KEY[0]).length === 2 && !t.includes(RD_KEY[1]);
const noRound = t => t.replace(RD_KEY[0], RD_KEY[1]);
const SK_IDX_TAG = '<script src="moonlight.js?v=202612071100"></script>\n', SK_IDX_KEY = ['skyscene.js?v=202612271000', 'skyscene.js?v=202612101000'], SK_IDX_P = /              <p id="zoom-moonmap">[^\n]*<\/p>\n/;
const skIdxOk = t => t.split(SK_IDX_TAG).length === 2 && t.includes(SK_IDX_TAG + '<script src="' + SK_IDX_KEY[0] + '"></script>') && (t.match(new RegExp(SK_IDX_P.source, 'g')) || []).length === 1
  && /approximate calculated orientation/.test(t) && /appearance only, evenly lit/.test(t);
const noSkIdx = t => t.replace(SK_IDX_TAG, '').replace(SK_IDX_P, '').replace(SK_IDX_KEY[0], SK_IDX_KEY[1]);
const SK_SRC_P = /  <p><b>The Moon's picture\.<\/b>[^\n]*<\/p>\n/, SK_SRC_2 = ' When the view opens it also reads, from this site, the Moon page\'s map <code>assets/moon/lroc_color_2k.jpg</code> and sunlight table <code>assets/moon/moon-light-2026-06-R1.json</code>, each used only if its sha256 matches its pin. These two are optional: the view never waits for them.';
const skySrcOk = t => (t.match(new RegExp(SK_SRC_P.source, 'g')) || []).length === 1 && t.split(SK_SRC_2).length === 2 && /<b>appearance only and evenly lit<\/b>/.test(t) && /<b>approximate calculated orientation<\/b>/.test(t)
  && /drawn plain grey and the view still opens/.test(t) && /<h2 id="sky-scene">[\s\S]*?The Moon's picture\.[\s\S]*?<h2 id="skycraft">/.test(t);
const noSkySrc = t => t.replace(SK_SRC_P, '').replace(SK_SRC_2, '');
const LR_ADD = [/\n<link rel="stylesheet" href="moonlroc\.css\?v=202612261700">/,
  /    <div id="mg-lroc-ctl" class="mgctl">\n      <button type="button" id="mg-lroc" aria-pressed="false">Show a detailed site: Apollo 11 \(LROC\)<\/button>\n    <\/div>\n/,
  /      <li><b>Detailed site \(optional\):<\/b>[^\n]*<\/li>\n/,
  /    <p id="mg-lroc-loc" class="mglro" hidden><\/p>\n    <section id="mg-lroc-panel" class="mgl"[\s\S]*?\n    <\/section>\n/, /    <span>“Show a detailed site: Apollo 11 \(LROC\)” [^\n]*<\/span>\n/,
  /\n<script src="moonlroc\.js\?v=202612261700"><\/script>/];
const lrocOk = t => LR_ADD.every(re => (t.match(new RegExp(re.source, 'g')) || []).length === 1);
const noLroc = t => LR_ADD.reduce((a, re) => a.replace(re, ''), t);
const LR_SRC_SHORTCUT = ' · <a href="#moonlroc">Moon detailed site</a>', LR_SRC_SEC = /  <h2 id="moonlroc">[\s\S]*?\n\n(?=  <h2 id="sunglobe">)/;
const LR_SRC_KEYS = [['switching height off puts back the lighting you had before: if “Lit as now” was on, it returns for the current minute.', 'switching height off brings sunlight back for the current minute.'],
  ['switching it off puts back the lighting you had before: if “Lit as now” was on, it returns for the current minute.', 'switching it off brings sunlight back for the current minute.']];
const lrocSourcesOk = t => t.split(LR_SRC_SHORTCUT).length === 2 && t.includes(' · <a href="#moontemp">Moon temperature</a>' + LR_SRC_SHORTCUT + ' · <a href="#tides">Tides</a>') && (t.match(/<h2 id="moonlroc">/g) || []).length === 1 && LR_SRC_SEC.test(t)
  && LR_SRC_KEYS.every(([k]) => t.split(k).length === 2) && ['doi:10.1007/s11214-010-9634-2', 'doi:10.1016/j.icarus.2016.05.012', 'NASA/GSFC/Arizona State University', 'not a measured reflectance', 'not the picture’s footprint'].every(x => (t.match(LR_SRC_SEC) || [''])[0].includes(x));
// the Moon detailed-site section is removed first: the temperature section's pattern runs up to the Sun globe section
const noLrocSources = t => LR_SRC_KEYS.reduce((a, [k, o]) => a.replace(k, o), t.replace(LR_SRC_SHORTCUT, '').replace(LR_SRC_SEC, ''));
const noTidesSources = t => t.replace(TIDES_SHORTCUT + ' · <a href="#animals">', ' · <a href="#animals">').replace(TIDES_SEC, '');
const tidesSourcesOk = t => t.split(TIDES_SHORTCUT).length === 2 && t.includes(TIDES_SHORTCUT + ' · <a href="#animals">Animals</a>') && (t.match(/<h2 id="tides">/g) || []).length === 1 && TIDES_SEC.test(t);
const PROMISE_SPAN = ['<div class="promise fit"><span>', '</span></div>'], unwrapPromise = t => t.replace(PROMISE_SPAN[0], '<div class="promise">').replace(/(<div class="promise">[^<]*)<\/span><\/div>/, '$1</div>');
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const BREAK = process.env.BREAK || '', EDIT = process.env.EDIT || '';
const ONLY = (process.env.SECTIONS || '').split(',').filter(Boolean).map(Number), want = n => !ONLY.length || ONLY.includes(n);
let pass = 0, fail = 0; const failed = [];
const ok = (n, c, got) => { if (c) pass++; else { fail++; failed.push(n); console.log(`FAIL  ${n}${got !== undefined ? `\n      got: ${JSON.stringify(got).slice(0, 1600)}` : ''}`); } };
const wd = setTimeout(() => { console.log('FAIL  suite exceeded 20 min'); process.exit(1); }, 20 * 60e3);

const JS = 'animals-journey.js', GJS = 'animals-globe.js';
// the exact Sources block reviewed for the zebra's historical regional land context (C1a); 13e allows this one line and nothing else
const CTX_SOURCES = "  <p><b>Historical regional land context for the zebra: the two 4° grid cells 20–28° E, 18–22° S, over the recorded journey.</b> Fire detections: <a href=\"https://firms.modaps.eosdis.nasa.gov/\" target=\"_blank\" rel=\"noopener\">NASA FIRMS</a>, MODIS Collection 6 standard processing (file version 6.03); presumed vegetation fires (type 0), all confidence levels, Terra and Aqua; read 25 Nov 2026. We acknowledge the use of data and/or imagery from NASA's Land, Atmosphere Near real-time Capability for Earth observations (LANCE) (https://earthdata.nasa.gov/lance), part of NASA's Earth Science Data and Information System (ESDIS). Tree-cover loss: <a href=\"https://storage.googleapis.com/earthenginepartners-hansen/GFC-2025-v1.13/download.html\" target=\"_blank\" rel=\"noopener\">Hansen/UMD/Google/USGS/NASA Global Forest Change 2000–2025, version 1.13</a>, tiles 10S_020E and 20S_020E, where tree cover in 2000 was at least 30 %. Source: Hansen/UMD/Google/USGS/NASA. Licence <a href=\"https://creativecommons.org/licenses/by/4.0/\" target=\"_blank\" rel=\"noopener\">CC BY 4.0</a>. Only totals by month, grid cell and year are published; the source files are not. A detection marks a satellite pixel with an active fire and is not a count of fires. The loss figure is a relative indicator for the calendar years 2007 and 2008, which extend beyond the journey. Neither shows where the zebra went, what it encountered or how it was affected. Not for local-scale or tactical decisions.</p>";
const BREAKS = {
  'not-exclusive': [JS, "const prev = st.choice; if (prev) off();", "const prev = null;"],
  // with the request no longer aborted AND the generation check gone, a superseded answer would draw
  'late-answer-draws': [JS, "const abortLoad = () => { const c = st.abort; st.abort = null; if (c) try { c.abort(); } catch (_) { } };", "const abortLoad = () => { st.abort = null; };", "const jr = verify(man, d, ce.animal); if (gen !== st.gen) return;", "const jr = verify(man, d, ce.animal);",
    "const db = await get(J.BASE + ent.file); if (gen !== st.gen) return;", "const db = await get(J.BASE + ent.file);", "if (db.byteLength !== ent.bytes || await hex(db) !== ent.sha256) throw new Unverified('the display file does not match the manifest checksum'); if (gen !== st.gen) return;", "if (db.byteLength !== ent.bytes || await hex(db) !== ent.sha256) throw new Unverified('the display file does not match the manifest checksum');"],
  'off-no-cancel': [JS, "function off() { st.on = false; st.gen++; abortLoad();", "function off() { st.on = false; abortLoad();"],
  'off-no-abort': [JS, "function off() { st.on = false; st.gen++; abortLoad();", "function off() { st.on = false; st.gen++;"],
  'load-on-open': [JS, "  window.addEventListener('hashchange', reveal);\n  paint();", "  window.addEventListener('hashchange', reveal);\n  paint(); select(switches[0].dataset.journey);"],
  'deep-link-switches-on': [JS, "b.focus({ preventScroll: true }); }", "b.focus({ preventScroll: true }); b.click(); }"],
  'fail-stays-on': [JS, "      off(); st.choice = null;\n      if (shared)", "      off();\n      if (shared)"],
  'list-error-local': [JS, "      if (shared) { st.catErr = unv ? J.T.catUnverified : J.T.catFailed;", "      if (false) { st.catErr = unv ? J.T.catUnverified : J.T.catFailed;"],
  'no-catalogue-check': [JS, "if (await hex(cb) !== J.CATALOG_SHA256) throw new Unverified('the journey list does not match its pinned checksum');", ''],
  'no-manifest-check': [JS, "if (await hex(mb) !== ce.manifest_sha256) throw new Unverified('the manifest does not match the checksum in the journey list');", ''],
  'no-display-check': [JS, "if (db.byteLength !== ent.bytes || await hex(db) !== ent.sha256) throw new Unverified('the display file does not match the manifest checksum');", ''],
  'no-content-check': [JS, "if (!Number.isInteger(t) || (i && t <= d.t[i - 1])) throw new Unverified('fix times are not whole seconds in increasing order');", ''],
  'marker-next-fix': [JS, 'if (t[mid] <= s) lo = mid; else hi = mid - 1; } return lo; }', 'if (t[mid] <= s) lo = mid; else hi = mid - 1; } return Math.min(t.length - 1, lo + 1); }'],
  'future-fixes-drawn': [JS, 'o.fixes.geometry.setDrawRange(0, i >= 0 ? (i + 1) * 3 : 0);', 'o.fixes.geometry.setDrawRange(0, st.d.t.length * 3);'],
  'join-over-rule': [JS, "const joins = (d, rule, i) => d.t[i] - d.t[i - 1] <= rule && (!d.j || d.j[i] === 1);", "const joins = (d, rule, i) => d.t[i] - d.t[i - 1] <= rule + 1 && (!d.j || d.j[i] === 1);"],
  'ignore-join-flags': [JS, "const joins = (d, rule, i) => d.t[i] - d.t[i - 1] <= rule && (!d.j || d.j[i] === 1);", "const joins = (d, rule, i) => d.t[i] - d.t[i - 1] <= rule;"],
  'autoplay': [JS, "seek(st.R0, true); goArea();", "seek(st.R0, true); goArea(); play();"],
  'announce-per-frame': [JS, "st.rtExact = next; st.rt = Math.floor(next);", "announce('t ' + next); st.rtExact = next; st.rt = Math.floor(next);"],
  // both guards removed (the switch's own and select()'s): a switch marked unavailable would then start a load
  'disabled-still-loads': [JS, "    if (why) { st.choice = null; if (!quiet) announce(`${nameOf(id)} cannot be shown. ${why}`); return paint(); }\n", '', "    if (b.getAttribute('aria-disabled') === 'true') return announce(`${nameOf(id)} cannot be shown. ${blocked()}`);\n", ''],
  'no-pagehide-reset': [JS, "window.addEventListener('pagehide', () => { cancelList(); if (st.choice) select(null, true); else paint(); });", "window.addEventListener('pagehide', () => { cancelList(); paint(); });"],
  'hidden-keeps-playing': [JS, "document.addEventListener('visibilitychange', () => { if (document.hidden && st.playing) pause(false); });", ''],
  'date-kept-on-fallback': [GJS, "st.backdrop === 'plain' ? (st.coast === 'failed' ? G.T.plainNoCoast : G.T.plain) : G.T.loading", "st.backdrop === 'plain' ? G.T.imagery : G.T.loading"],
  'auto-rotate': [GJS, "globe.controls().autoRotate = false;\n      st.globe = 'ok';", "globe.controls().autoRotate = true;\n      st.globe = 'ok';"],
  'coast-always-fetched': [GJS, "      size(); loadBackdrop();", "      size(); loadBackdrop(); loadCoast();"],
  'filtered-says-recorded': [JS, "const F = !!st.man.card;", "const F = false;"],
  'no-phone-scroll': [JS, "function showGlobe() { const box = $('an-globe-box'), panel = $('an-panel'); if (!box || !panel) return;", "function showGlobe() { const box = $('an-globe-box'), panel = $('an-panel'); return;"],
  'scroll-on-answer': [JS, "seek(st.R0, true); goArea();", "seek(st.R0, true); goArea(); showGlobe();"],
  'scroll-on-off': [JS, "if (turnOn && st.choice === id) showGlobe(); });", "showGlobe(); });"],
  'scroll-ignores-reduced-motion': [JS, "const reduce = !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches),", "const reduce = false,"],
  'deep-link-scrolls-to-globe': [JS, "b.focus({ preventScroll: true }); }", "b.focus({ preventScroll: true }); showGlobe(); }"],
  'no-status-by-globe': [JS, "ns.textContent = t; ns.hidden = !t; }", "ns.textContent = ''; ns.hidden = true; }"],
  'selection-keeps-list-retry': [JS, "    cancelList(); st.note = '';\n", "    st.note = '';\n"],
  'list-retry-no-token': [JS, "} catch (e) { if (tok !== st.listTok) return; err = J.T.catFailed;", "} catch (e) { err = J.T.catFailed;"],
  'list-retry-late-success': [JS, "const h = await hex(b); if (tok !== st.listTok) return;", "const h = await hex(b);", "const b = await r.arrayBuffer(); if (tok !== st.listTok) return;", "const b = await r.arrayBuffer();", "const r = await fetch(J.CATALOG, { cache: 'no-store', signal: c.signal }); if (tok !== st.listTok) return;", "const r = await fetch(J.CATALOG, { cache: 'no-store' });"],
  'list-retry-no-time-limit': [JS, "L = { c, timer: setTimeout(() => c.abort(), J.WAIT_MS) }; st.list = L; paint();", "L = { c, timer: 0 }; st.list = L; paint();"],
  'pagehide-keeps-list-retry': [JS, "window.addEventListener('pagehide', () => { cancelList(); if", "window.addEventListener('pagehide', () => { if"],
  // stage 2: the bird
  'marker-in-withheld': [JS, "o.marker.visible = vis && i >= 0 && !st.hid;", "o.marker.visible = vis && i >= 0;"],
  'hidden-ends-at-last-withheld': [JS, "for (const h of H) if (s >= h.from && s < h.to) return h; return null; };", "for (const h of H) if (s >= h.from && s <= h.p[1]) return h; return null; };"],
  'tried-before-reached': [JS, "if (x > t[i] && x < next && x <= st.rt) f = x;", "if (x > t[i] && x < next) f = x;"],
  'accuracy-in-withheld': [JS, "are not shown. No marker is shown` +", "are not shown. No marker is shown · Tag's accuracy estimate ${i >= 0 ? d.acc[i] : 0} m` +"],
  'replay-starts-at-first-fix': [JS, "setBarFrame(); paint(); seek(st.R0, true); goArea();", "setBarFrame(); paint(); seek(d.t[0], true); goArea();"],
  'replay-ends-at-last-fix': [JS, "    const end = st.R1, next = st.rtExact + dt * st.speed;", "    const end = st.d.t[st.d.t.length - 1], next = st.rtExact + dt * st.speed;"],
  'bird-says-not-displayed': [JS, "      if (st.man.kind === 'gps-filtered') {", "      if (false) {"],
  'new-fields-optional': [JS, "if (!Array.isArray(d[f])) throw new Unverified(`the display file lacks \"${f}\", which this journey requires`);", ""],
  'no-acc-check': [JS, "if (!Array.isArray(d.acc) || d.acc.length !== n || d.acc.some(x => typeof x !== 'number' || !Number.isFinite(x) || x < 0)) throw new Unverified('the accuracy estimates are missing or malformed'); }", "}"],
  'no-inside-period-check': [JS, "if (lo < n && d.t[lo] <= l) throw new Unverified('a displayed fix lies inside a withheld period');", ""],
  'join-across-withheld-accepted': [JS, "if (lo > 0 && lo < n && (!d.j || d.j[lo] !== 0)) throw new Unverified('a step is joined across a withheld period');", ""],
  'no-failed-check': [JS, "|| ts.has(x) || W.some(p => x >= p[0] && x <= p[1])) throw", ") throw"],
  'stops-skip-withheld-starts': [JS, "[...new Set([st.R0, ...d.t, ...W.map(p => p[0]), st.R1])]", "[...new Set([st.R0, ...d.t, st.R1])]"],
  'chooser-back': ['animals.html', '<div class="vh" id="an-say" aria-live="polite"></div>', '<select id="journey-choose"><option>x</option></select><div class="vh" id="an-say" aria-live="polite"></div>'],
  'switch-unlabelled': ['animals.html', '<span class="t">White shark, tag 118845 (2012–2013)</span>', '<span class="t"></span>'],
};
// EDIT=no-abort is not a break: requests are no longer aborted, and section 5 must STILL pass apart from the two checks that the
// request itself was aborted (5b, 5g). It shows the generation check alone refuses a superseded answer.
// Section 13 breaks: each makes one unintended change to a file the comparisons read (nothing on disk changes).
Object.assign(BREAKS, {
  'earth-script-edited': ['layers.js', 'const ROWS = GROUPS.flatMap(g => g[1]);', 'const ROWS = GROUPS.flatMap(g => g[1]); '],
  'nc-app-edited': ['app.js', 'ME.REFRESH_MS = 5 * 60e3;', 'ME.REFRESH_MS = 5 * 60e3; '],
  'nc-index-edited': ['index.html', '</title>', ' </title>'],
  // 27 Nov 2026 (Sky zoom-out Moon picture): one unintended change to each file it pins
  'sk-index-paragraph-edited': ['index.html', 'appearance only, evenly lit, not how it was lit at that instant', 'appearance only, not how it was lit at that instant'],
  'sk-index-tag-gone': ['index.html', '<script src="moonlight.js?v=202612071100"></script>\n', ''],
  'sk-skyscene-edited': ['skyscene.js', 'MAP_TIMEOUT_MS = 10000', 'MAP_TIMEOUT_MS = 20000'],
  'sk-sources-edited': ['sources.html', 'the Moon is drawn plain grey and the view still opens', 'the Moon is drawn plain grey'],
  'sk-sources-datapath-gone': ['sources.html', ' These two are optional: the view never waits for them.', ''],
  'sk-moonlight-edited': ['moonlight.js', 'step: 21600000', 'step: 21600001'],
  // 27 Nov 2026 (Moon CRaTER event counts): the CRaTER additions are set aside only once each, and only those lines
  'cr-moon-panel-edited': ['moon.html', 'not a radiation dose, a particle flux or conditions at a place on the Moon’s surface', 'not a radiation dose or conditions on the surface'],
  'cr-sources-edited': ['sources.html', 'and it is not a 95% interval', 'and it is a 95% interval'],
  // 27 Nov 2026 (Moon neutron record): the LEND additions are set aside only once each, and only those lines; the two keys are its own
  'le-moon-legend-edited': ['moon.html', 'nor a measurement of hydrogen or ice.', 'and a measurement of hydrogen.'],
  'le-moon-key-old': ['moon.html', 'moonsci.css?v=202612271700', 'moonsci.css?v=202612261100'],   // 28 Nov 2026: LEND's own moonsci.css key (its moonsci.js key is no longer served)
  'rd-moon-key-old': ['moon.html', 'moonsci.js?v=202612280400', 'moonsci.js?v=202612272000'],   // 28 Nov 2026: the LEND release's key put back
  'le-sources-edited': ['sources.html', 'which is not established here', 'which is established here'],
  'le-sources-shortcut-moved': ['sources.html', ' · <a href="#mooncrater">Moon event counts</a> · <a href="#moonlend">Moon neutron record</a>', ' · <a href="#moonlend">Moon neutron record</a> · <a href="#mooncrater">Moon event counts</a>'],
  'nc-index-tab-gone': ['index.html', '    <a href="animals.html" data-view="animals">Animals</a>\n', ''],
  'nc-index-menu-gone': ['index.html', '      <li role="none"><a role="menuitem" href="animals.html" data-page="animals">Animals</a></li>\n', ''],
  'nc-sources-edited': ['sources.html', '</title>', ' </title>'],
  'nc-sources-tab-gone': ['sources.html', '    <a href="animals.html" data-view="animals">Animals</a>\n', ''],
  'nc-sources-id-gone': ['sources.html', 'ptt id 98364', 'ptt id 98365'],
  'ctx-sources-edited': ['sources.html', 'which extend beyond the journey', 'which match the journey'],
  'ctx-sources-dropped': ['sources.html', CTX_SOURCES + '\n', ''],
  'ctx-sources-moved': ['sources.html', CTX_SOURCES + '\n', '', '  <h2 id="search">', CTX_SOURCES + '\n  <h2 id="search">'],
  'nc-sources-shortcut-gone': ['sources.html', ' · <a href="#animals">Animals</a> · <a href="#search">Search</a>', ' · <a href="#search">Search</a>'],
  'shared-rule-dropped': ['style.css', '\n.top{', '\n.top.x{'],
  'moon-page-edited': ['moon.html', '</title>', ' </title>'],
  'tl-script-edited': ['timeline.js', 'const MIN_SPAN = 1', 'const MIN_SPAN = 2'],
  'tl-page-edited': ['timeline.html', '</title>', ' </title>'],
  'tl-page-animals-tab-gone': ['timeline.html', '    <a href="animals.html" data-view="animals">Animals</a>\n', ''],
  // 25 Nov 2026 (Tides navigation): the Tides lines are set aside only once each, and only those lines
  'tides-index-tab-gone': ['index.html', '    <a href="tides.html" data-view="tides">Tides</a>\n', ''],
  'tides-sources-menu-gone': ['sources.html', '      <li role="none"><a role="menuitem" href="tides.html" data-page="tides">Tides</a></li>\n', ''],
  'tides-sources-section-edited': ['sources.html', 'It is an Earth-facing view, not a picture of the whole Sun.', 'It is a picture of the whole Sun.'],
  'mh-sources-section-edited': ['sources.html', 'The cause is not established. That cap is drawn grey on the globe.', 'That cap is drawn grey on the globe.'],
  'mh-sources-shortcut-gone': ['sources.html', ' · <a href="#moonheight">Moon height</a>', ''],
  'tides-sources-shortcut-moved': ['sources.html', ' · <a href="#tides">Tides</a> · <a href="#animals">Animals</a>', ' · <a href="#animals">Animals</a> · <a href="#tides">Tides</a>'],
  'tides-tl-tab-twice': ['timeline.html', '    <a href="tides.html" data-view="tides">Tides</a>\n', '    <a href="tides.html" data-view="tides">Tides</a>\n    <a href="tides.html" data-view="tides">Tides</a>\n'],
  'tl-page-header-edited': ['timeline.html', '<a href="animals.html" data-view="animals">Animals</a>', '<a href="animals.html" data-view="animals">Animals</a><a href="x.html">X</a>'],
  'tl-rule-dropped': ['style.css', 'body.tl .tlmain{max-width:1400px;margin:0 auto;padding:16px}\n', ''],
  'tl-rule-edited': ['style.css', 'body.tl .tlmain{max-width:1400px;', 'body.tl .tlmain{max-width:1401px;'],
  'tl-rule-added': ['style.css', 'body.tl .tlmain{max-width:1400px;margin:0 auto;padding:16px}\n', 'body.tl .tlmain{max-width:1400px;margin:0 auto;padding:16px}\nbody.tl .tlmain{color:red}\n'],
});
const EDITS = { 'no-abort': [JS, "const abortLoad = () => { const c = st.abort; st.abort = null; if (c) try { c.abort(); } catch (_) { } };", "const abortLoad = () => { st.abort = null; };"] };
const EXPECT = { 'not-exclusive': '3b', 'late-answer-draws': '5a', 'off-no-cancel': '5c', 'off-no-abort': '5g', 'load-on-open': '1b', 'deep-link-switches-on': '8a', 'fail-stays-on': '6a', 'list-error-local': '6h',
  'no-catalogue-check': '6h', 'no-manifest-check': '6f', 'no-display-check': '6e', 'no-content-check': '6g', 'marker-next-fix': '2d', 'future-fixes-drawn': '2e', 'join-over-rule': '12a', 'ignore-join-flags': '12c',
  'autoplay': '2b', 'announce-per-frame': '7e', 'disabled-still-loads': '11b', 'no-pagehide-reset': '9a', 'hidden-keeps-playing': '9c', 'date-kept-on-fallback': '10b', 'auto-rotate': '1g', 'coast-always-fetched': '1f',
  'chooser-back': '1d', 'switch-unlabelled': '1c', 'filtered-says-recorded': '12h', 'no-phone-scroll': '16b', 'scroll-on-answer': '16c', 'scroll-on-off': '16e', 'scroll-ignores-reduced-motion': '16b',
  'deep-link-scrolls-to-globe': '16j', 'no-status-by-globe': '16b', 'selection-keeps-list-retry': '17a', 'list-retry-no-token': '17a', 'list-retry-late-success': '17c', 'list-retry-no-time-limit': '17h', 'pagehide-keeps-list-retry': '17f',
  'marker-in-withheld': '18c', 'hidden-ends-at-last-withheld': '18c', 'tried-before-reached': '18e', 'accuracy-in-withheld': '18a', 'replay-starts-at-first-fix': '18a', 'replay-ends-at-last-fix': '18m',
  'bird-says-not-displayed': '18f', 'new-fields-optional': '19a', 'no-acc-check': '19b', 'no-inside-period-check': '19d', 'join-across-withheld-accepted': '19c', 'no-failed-check': '19e', 'stops-skip-withheld-starts': '18i',
  'earth-script-edited': '13c', 'nc-app-edited': '13k', 'nc-index-edited': '13b', 'sk-index-paragraph-edited': '13b', 'sk-index-tag-gone': '13b', 'sk-skyscene-edited': '13x', 'cr-moon-panel-edited': '13e moon.html (CRaTER)', 'cr-sources-edited': '13e sources.html (CRaTER)', 'le-moon-legend-edited': '13e moon.html (LEND)', 'le-moon-key-old': '13e moon.html (LEND)', 'rd-moon-key-old': '13e moon.html (LEND rounding)', 'le-sources-edited': '13e sources.html (LEND)', 'le-sources-shortcut-moved': '13e sources.html (LEND)', 'sk-sources-edited': '13e sources.html (Sky)', 'sk-sources-datapath-gone': '13e sources.html (Sky)', 'sk-moonlight-edited': '13c', 'nc-index-tab-gone': '13b', 'nc-index-menu-gone': '13b', 'nc-sources-edited': '13e sources.html', 'nc-sources-tab-gone': '13e sources.html', 'nc-sources-id-gone': '13e sources.html', 'nc-sources-shortcut-gone': '13e sources.html', 'ctx-sources-edited': '13e sources.html', 'ctx-sources-dropped': '13e sources.html', 'ctx-sources-moved': '13e sources.html', 'shared-rule-dropped': '13d', 'moon-page-edited': '13e moon.html', 'tl-script-edited': '13g', 'tl-page-edited': '13h', 'tl-page-animals-tab-gone': '13h', 'tides-index-tab-gone': '13b', 'tides-sources-menu-gone': '13e sources.html', 'tides-tl-tab-twice': '13h', 'tides-sources-section-edited': '13e sources.html', 'tides-sources-shortcut-moved': '13e sources.html', 'mh-sources-section-edited': '13e sources.html', 'mh-sources-shortcut-gone': '13e sources.html', 'tl-page-header-edited': '13h',
  'tl-rule-dropped': '13i', 'tl-rule-edited': '13i', 'tl-rule-added': '13i' };
if (BREAK && !(BREAKS[BREAK] && EXPECT[BREAK])) { console.log('FAIL  unknown break ' + BREAK); process.exit(1); }

// ---------- files
const real = name => fs.readFileSync(path.join(ROOT, 'assets/animals', name));
const CAT = real('journeys-R1.catalog.json'), CATJ = JSON.parse(CAT), CAT_PIN = sha(CAT);
const JOUR = Object.fromEntries(CATJ.journeys.map(e => { const m = JSON.parse(real(e.manifest)), j = m.journeys.find(x => x.animal === e.animal); return [e.id, { e, m, j, d: JSON.parse(real(j.file)) }]; }));
const Z = 'zebra-botswana-Z3866', SH = 'white-shark-sa-118845', W = 'false-killer-whale-hawaii-98364', BIRD = 'waved-albatross-galapagos-3275-30662', IDS = [Z, SH, W, BIRD];
const NAME = { [Z]: 'Plains zebra', [SH]: 'White shark', [W]: 'False killer whale', [BIRD]: 'Waved albatross' };
/** where a journey's replay starts: the start of the recording (the bird's is before its first displayed fix) */
const startOf = id => Number.isInteger(JOUR[id].j.record_first_s) ? JOUR[id].j.record_first_s : JOUR[id].d.t[0];
const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const utc = s => { const x = new Date(s * 1000).toISOString(); return `${+x.slice(8, 10)} ${MON[+x.slice(5, 7) - 1]} ${x.slice(0, 4)} ${x.slice(11, 19)} UTC`; };
const lastAt = (t, s) => { let k = -1; for (let i = 0; i < t.length && t[i] <= s; i++) k = i; return k; };                 // plain scan, not the page's search
const joinsTo = (d, rule, i) => { let k = 0; for (let j = 1; j <= i; j++) if (d.t[j] - d.t[j - 1] <= rule && (!d.j || d.j[j] === 1)) k++; return k; };
const BACKDROP = (() => { const p = new PNG({ width: 64, height: 32 }); for (let i = 0; i < p.data.length; i += 4) { p.data[i] = 10; p.data[i + 1] = 30; p.data[i + 2] = 60; p.data[i + 3] = 255; } return PNG.sync.write(p); })();
/** a fixture for one journey: its display file and manifest replaced, the journey list re-pinned (harness substitution) */
function fixture(id, mutate) { const T = JOUR[id], d = JSON.parse(JSON.stringify(T.d)), m = JSON.parse(JSON.stringify(T.m)); const jr = m.journeys.find(x => x.animal === T.e.animal);
  mutate(d, m, jr); const db = Buffer.from(JSON.stringify(d)); jr.file = 'fx-' + id + '.json'; jr.bytes = db.length; jr.sha256 = sha(db);
  const mb = Buffer.from(JSON.stringify(m)), cat = Buffer.from(JSON.stringify({ ...CATJ, journeys: CATJ.journeys.map(e => e.id === id ? { ...e, manifest_sha256: sha(mb) } : e) }));
  return { id, display: db, manifest: mb, cat, file: jr.file, d, m, jr }; }

// ---------- server. S.over[file name] = { status, body, hold } overrides one asset; S.cat = bytes for the journey list; S.fx = a fixture
const S = { over: {}, q: {}, cat: null, fx: null, log: [], keepable: false };   // S.q[file name] = one-off answers, used in order before S.over
const reset = () => Object.assign(S, { over: {}, q: {}, cat: null, fx: null, log: [], keepable: false });
const TYPES = { '.html': 'text/html', '.js': 'application/javascript', '.css': 'text/css', '.json': 'application/json', '.bin': 'application/octet-stream' };
function served(f) { let t = fs.readFileSync(path.join(ROOT, f), 'utf8');
  for (const E of [BREAK && BREAKS[BREAK], EDIT && EDITS[EDIT]]) if (E && E[0] === f) for (let k = 1; k < E.length; k += 2) { const a = E[k], b = E[k + 1]; if (t.split(a).length !== 2) { console.log('FAIL  edit did not apply: ' + (BREAK || EDIT)); process.exit(1); } t = t.replace(a, b); }
  if (S.fx && (f === JS || f === 'animals.js')) { if (t.split(CAT_PIN).length !== 2) { console.log('FAIL  pinned checksum not found in ' + f); process.exit(1); } t = t.replace(CAT_PIN, sha(S.fx.cat)); }
  return t; }
const srv = http.createServer(async (q, s) => {
  const p = decodeURIComponent(q.url.split('?')[0]), f = p.replace(/^\//, '') || 'index.html';
  const send = (code, type, body) => { s.writeHead(code, { 'content-type': type, 'cache-control': S.keepable ? 'no-cache' : 'no-store' }); s.end(body); };
  if (p.startsWith('/assets/animals/')) { const name = p.split('/').pop(); S.log.push(name); const o = S.q[name] && S.q[name].length ? S.q[name].shift() : S.over[name];
    if (o && o.hold) await o.hold;
    if (o && o.status && o.status !== 200) return send(o.status, 'text/plain', 'no');
    if (o && o.body) return send(200, 'application/json', o.body);
    if (name === 'journeys-R1.catalog.json') return send(200, 'application/json', S.cat || (S.fx ? S.fx.cat : CAT));        // the journey list only; the census section's own list is served as it is
    if (S.fx && name === JOUR[S.fx.id].e.manifest) return send(200, 'application/json', S.fx.manifest);
    if (S.fx && name === S.fx.file) return send(200, 'application/json', S.fx.display);
    return fs.existsSync(path.join(ROOT, 'assets/animals', name)) ? send(200, 'application/json', real(name)) : send(404, 'text/plain', ''); }
  if (p === '/assets/coast-50m.bin') S.log.push('coast-50m.bin');
  if (!fs.existsSync(path.join(ROOT, f)) || fs.statSync(path.join(ROOT, f)).isDirectory()) return send(404, 'text/plain', '');
  const ext = path.extname(f); if (TYPES[ext] && ext !== '.json' && ext !== '.bin') return send(200, TYPES[ext], served(f));
  send(200, TYPES[ext] || 'application/octet-stream', fs.readFileSync(path.join(ROOT, f)));
});
let BASE;
/** opts: img 'ok' | 'fail' | 'xml' | 'hang' ; lib false = the globe library is blocked */
async function ctxFor(browser, vp, opts = {}) {
  const ctx = await browser.newContext({ viewport: vp, deviceScaleFactor: 1, reducedMotion: 'reduce', ...(opts.extra || {}) }); ctx._img = [];
  await ctx.route('**/unpkg.com/**', r => opts.lib === false ? r.abort() : r.fulfill({ status: 200, contentType: 'application/javascript', body: GLOBE_JS }));
  await ctx.route('**/fonts.googleapis.com/**', r => r.fulfill({ status: 200, contentType: 'text/css', body: '' }));
  await ctx.route('**/*.nasa.gov/**', r => { ctx._img.push(r.request().url()); const m = opts.img || 'ok';
    if (m === 'fail') return r.abort(); if (m === 'hang') return;                                                        // 'hang': never answered
    if (m === 'xml') return r.fulfill({ status: 200, contentType: 'application/xml', headers: { 'access-control-allow-origin': '*' }, body: '<ServiceExceptionReport/>' });
    return r.fulfill({ status: 200, contentType: 'image/png', headers: { 'access-control-allow-origin': '*' }, body: BACKDROP }); });
  return ctx;
}
async function open(browser, vp = { width: 1280, height: 860 }, hash = '', opts = {}) {
  const ctx = await ctxFor(browser, vp, opts); if (opts.pre) await opts.pre(ctx);
  const page = await ctx.newPage(), errs = [], reqs = [], failedReqs = []; page.on('pageerror', e => errs.push(String(e).slice(0, 200)));
  page.on('request', r => reqs.push(r.url())); page.on('requestfailed', r => failedReqs.push([r.url().split('/').pop().split('?')[0], (r.failure() || {}).errorText || '']));
  await page.goto(BASE + '/animals.html' + hash, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => window.ME && ME.journey && ME.animalsGlobe && ME.animalsPage, null, { timeout: 30000 });
  if (!opts.noWait) await page.waitForFunction(() => { const g = ME.animalsGlobe.state(); return g.globe !== 'ok' || (g.backdrop === 'imagery') || (g.backdrop === 'plain' && g.coast !== 'loading' && g.coast !== 'idle'); }, null, { timeout: 30000 });
  await page.waitForFunction(() => [...document.querySelectorAll('.an-study [data-f="state"]')].every(e => !/Checking/.test(e.textContent)), null, { timeout: 30000 });
  await page.waitForFunction(() => !window.ME.census || ME.census.state().status !== 'loading', null, { timeout: 30000 });        // the census section (stage 3) has settled too
  await page.waitForTimeout(400);
  return { ctx, page, errs, reqs, failedReqs };
}
const state = page => page.evaluate(() => ({ ...ME.journey.state(), scene: ME.journey.sceneCount(), g: ME.animalsGlobe.state(), barHidden: document.getElementById('replay').hidden,
  say: document.getElementById('an-say').textContent, play: document.getElementById('replay-play').textContent, note: document.getElementById('replay-note').textContent, rule: document.getElementById('replay-rule').textContent,
  range: document.getElementById('replay-range').value, y: Math.round(scrollY), vh: innerHeight,
  box: (() => { const r = document.getElementById('an-globe-box').getBoundingClientRect(); return { top: Math.round(r.top), bottom: Math.round(r.bottom) }; })(),
  beside: (() => { const e = document.getElementById('an-status'), r = e.getBoundingClientRect(); return e.hidden ? null : { text: e.textContent, inView: r.top >= 0 && r.bottom <= innerHeight }; })(),
  barTop: (() => { const e = document.getElementById('replay'); return e.hidden ? null : Math.round(e.getBoundingClientRect().top); })(),
  retryBtn: (() => { const e = document.getElementById('an-integrity-retry'); return [e.textContent, e.getAttribute('aria-busy')]; })(), focus: document.activeElement ? document.activeElement.id : null, integrity: document.getElementById('an-integrity').hidden ? null : document.getElementById('an-integrity-text').textContent }));
const checked = s => IDS.filter(id => s.switches[id].checked === 'true');
const tgl = id => '#tgl-' + id;
const settle = (page, id, st = 'ready') => page.waitForFunction(([i, w]) => { const s = ME.journey.state(); return w === 'off' ? s.status === 'off' : (s.choice === i && s.status === w); }, [id, st], { timeout: 30000 });
const on = async (page, id, st = 'ready') => { await page.click(tgl(id)); await settle(page, id, st); };
const coordsOf = (page, lat, lon) => page.evaluate(([la, lo, alt]) => { const c = ME.animalsGlobe.raw().getCoords(la, lo, alt); return [c.x, c.y, c.z]; }, [lat, lon, 0.004]);
const near = (a, b) => a && b && a.every((v, i) => Math.abs(v - b[i]) < 1e-3);
/** wait until no load is in flight, whatever its outcome (the checks then say what the outcome must be) */
const done = page => page.waitForFunction(() => ME.journey.state().status !== 'loading', null, { timeout: 30000 }).then(() => page.waitForTimeout(200));
const gate = () => { let go; const p = new Promise(r => { go = r; }); return { p, go }; };

(async () => {
  await new Promise(r => srv.listen(0, '127.0.0.1', r)); BASE = 'http://127.0.0.1:' + srv.address().port;
  const browser = await chromium.launch({ args: ['--use-gl=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  try {
  // ===== 1. At load (T1, T2, T3, T12, T15)
  if (want(1)) { reset(); const { ctx, page, errs, reqs } = await open(browser); const s = await state(page);
    ok('1a no page error at load', errs.length === 0, errs);
    ok('1b nothing is on at load: every switch reads off, nothing is drawn, the replay bar is hidden', checked(s).length === 0 && s.choice === null && s.scene === 0 && s.barHidden && IDS.every(id => s.switches[id].state === 'off'), s.switches);
    const dom = await page.evaluate(() => ({ sw: [...document.querySelectorAll('#an-panel button.an-tgl')].map(b => ({ id: b.dataset.journey, role: b.getAttribute('role'), checked: b.getAttribute('aria-checked'), label: b.textContent.trim(), acc: b.getAttribute('aria-label'),
        desc: (document.getElementById(b.getAttribute('aria-describedby')) || {}).textContent || '', h: b.getBoundingClientRect().height })),
      group: (() => { const g = document.getElementById('an-panel'); return { role: g.getAttribute('role'), name: (document.getElementById(g.getAttribute('aria-labelledby')) || {}).textContent, desc: (document.getElementById(g.getAttribute('aria-describedby')) || {}).textContent }; })(),
      groups: [...document.querySelectorAll('#an-panel h3.an-grp')].map(h => h.textContent.trim()), selects: [...document.querySelectorAll('select')].map(x => x.id), radios: document.querySelectorAll('[role="radio"],[role="radiogroup"],input[type="radio"]').length,
      tabs: [...document.querySelectorAll('nav.tabs a')].map(a => [a.textContent.trim(), a.getAttribute('aria-current')]) }));
    ok('1c each animal has one labelled switch: role="switch", unchecked, a visible label that begins with the journey list\'s label and carries the years, described by its evidence line, at least 44 px high',
      dom.sw.length === IDS.length && dom.sw.every(b => b.role === 'switch' && b.checked === 'false' && !b.acc && b.label.startsWith(JOUR[b.id].e.label) && /\(\d{4}(–\d{4})?\)$/.test(b.label) && /dated record, not current/.test(b.desc) && b.h >= 44), dom.sw);
    ok('1d no chooser: the only select on the page is the replay speed; no radio semantics', dom.selects.join() === 'replay-speed' && dom.radios === 0, [dom.selects, dom.radios]);
    ok('1e the switches are one labelled group that says "one at a time"; groups are Land, Sea and Air', dom.group.role === 'group' && /one at a time/i.test(dom.group.name) && /Switching another on switches the first off/.test(dom.group.desc) && /Nothing is on when the page opens/.test(dom.group.desc) && dom.groups.join() === 'Land,Sea,Air', dom);
    const assets = S.log.slice(), allowed = u => u.startsWith(BASE) || /^https:\/\/unpkg\.com\/globe\.gl@2\.45\.0\//.test(u) || /^https:\/\/fonts\.googleapis\.com\//.test(u) || /^https:\/\/gibs\.earthdata\.nasa\.gov\//.test(u) || u.startsWith('blob:') || u.startsWith('data:');
    ok('1f network at load: the journey list and one manifest per card, the three small files of the census section (stage 3), and the corridor\'s list and manifest but NOT its display file (stage 4); NO journey display file; no coastline file while imagery is shown; one imagery request; no hub request; only the allowed origins',
      assets.filter(n => /catalog/.test(n)).length >= 1 && assets.filter(n => /manifest/.test(n) && !/census|corridor/.test(n)).length === IDS.length && assets.filter(n => /census|populations/.test(n)).length === 3 && assets.filter(n => /corridor/.test(n)).sort().join() === 'corridors-R1.catalog.json,mule-deer-east-walker-corridor-R1.manifest.json' && !assets.some(n => IDS.some(id => n === JOUR[id].j.file)) && !assets.includes('coast-50m.bin') && ctx._img.length === 1 && !reqs.some(u => u.includes(HUB)) && reqs.every(allowed), { assets, img: ctx._img.length, other: reqs.filter(u => !allowed(u)) });
    ok('1g the globe is ready, still (no auto-rotation), showing the whole Earth; the backdrop line gives the picture\'s own date and says it is not the journey dates',
      s.g.globe === 'ok' && s.g.autoRotate === false && Math.abs(s.g.view.altitude - 2.2) < 0.01 && s.g.backdrop === 'imagery' && /^Backdrop: NASA satellite imagery for \d{2} [A-Z][a-z]{2} \d{4} \(NASA GIBS, VIIRS NOAA-21\), not the journey dates\./.test(s.g.note) && /Dark areas/.test(s.g.note), s.g);
    ok('1h the header has the six tabs with Animals current (Tides added after Sun, 25 Nov 2026)', dom.tabs.map(t => t[0]).join() === 'Earth now,Timeline,Moon,Sun,Tides,Animals' && dom.tabs[5][1] === 'page' && dom.tabs.slice(0, 5).every(t => !t[1]), dom.tabs);
    const img = await page.evaluate(() => ({ url: ME.animalsGlobe.IMG_URL, day: ME.animalsGlobe.IMG_DAY, G: ME.animalsGlobe.G }));
    const app = fs.readFileSync(path.join(ROOT, 'app.js'), 'utf8'), idx = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
    const wantDay = new Date(Date.now() - 36 * 3600e3).toISOString().slice(0, 10);
    const PREFIX = 'https://gibs.earthdata.nasa.gov/wms/epsg4326/best/wms.cgi?SERVICE=WMS&REQUEST=GetMap&VERSION=1.3.0&FORMAT=image/jpeg&WIDTH=2048&HEIGHT=1024&CRS=EPSG:4326&BBOX=-90,-180,90,180&TIME=';
    ok('1i the backdrop uses Earth now\'s own selection rule: the same 36-hour date offset and layer as app.js, and the same address as index.html builds',
      app.includes('new Date(Date.now() - 36 * 3600e3).toISOString().slice(0, 10)') && app.includes(`id: '${img.G.IMG_LAYER}', sat: '${img.G.IMG_SAT}'`) && img.G.IMG_OFFSET_H === 36 && img.day === wantDay &&
      idx.includes("const gibs = '" + PREFIX + "' + IMG_DAY + '&LAYERS=' + IMG_LAYER.id;") && img.url === PREFIX + wantDay + '&LAYERS=' + img.G.IMG_LAYER && ctx._img[0] === img.url, [img.url, ctx._img]);
    ok('1k the globe library served by this suite is the version the page pins (2.45.0)', GLOBE_VER === '2.45.0' && /unpkg\.com\/globe\.gl@2\.45\.0\//.test(fs.readFileSync(path.join(ROOT, 'animals.html'), 'utf8')), GLOBE_VER);
    // the tabs on every page
    for (const pg of ['index.html', 'timeline.html', 'moon.html', 'sun.html', 'sources.html', 'tides.html']) { const p2 = await ctx.newPage(); await p2.goto(BASE + '/' + pg, { waitUntil: 'domcontentloaded' }); await p2.waitForTimeout(300);
      const t = await p2.evaluate(() => [...document.querySelectorAll('nav.tabs a')].map(a => a.getAttribute('href'))); ok(`1j ${pg}: one Animals tab, last, after Moon, Sun and Tides`, t.join() === 'index.html,timeline.html,moon.html,sun.html,tides.html,animals.html', t); await p2.close(); }
    await ctx.close(); }

  // ===== 2. One journey on (T4, T18): the zebra
  if (want(2)) { reset(); const g = gate(); S.over[JOUR[Z].j.file] = { hold: g.p }; const { ctx, page, errs } = await open(browser); const T = JOUR[Z], D = T.d, RULE = T.m.gap_rule.max_join_seconds, N = D.t.length;
    S.log = []; await page.focus(tgl(Z)); await page.keyboard.press('Space'); await settle(page, Z, 'loading'); let s = await state(page);
    ok('2a while it loads the switch reads on and busy, its row says loading, nothing is drawn yet, focus stays on the switch', s.switches[Z].checked === 'true' && s.switches[Z].busy === 'true' && s.switches[Z].state === 'loading' && s.scene === 0 && s.barHidden && s.focus === 'tgl-' + Z && /Plains zebra loading\.$/.test(s.say), s);
    g.go(); delete S.over[JOUR[Z].j.file]; await settle(page, Z, 'ready'); await page.waitForTimeout(300); s = await state(page);
    ok('2b shown: three objects on the globe, the bar is visible, replay is paused at the first recorded fix, the journey is announced once, focus is still on the switch',
      s.scene === 3 && !s.barHidden && s.playing === false && s.i === 0 && s.rt === D.t[0] && s.switches[Z].checked === 'true' && s.switches[Z].busy === null && s.switches[Z].state === 'replay' && s.say === 'Plains zebra shown. Replay is at the first recorded fix.' && s.focus === 'tgl-' + Z && new RegExp('First recorded fix ' + utc(D.t[0]).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).test(s.bar), s);
    ok('2c only now was the journey\'s display file requested, once', S.log.filter(n => n === T.j.file).length === 1 && !S.log.some(n => n === JOUR[SH].j.file || n === JOUR[W].j.file), S.log);
    const bb = T.j.bbox; ok('2c2 the globe turned to the journey area (no animation), and still does not rotate', Math.abs(s.g.view.lat - (bb.south + bb.north) / 2) < 0.5 && Math.abs(s.g.view.lng - (bb.west + bb.east) / 2) < 0.5 && s.g.autoRotate === false, s.g.view);
    // the marker is on the last recorded fix at or before the replay time; only the past is drawn
    for (const [tag, at] of [['on a fix', D.t[500]], ['between fixes', D.t[500] + Math.floor((D.t[501] - D.t[500]) / 2)], ['one second before the next fix', D.t[501] - 1], ['the last fix', D.t[N - 1]]]) {
      await page.evaluate(x => ME.journey.seek(x), at); s = await state(page); const k = lastAt(D.t, at), xyz = await coordsOf(page, D.lat[k], D.lon[k]);
      ok(`2d ${tag}: the marker is exactly on the last recorded fix at or before the replay time`, s.i === k && s.fixTime === D.t[k] && near(s.objects.marker, xyz) && near(s.objects.fixXYZ, xyz), { i: s.i, k });
      ok(`2e ${tag}: only the past is drawn (fix marks to this fix; line segments joined so far)`, s.objects.fixesShown === k + 1 && s.objects.lineShown === joinsTo(D, RULE, k), [s.objects.fixesShown, k + 1, s.objects.lineShown, joinsTo(D, RULE, k)]); }
    await page.evaluate(x => ME.journey.seek(x), D.t[10] + 3661); s = await state(page); const k10 = lastAt(D.t, D.t[10] + 3661), age = D.t[10] + 3661 - D.t[k10];
    ok('2f the bar gives the replay time, the fix time and its age to the second, in UTC', s.bar.includes(`Replay time (recorded) ${utc(D.t[10] + 3661)}`) && s.bar.includes(`Last recorded fix ${utc(D.t[k10])}`) && /\d+ (min|s|h)/.test(s.bar) && s.objects.fixesShown === k10 + 1, [s.bar, age]);
    ok('2g the bar\'s note speaks of the backdrop, not of other layers; the line rule is stated as Mother Earth\'s', /The backdrop keeps its own date; it is not matched to this journey\./.test(s.note) && !/Other layers/.test(s.note) && /This is a display rule, not part of the study\./.test(s.rule), [s.note, s.rule]);
    // keyboard on the slider
    await page.evaluate(x => ME.journey.seek(x), D.t[100]); await page.focus('#replay-range'); await page.keyboard.press('ArrowRight'); s = await state(page); const a1 = s.i; await page.keyboard.press('ArrowLeft'); await page.keyboard.press('ArrowLeft'); s = await state(page); const a2 = s.i;
    await page.keyboard.press('End'); s = await state(page); const a3 = s.i; await page.keyboard.press('Home'); s = await state(page);
    ok('2h keyboard on the slider: arrows step from fix to fix, End and Home go to the last and first fix', a1 === 101 && a2 === 99 && a3 === N - 1 && s.i === 0, [a1, a2, a3, s.i]);
    // playback
    await page.evaluate(x => { ME.journey.setSpeed(604800 * 8); ME.journey.seek(x); }, D.t[N - 1] - 86400 * 3); await page.click('#replay-play'); await page.waitForFunction(() => !ME.journey.state().playing, null, { timeout: 30000 }); s = await state(page);
    ok('2i play runs to the last recorded fix, stops there and says the record ends', s.i === N - 1 && s.rt === D.t[N - 1] && s.play === 'Play' && /Last recorded fix: tracking record ends here/.test(s.bar), s.bar);
    ok('2j no page error', errs.length === 0, errs);
    // ===== off (T7)
    await page.click(tgl(Z)); await settle(page, null, 'off'); s = await state(page);
    ok('4a switching the shown journey off: every switch off, nothing on the globe, the bar hidden, announced', checked(s).length === 0 && s.scene === 0 && s.barHidden && s.objects === null && s.say === 'Plains zebra switched off.' && s.switches[Z].state === 'off' && s.focus === 'tgl-' + Z, s);
    await on(page, SH); s = await state(page);
    ok('4b the next journey starts at its own first fix: no replay time is carried over', s.rt === JOUR[SH].d.t[0] && s.i === 0 && s.playing === false, [s.rt, JOUR[SH].d.t[0]]);
    await ctx.close(); }

  // ===== 3. Exclusivity for every ordered pair (T5)
  if (want(3)) { reset(); const { ctx, page, errs } = await open(browser);
    for (const A of IDS) for (const B of IDS) { if (A === B) continue; const s0 = await state(page); if (s0.choice !== A) { await page.click(tgl(A)); await settle(page, A); }
      await page.evaluate(() => { ME.journey.setSpeed(3600); ME.journey.play(); }); await page.focus(tgl(B)); await page.keyboard.press('Enter');
      const mid = await state(page);                                                 // straight after the press, before B has loaded
      await settle(page, B); await page.waitForTimeout(150); const s = await state(page), tag = `${NAME[A]} → ${NAME[B]}`;
      ok(`3a ${tag}: exactly one switch is on (the new one); the old journey's objects are gone and the new one's are there`, checked(s).join() === B && s.scene === 3 && s.n === JOUR[B].d.t.length && s.switches[A].state === 'off' && s.switches[A].checked === 'false', { ck: checked(s), scene: s.scene, n: s.n });
      ok(`3b ${tag}: straight after the press the old switch already reads off and the new one on, the old journey's objects are already gone and its replay has stopped`, mid.switches[A].checked === 'false' && mid.switches[B].checked === 'true' && checked(mid).length === 1 && (mid.status === 'ready' ? mid.n === JOUR[B].d.t.length : mid.scene === 0) && mid.playing === false, { sw: mid.switches, scene: mid.scene, status: mid.status, playing: mid.playing });
      ok(`3c ${tag}: the old replay stopped; the new one is paused at its own start; focus stayed on the pressed switch`, s.playing === false && s.rt === startOf(B) && s.focus === 'tgl-' + B, [s.playing, s.rt, s.focus]);
      ok(`3d ${tag}: announced once as a change and once as shown`, new RegExp(`^${NAME[B]} shown\\.`).test(s.say) && (mid.say === `${NAME[A]} switched off. ${NAME[B]} loading.` || new RegExp(`^${NAME[B]} shown\\.`).test(mid.say)), [mid.say, s.say]); }
    ok('3e no page error', errs.length === 0, errs); await ctx.close(); }

  // ===== 5. Races (T6)
  if (want(5)) { reset(); const { ctx, page, errs, failedReqs } = await open(browser);
    // A loading (held) → B: A's answer arrives late
    let g = gate(); S.over[JOUR[Z].j.file] = { hold: g.p }; await page.click(tgl(Z)); await settle(page, Z, 'loading'); await page.waitForFunction(f => true, null); await page.waitForTimeout(300);
    await page.click(tgl(SH)); await settle(page, SH); const before = await state(page); g.go(); delete S.over[JOUR[Z].j.file]; await page.waitForTimeout(700); let s = await state(page);
    ok('5a a superseded answer draws nothing: the first journey\'s late answer changes nothing (still only the second, three objects)', checked(s).join() === SH && s.scene === 3 && s.n === JOUR[SH].d.t.length && before.scene === 3 && s.choice === SH, { scene: s.scene, n: s.n, choice: s.choice });
    ok('5b the superseded request itself was aborted', failedReqs.some(f => f[0] === JOUR[Z].j.file && /ERR_ABORTED/.test(f[1])), failedReqs);
    await page.click(tgl(SH)); await settle(page, null, 'off');
    // on then off while loading
    g = gate(); S.over[JOUR[W].j.file] = { hold: g.p }; await page.click(tgl(W)); await settle(page, W, 'loading'); await page.waitForTimeout(300); await page.click(tgl(W)); await settle(page, null, 'off'); await page.waitForTimeout(300); const abortedW = failedReqs.some(f => f[0] === JOUR[W].j.file && /ERR_ABORTED/.test(f[1]));
    g.go(); delete S.over[JOUR[W].j.file]; await page.waitForTimeout(700); s = await state(page);
    ok('5c on then off while loading: nothing is drawn when the answer arrives; every switch is off; switching off is not reported as a failure', checked(s).length === 0 && s.scene === 0 && s.barHidden && s.choice === null && Object.keys(s.err).length === 0 && s.switches[W].state === 'off' && s.switches[W].retry === false && s.say === 'False killer whale switched off.', { scene: s.scene, ck: checked(s), err: s.err, say: s.say });
    ok('5g switching off while loading aborts the request itself, before the server answers', abortedW, failedReqs);
    // A → B → A
    await page.click(tgl(Z)); await page.click(tgl(SH)); await page.click(tgl(Z)); await settle(page, Z); await page.waitForTimeout(400); s = await state(page);
    ok('5d A, B, A in quick succession: the last pressed (A) is the one shown, once', checked(s).join() === Z && s.scene === 3 && s.n === JOUR[Z].d.t.length, { ck: checked(s), scene: s.scene, n: s.n });
    await page.click(tgl(Z)); await settle(page, null, 'off');
    // three in a row on a slowed network, checking the switches after each press
    const TRIO = [Z, SH, BIRD], gs = TRIO.map(() => gate()); TRIO.forEach((id, i) => { S.over[JOUR[id].j.file] = { hold: gs[i].p }; }); const after = [];
    for (const id of TRIO) { await page.click(tgl(id)); after.push(checked(await state(page))); }
    gs[0].go(); await page.waitForTimeout(300); gs[1].go(); await page.waitForTimeout(300); const midScene = (await state(page)).scene; gs[2].go(); TRIO.forEach(id => delete S.over[JOUR[id].j.file]); await settle(page, BIRD); await page.waitForTimeout(300); s = await state(page);
    ok('5e three pressed in a row on a slow connection: exactly one switch on after each press; only the last is ever drawn', after.every((c, i) => c.join() === TRIO[i]) && midScene === 0 && checked(s).join() === BIRD && s.scene === 3 && s.n === JOUR[BIRD].d.t.length, { after, midScene, scene: s.scene });
    ok('5f after the races: no replay is running and no page error', s.playing === false && errs.length === 0, errs);
    await ctx.close(); }

  // ===== 6. Failure (T8 with §A7): local to a journey, or global for the shared list
  if (want(6)) { reset(); const { ctx, page, errs } = await open(browser); const UNV = 'Journey file could not be verified. Nothing is drawn.', FAILED = 'The journey file could not be loaded. Nothing is drawn.';
    await on(page, Z); S.over[JOUR[SH].j.file] = { status: 500 }; await page.focus(tgl(SH)); await page.keyboard.press('Space'); await done(page); await page.waitForTimeout(200); let s = await state(page);
    ok('6a a journey that fails to load returns to off; its error and Retry are on its own row; the earlier journey is NOT brought back', checked(s).length === 0 && s.scene === 0 && s.barHidden && s.switches[SH].state === 'not shown' && s.switches[SH].obs === FAILED && s.switches[SH].retry === true && s.switches[Z].retry === false && s.switches[Z].state === 'off' && s.switches[W].retry === false && s.integrity === null, s.switches);
    ok('6b the failure is announced once and focus stays on the pressed switch', s.say === `White shark could not be shown. ${FAILED}` && s.focus === 'tgl-' + SH, [s.say, s.focus]);
    await on(page, W); s = await state(page);
    ok('6c another verified journey can still be shown; the failed one keeps its error and Retry', checked(s).join() === W && s.scene === 3 && s.switches[SH].state === 'not shown' && s.switches[SH].retry === true, s.switches);
    delete S.over[JOUR[SH].j.file]; await page.click(`.an-sw[data-journey="${SH}"] [data-f="sw-retry"]`); await settle(page, SH); s = await state(page);
    ok('6d Retry selects that journey through the same path: the other is switched off, this one is shown, its error is cleared', checked(s).join() === SH && s.scene === 3 && s.n === JOUR[SH].d.t.length && s.switches[SH].retry === false && s.switches[W].state === 'off' && Object.keys(s.err).length === 0, s.switches);
    await page.click(tgl(SH)); await done(page);
    // a display file with one digit changed
    const bad = Buffer.from(real(JOUR[Z].j.file)); bad[bad.length - 40] = bad[bad.length - 40] === 0x31 ? 0x32 : 0x31; S.over[JOUR[Z].j.file] = { body: bad }; await page.click(tgl(Z)); await done(page); s = await state(page);
    ok('6e a display file with one digit changed: not verified, nothing drawn, said on that row only', s.scene === 0 && checked(s).length === 0 && s.switches[Z].obs === UNV && s.switches[Z].state === 'not shown' && s.integrity === null && /display file does not match/.test(s.err[Z].detail), s.err);
    delete S.over[JOUR[Z].j.file];
    // a manifest that differs from the list's checksum
    const mb = Buffer.from(JSON.stringify({ ...JOUR[SH].m, title: 'changed' })); S.over[JOUR[SH].e.manifest] = { body: mb }; S.log = []; await page.click(tgl(SH)); await done(page); s = await state(page);
    ok('6f a manifest that differs from the journey list: not verified, nothing drawn, its display file is never requested, said on that row only', s.scene === 0 && s.switches[SH].obs === UNV && !S.log.includes(JOUR[SH].j.file) && s.integrity === null && /manifest does not match/.test(s.err[SH].detail), [s.err, S.log]);
    delete S.over[JOUR[SH].e.manifest]; await ctx.close();
    // a file whose checksums all match but whose fix times are out of order (fixture with its own pinned list)
    reset(); S.fx = fixture(Z, d => { const x = d.t[5]; d.t[5] = d.t[6]; d.t[6] = x; }); { const o = await open(browser); await o.page.click(tgl(Z)); await done(o.page); const s2 = await state(o.page);
      ok('6g a file with matching checksums whose fix times are out of order: refused, nothing drawn', s2.scene === 0 && s2.switches[Z].obs === UNV && /whole seconds in increasing order/.test(s2.err[Z].detail), s2.err); await o.ctx.close(); }
    // the shared journey list
    reset(); { const o = await open(browser); await on(o.page, Z); const badCat = Buffer.from(CAT.toString().replace('"schema": 1', '"schema": 1 ')); S.cat = badCat; S.log = []; await o.page.click(tgl(W)); await done(o.page); await o.page.waitForTimeout(200); let s3 = await state(o.page);
      ok('6h a journey list that does not verify is ONE error for the whole group: no row carries it, every switch is off, nothing is drawn, no manifest or display file is requested after it', s3.integrity === 'The list of journeys could not be verified. No journey can be shown until it verifies.' && IDS.every(id => s3.switches[id].state === 'off' && s3.switches[id].retry === false) && checked(s3).length === 0 && s3.scene === 0 && Object.keys(s3.err).length === 0 && S.log.every(n => /catalog/.test(n)), [s3.integrity, s3.switches, S.log]);
      const cards = await o.page.evaluate(() => [...document.querySelectorAll('.an-study')].map(c => !c.querySelector('[data-f="facts"]').hidden && c.querySelector('[data-f="title"]').textContent.length > 5));
      ok('6i the study cards stay readable under the list error', cards.length === IDS.length && cards.every(Boolean), cards);
      await o.page.click(tgl(SH)); await done(o.page); s3 = await state(o.page);
      ok('6j while the list does not verify, no journey can be switched on (the check is not bypassed)', s3.scene === 0 && checked(s3).length === 0 && s3.integrity !== null, s3.integrity);
      await o.page.click('#an-integrity-retry'); await o.page.waitForTimeout(500); s3 = await state(o.page); const still = s3.integrity !== null;
      S.cat = null; await o.page.click('#an-integrity-retry'); await o.page.waitForFunction(() => document.getElementById('an-integrity').hidden, null, { timeout: 15000 }); s3 = await state(o.page);
      ok('6k the group\'s Retry checks the list alone: still failing while it is bad; cleared once a valid list is served; it switches nothing on', still && s3.integrity === null && checked(s3).length === 0 && s3.scene === 0, [still, s3.integrity]);
      await on(o.page, SH); s3 = await state(o.page); ok('6l after the list verifies, a journey can be shown', checked(s3).join() === SH && s3.scene === 3, s3.switches);
      ok('6m no page error in the failure paths', o.errs.length === 0 && errs.length === 0, [o.errs, errs]); await o.ctx.close(); } }

  // ===== 7. Keyboard, focus and announcements (T9, T10)
  if (want(7)) { reset(); const { ctx, page } = await open(browser);
    await page.focus('#an-panel'); await page.evaluate(() => document.querySelector('.an-preview').closest('p').querySelector('a').focus()); const order = [];
    for (let i = 0; i < 60 && order.filter(x => /^tgl-/.test(x)).length < IDS.length; i++) { await page.keyboard.press('Tab'); order.push(await page.evaluate(() => document.activeElement.id || document.activeElement.tagName)); }
    ok('7a Tab reaches each switch, in the order shown', order.filter(x => /^tgl-/.test(x)).join() === IDS.map(id => 'tgl-' + id).join(), order);
    await page.focus(tgl(Z)); await page.keyboard.press('Space'); await settle(page, Z); let s = await state(page); const a = s.focus === 'tgl-' + Z && checked(s).join() === Z;
    await page.focus(tgl(SH)); await page.keyboard.press('Enter'); await settle(page, SH); s = await state(page); const b = s.focus === 'tgl-' + SH && checked(s).join() === SH;
    await page.keyboard.press('Space'); await settle(page, null, 'off'); s = await state(page);
    ok('7b Space and Enter operate a switch; focus stays on it through loading, and when it switched another off; Space switches it off again', a && b && s.focus === 'tgl-' + SH && checked(s).length === 0, [a, b, s.focus]);
    const arrows = await page.evaluate(async () => { const el = document.activeElement.id; document.activeElement.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowDown', bubbles: true })); return [el, document.activeElement.id, ME.journey.state().choice]; });
    ok('7c arrow keys do not move between switches or change them (no radio behaviour)', arrows[0] === arrows[1] && arrows[2] === null, arrows);
    const live = await page.evaluate(() => ({ say: document.getElementById('an-say').getAttribute('aria-live'), obsLive: [...document.querySelectorAll('.an-sw [data-f="sw-obs"]')].map(e => e.getAttribute('aria-live')), integ: document.getElementById('an-integrity').getAttribute('role') }));
    ok('7d one polite live region carries the announcements; the rows themselves are not live (no duplicate speech)', live.say === 'polite' && live.obsLive.every(x => x === null) && live.integ === null, live);
    await on(page, Z); const said = (await state(page)).say; await page.evaluate(() => { ME.journey.setSpeed(3600); ME.journey.play(); }); await page.waitForTimeout(700); s = await state(page);
    ok('7e playback does not announce on every frame: the announcement is unchanged while the replay runs', s.playing === true && s.say === said && s.rt > JOUR[Z].d.t[0], [s.say, s.rt]);
    const names = await page.evaluate(() => [...document.querySelectorAll('button.an-tgl[data-journey]')].map(b => b.textContent.trim())); await page.click(tgl(Z)); await settle(page, null, 'off'); const names2 = await page.evaluate(() => [...document.querySelectorAll('button.an-tgl[data-journey]')].map(b => b.textContent.trim()));
    ok('7f a switch\'s label never changes with its state', names.join('|') === names2.join('|') && names.length === IDS.length, [names, names2]);
    await ctx.close(); }

  // ===== 8. Links to one journey (T11)
  if (want(8)) { reset(); S.log = []; const { ctx, page } = await open(browser, undefined, '#journey=' + SH); await page.waitForTimeout(500); let s = await state(page);
    ok('8a animals.html#journey=<id> focuses that journey\'s switch and switches nothing on; no display file is requested', s.focus === 'tgl-' + SH && checked(s).length === 0 && s.scene === 0 && s.choice === null && !S.log.some(n => IDS.some(id => n === JOUR[id].j.file)), [s.focus, checked(s), S.log]);
    await page.click(`#${W} a.an-go`); await page.waitForTimeout(400); s = await state(page);
    ok('8b a study card\'s link moves focus to that journey\'s switch and switches nothing on', s.focus === 'tgl-' + W && checked(s).length === 0 && s.scene === 0, [s.focus, checked(s)]);
    const inView = await page.evaluate(id => { const r = document.getElementById(id).getBoundingClientRect(); return r.top >= 0 && r.bottom <= innerHeight; }, 'tgl-' + W); ok('8c the switch is brought into view', inView);
    await ctx.close(); const o = await open(browser, undefined, '#journey=no-such-animal'); s = await state(o.page);
    ok('8d an unknown id does nothing', !/^tgl-/.test(s.focus || '') && checked(s).length === 0 && s.scene === 0, s.focus);
    const links = await o.page.evaluate(() => [...document.querySelectorAll('a')].map(a => a.getAttribute('href')).filter(h => /index\.html#journey/.test(h || ''))); ok('8e no link points at the retired index.html#journey address', links.length === 0, links);
    await o.ctx.close(); }

  // ===== 9. Leaving, returning, hidden tab, resize (T14)
  if (want(9)) { reset(); const { ctx, page } = await open(browser); await on(page, Z); await page.evaluate(() => { ME.journey.setSpeed(3600); ME.journey.play(); });
    await page.evaluate(() => window.dispatchEvent(new PageTransitionEvent('pagehide', { persisted: true }))); await page.waitForTimeout(200); let s = await state(page);
    ok('9a leaving the page (pagehide): the journey is switched off, nothing is drawn, no replay runs', s.choice === null && s.scene === 0 && s.playing === false && checked(s).length === 0, s.switches);
    await on(page, SH); await page.evaluate(() => window.dispatchEvent(new PageTransitionEvent('pageshow', { persisted: true }))); await page.waitForTimeout(200); s = await state(page);
    ok('9b a page restored from the browser\'s kept copy (pageshow, persisted) comes back with nothing on', s.choice === null && s.scene === 0 && checked(s).length === 0, s.switches);
    await on(page, Z); await page.evaluate(() => { ME.journey.setSpeed(3600); ME.journey.play(); }); await page.waitForTimeout(200);
    await page.evaluate(() => { Object.defineProperty(document, 'hidden', { configurable: true, get: () => true }); document.dispatchEvent(new Event('visibilitychange')); }); await page.waitForTimeout(200); s = await state(page);
    ok('9c a hidden tab pauses playback and keeps the journey', s.playing === false && s.choice === Z && s.scene === 3, [s.playing, s.choice]);
    await page.evaluate(() => { Object.defineProperty(document, 'hidden', { configurable: true, get: () => false }); document.dispatchEvent(new Event('visibilitychange')); });
    await page.setViewportSize({ width: 800, height: 700 }); await page.waitForTimeout(600); const r1 = await page.evaluate(() => { const b = document.getElementById('an-globe').getBoundingClientRect(), g = ME.animalsGlobe.state().size; return [Math.round(b.width), Math.round(b.height), g[0], g[1]]; });
    await page.setViewportSize({ width: 700, height: 1000 }); await page.waitForTimeout(600); const r2 = await page.evaluate(() => { const b = document.getElementById('an-globe').getBoundingClientRect(), g = ME.animalsGlobe.state().size; return [Math.round(b.width), Math.round(b.height), g[0], g[1]]; }); s = await state(page);
    ok('9d resize and a turn to portrait: the globe follows its box, the journey stays shown, the controls still work', Math.abs(r1[0] - r1[2]) <= 1 && Math.abs(r1[1] - r1[3]) <= 1 && Math.abs(r2[0] - r2[2]) <= 1 && Math.abs(r2[1] - r2[3]) <= 1 && s.scene === 3 && s.choice === Z, [r1, r2]);
    await page.click('#replay-play'); await page.waitForTimeout(300); s = await state(page); ok('9e after the resize Play still starts the replay', s.playing === true, s.playing);
    await ctx.close(); }

  // ===== 10. The backdrop and its fallback (T15 with §A7)
  if (want(10)) { for (const mode of ['fail', 'xml']) { reset(); const { ctx, page, errs } = await open(browser, undefined, '', { img: mode }); let s = await state(page);
      ok(`10a imagery ${mode === 'fail' ? 'request fails' : 'answers with something that is not a picture'}: a plain globe with the coastline outline; the coastline file is requested now`, s.g.globe === 'ok' && s.g.backdrop === 'plain' && s.g.coast === 'ready' && s.g.coastInScene && s.g.coastSegs > 1000 && S.log.includes('coast-50m.bin'), s.g);
      ok(`10b ${mode}: the line says the satellite backdrop is unavailable and never names a picture date`, /^Satellite backdrop unavailable\./.test(s.g.note) && !/satellite imagery for/.test(s.g.note) && !/\d{2} [A-Z][a-z]{2} \d{4}/.test(s.g.note), s.g.note);
      await on(page, Z); s = await state(page); ok(`10c ${mode}: journeys stay usable on the plain globe`, s.scene === 3 && checked(s).join() === Z && errs.length === 0, [s.scene, errs]); await ctx.close(); }
    reset(); const o = await open(browser, undefined, '', { img: 'hang', noWait: true }); await o.page.waitForTimeout(600); let s = await state(o.page);
    ok('10d while the picture is still on its way the line says loading, and a journey can already be shown', s.g.backdrop === 'loading' && /^Backdrop: loading/.test(s.g.note), s.g.note); await on(o.page, SH); s = await state(o.page); ok('10e journey shown while the backdrop is still loading', s.scene === 3 && checked(s).join() === SH, s.scene);
    await o.ctx.close();
    reset(); const c = await open(browser, undefined, '', { img: 'fail', pre: ctx => ctx.route('**/assets/coast-50m.bin*', r => r.abort()) }); await c.page.waitForFunction(() => ME.animalsGlobe.state().coast === 'failed', null, { timeout: 15000 }); s = await state(c.page);
    ok('10f picture and coastline both unavailable: a plain globe, said so, journeys still offered', s.g.backdrop === 'plain' && /coastline outline could not be loaded either/.test(s.g.note) && s.switches[Z].disabled === null, s.g.note); await c.ctx.close(); }

  // ===== 11. No usable globe (T17 with §A7)
  if (want(11)) { reset(); const noGL = ctx => ctx.addInitScript(() => { const g = HTMLCanvasElement.prototype.getContext; HTMLCanvasElement.prototype.getContext = function (t, ...a) { return /webgl/.test(t) ? null : g.call(this, t, ...a); }; });
    const o = await open(browser, undefined, '', { pre: noGL }); let s = await state(o.page);
    const box = await o.page.evaluate(() => document.getElementById('an-globe').textContent);
    ok('11a no WebGL: the globe box says so in plain words; every switch is marked unavailable and its row says why; nothing is on', s.g.globe === 'failed' && /The globe needs 3-D graphics/.test(box) && /study details, sources and licences below remain available/.test(box) && IDS.every(id => s.switches[id].disabled === 'true' && /needs the 3-D globe/.test(s.switches[id].obs)) && checked(s).length === 0 && s.g.noteHidden === true, [box, s.switches]);
    S.log = []; await o.page.click(tgl(Z), { force: true }); await o.page.waitForTimeout(400); s = await state(o.page);
    ok('11b pressing an unavailable switch switches nothing on, requests nothing and says why', checked(s).length === 0 && s.choice === null && S.log.length === 0 && /Plains zebra cannot be shown\. The journey needs the 3-D globe/.test(s.say) && s.focus === 'tgl-' + Z, [s.say, S.log]);
    const cards = await o.page.evaluate(() => [...document.querySelectorAll('.an-study')].map(c => [c.querySelector('[data-f="state"]').textContent, !c.querySelector('[data-f="facts"]').hidden, c.querySelector('[data-f="lic"]').textContent.length > 3]));
    ok('11c the study cards, sources and licences are still shown', cards.length === IDS.length && cards.every(c => /verified/.test(c[0]) && c[1] && c[2]), cards); ok('11d no page error without WebGL', o.errs.length === 0, o.errs); await o.ctx.close();
    reset(); const l = await open(browser, undefined, '', { lib: false }); s = await state(l.page); const box2 = await l.page.evaluate(() => document.getElementById('an-globe').textContent);
    ok('11e the globe library failed to load: the same plain message with a Diagnostics note; switches unavailable; cards readable', s.g.globe === 'failed' && /could not start in this browser/.test(box2) && /Diagnostics/.test(box2) && IDS.every(id => s.switches[id].disabled === 'true') && checked(s).length === 0, [box2, s.g]); await l.ctx.close();
    reset(); const k = await open(browser); await on(k.page, Z); await k.page.evaluate(() => { ME.journey.setSpeed(3600); ME.journey.play(); });
    const lost = await k.page.evaluate(() => { const cv = document.querySelector('#an-globe canvas'), gl = cv.getContext('webgl2') || cv.getContext('webgl'), ext = gl && gl.getExtension('WEBGL_lose_context'); if (ext) { ext.loseContext(); return 'ext'; } cv.dispatchEvent(new Event('webglcontextlost', { cancelable: true })); return 'event'; });
    await k.page.waitForFunction(() => ME.animalsGlobe.state().globe === 'lost', null, { timeout: 15000 }); await k.page.waitForTimeout(300); s = await state(k.page);
    ok(`11f graphics context lost after load (${lost}): the journey is switched off, the replay stops, the switches say the globe stopped, the line under the globe says so`, s.choice === null && s.playing === false && checked(s).length === 0 && IDS.every(id => s.switches[id].disabled === 'true' && /lost its graphics context/.test(s.switches[id].obs)) && /lost its graphics context/.test(s.g.note) && /Plains zebra switched off\./.test(s.say), [s.say, s.g.note, s.switches]);
    await k.ctx.close(); }

  // ===== 12. The old journeys' observable behaviour (T18): line rule, Argos classes and join flags, time zone
  if (want(12)) { reset(); const t0 = 1193299200, times = [0, 3600, 3600 + 10800, 3600 + 10800 + 10801, 3600 + 10800 + 10801 + 3600].map(x => t0 + x);
    S.fx = fixture(Z, (d, m, jr) => { d.n = times.length; d.t = times; d.lat = times.map((_, i) => -20 + i * 0.01); d.lon = times.map((_, i) => 24 + i * 0.01); d.id = 'fx'; jr.fixes = times.length; jr.first_fix_s = times[0]; jr.last_fix_s = times[times.length - 1]; jr.bbox = { south: -21, north: -19, west: 23, east: 25 }; });
    { const o = await open(browser); await on(o.page, Z); await o.page.evaluate(x => ME.journey.seek(x), times[times.length - 1]); let s = await state(o.page);
      ok('12a line rule (fixture): fixes exactly 3 h apart are joined; 3 h 1 s apart are not', s.objects.segments === 3 && s.objects.lineShown === 3 && s.n === 5, s.objects);
      await o.page.evaluate(x => ME.journey.seek(x), times[2] + 60); s = await state(o.page); ok('12b the gap is said on the bar: no fix was recorded for 3 h 0 min 1 s after it', /No fix was recorded for 3 h 0 min 1 s after it/.test(s.bar), s.bar); await o.ctx.close(); }
    reset(); const o = await open(browser);
    for (const id of [SH, W]) { const T = JOUR[id], D = T.d, RULE = T.m.gap_rule.max_join_seconds; await on(o.page, id); await o.page.evaluate(x => ME.journey.seek(x), D.t[D.t.length - 1]); let s = await state(o.page);
      const flagged = D.j.reduce((a, b) => a + b, 0), byTime = D.t.filter((t, i) => i && t - D.t[i - 1] <= RULE).length;
      ok(`12c ${NAME[id]}: the line has exactly the steps the build allowed (join flags)${id === SH ? ', fewer than time alone would join' : ''}`, s.objects.segments === flagged && flagged === T.j.steps_joined && (id === SH ? flagged < byTime : flagged <= byTime), [s.objects.segments, flagged, byTime]);
      ok(`12d ${NAME[id]}: the bar gives the Argos class of the fix and speaks of displayed fixes`, /Argos class [0-3AB] \(/.test(s.bar) && /Last displayed fix: displayed record ends here/.test(s.bar) && !/recorded fix/i.test(s.bar.replace('Replay time (recorded)', '')), s.bar);
      const k = Math.floor(D.t.length / 2), xyz = await coordsOf(o.page, D.lat[k], D.lon[k]); await o.page.evaluate(x => ME.journey.seek(x), D.t[k]); s = await state(o.page);
      ok(`12e ${NAME[id]}: the marker is on the displayed fix; its class is the file's`, near(s.objects.marker, xyz) && s.cls === D.lc[k] && s.objects.fixesShown === k + 1 && s.objects.lineShown === joinsTo(D, RULE, k), [s.cls, D.lc[k]]);
      ok(`12f ${NAME[id]}: the row carries the manifest's own sentences`, s.switches[id].obs.includes(T.m.card.shown) && s.switches[id].obs.includes(T.m.card.not_route), s.switches[id].obs.slice(0, 200));
      const n = D.t.length, clsWords = c => T.m.class_meanings[c] === 'no estimate' ? 'no error estimate' : 'nominal error ' + T.m.class_meanings[c];
      const words = [], sample = [...Array(n).keys()].filter(q => q % 9 === 0 || q === n - 1 || (q < n - 1 && D.t[q + 1] - D.t[q] > RULE)).slice(0, 220);
      for (const i of sample) { await o.page.evaluate(x => ME.journey.seek(x), D.t[i] + (i < n - 1 ? 1 : 0)); const bt = (await state(o.page)).bar; if (/was recorded|tracking record|recorded fix\b/i.test(bt.replace('Replay time (recorded)', ''))) words.push([i, bt]); }
      ok(`12h ${NAME[id]}: at ${sample.length} sampled fixes, every ninth and every gap, the bar never says a fix "was recorded", "recorded fix" or "tracking record" (it says displayed)`, words.length === 0 && sample.length > 20, words.slice(0, 2));
      const refused = []; for (let q = 1; q < n; q++) if (D.t[q] - D.t[q - 1] <= RULE && D.j[q] === 0) refused.push(q);
      const picks = [1, 2, Math.floor(n / 3), Math.floor(n / 2), n - 2, n - 1].concat(refused.slice(0, 2)), bad = [];
      for (const i of picks) { await o.page.evaluate(x => ME.journey.seek(x), D.t[i]); const q = await state(o.page);
        if (q.i !== i || q.objects.fixesShown !== i + 1 || q.objects.lineShown !== joinsTo(D, RULE, i) || q.cls !== D.lc[i] || !q.bar.includes(`Argos class ${D.lc[i]} (${clsWords(D.lc[i])})`) || !near(q.objects.marker, q.objects.fixXYZ)) bad.push([i, q.i, q.objects.lineShown, joinsTo(D, RULE, i), q.cls]); }
      ok(`12i ${NAME[id]}: at ${picks.length} replay times the marker is on the right fix, the class shown is that fix's, and exactly the build's joined steps up to then are drawn`, bad.length === 0, bad);
      ok(`12j ${NAME[id]}: steps within the time limit that the build refused for land: ${refused.length}, as the manifest says`, refused.length === T.j.steps_refused_for_land, [refused.length, T.j.steps_refused_for_land]);
      await o.page.evaluate(x => ME.journey.seek(x), D.t[n - 1]); const endBar = (await state(o.page)).bar;
      ok(`12k ${NAME[id]}: at the last displayed fix the bar says the DISPLAYED record ends here`, endBar === `Replay time (recorded) ${utc(D.t[n - 1])} · Last displayed fix: displayed record ends here, ${utc(D.t[n - 1])} · Argos class ${D.lc[n - 1]} (${clsWords(D.lc[n - 1])})`, endBar);
      if (id === SH) { await o.page.evaluate(x => ME.journey.seek(x), D.t[24]); const g24 = (await state(o.page)).bar;
        ok("12l GPT's earlier case, shark index 24: the bar says no fix is DISPLAYED for 18 h 43 min 44 s", utc(D.t[24]) === '17 May 2012 08:09:01 UTC' && utc(D.t[25]) === '18 May 2012 02:52:45 UTC' && g24 === `Replay time (recorded) 17 May 2012 08:09:01 UTC · Last displayed fix 17 May 2012 08:09:01 UTC, at this time · Argos class ${D.lc[24]} (${clsWords(D.lc[24])}) · No fix is displayed for 18 h 43 min 44 s after it`, g24); }
      if (id === W) ok("12m GPT's earlier case, whale end: the displayed record ends 12 Feb 2014 14:51:34 UTC and the bar does not call it the end of the tracking record", /Last displayed fix: displayed record ends here, 12 Feb 2014 14:51:34 UTC/.test(endBar) && !/tracking record/.test(endBar), endBar); }
    await o.ctx.close();
    for (const tz of ['Pacific/Auckland', 'America/Los_Angeles']) { reset(); const z = await open(browser, undefined, '', { extra: { timezoneId: tz, locale: 'en-US' } }); await on(z.page, Z); const s = await state(z.page);
      ok(`12g visitor in ${tz}: times are printed in UTC from the source's seconds`, s.bar.includes(utc(JOUR[Z].d.t[0])), s.bar); await z.ctx.close(); } }

  // ===== 13. Earth now is clean (T13 with §A7): baseline = the exact main commit merged into this branch
  if (want(13)) { reset(); const git = a => cp.execFileSync('git', a, { cwd: ROOT, maxBuffer: 64e6, stdio: ['ignore', 'pipe', 'ignore'] }).toString();
    const BASE_DIR = process.env.BASE_DIR || ''; let how = '';
    if (BASE_DIR && fs.existsSync(path.join(BASE_DIR, 'index.html'))) how = 'dir'; else { try { git(['cat-file', '-e', BASE_MAIN + '^{commit}']); how = 'git'; } catch (_) { } }
    const mainFile = f => how === 'dir' ? fs.readFileSync(path.join(BASE_DIR, f), 'utf8') : git(['show', BASE_MAIN + ':' + f]);
    // the Nature context baseline (NC_MAIN): read from NC_DIR or Git; without either, its checks fail closed (13j)
    const NC_DIR = process.env.NC_DIR || ''; let ncHow = '';
    if (NC_DIR && fs.existsSync(path.join(NC_DIR, 'index.html'))) ncHow = 'dir'; else { try { git(['cat-file', '-e', NC_MAIN + '^{commit}']); ncHow = 'git'; } catch (_) { } }
    const ncFile = f => ncHow === 'dir' ? fs.readFileSync(path.join(NC_DIR, f), 'utf8') : git(['show', NC_MAIN + ':' + f]);
    // the organic-soil baseline (SOIL_MAIN): Git only; without it, its checks fail closed (13b, 13c, 13e, 13m, 13n)
    let soilHow = ''; try { git(['cat-file', '-e', SOIL_MAIN + '^{commit}']); soilHow = 'git'; } catch (_) { }
    const soilFile = f => git(['show', SOIL_MAIN + ':' + f]);
    // the Tides navigation baseline (TIDES_MAIN): Git only; without it, its checks fail closed (13b, 13e, 13o, 13p)
    let tidesHow = ''; try { git(['cat-file', '-e', TIDES_MAIN + '^{commit}']); tidesHow = 'git'; } catch (_) { }
    const tidesFile = f => git(['show', TIDES_MAIN + ':' + f]);
    // the Moon height baseline (MH_MAIN): Git only; without it, its checks fail closed (13e moon.html, 13q, 13r, 13s)
    let mhHow = ''; try { git(['cat-file', '-e', MH_MAIN + '^{commit}']); mhHow = 'git'; } catch (_) { }
    const mhFile = f => git(['show', MH_MAIN + ':' + f]);
    // the Moon temperature baseline (DV_MAIN): Git only; without it, its checks fail closed (13e moon.html, 13t, 13u)
    let dvHow = ''; try { git(['cat-file', '-e', DV_MAIN + '^{commit}']); dvHow = 'git'; } catch (_) { }
    const dvFile = f => git(['show', DV_MAIN + ':' + f]);
    // the Moon LROC baseline (LR_MAIN): Git only; without it, its checks fail closed (13e moon.html, 13v, 13w)
    let lrHow = ''; try { git(['cat-file', '-e', LR_MAIN + '^{commit}']); lrHow = 'git'; } catch (_) { }
    const lrFile = f => git(['show', LR_MAIN + ':' + f]);
    // the Sky zoom-out Moon picture baseline (SK_MAIN): Git only; without it, its checks fail closed (13b, 13e sources.html, 13x, 13y, 13z)
    let skHow = ''; try { git(['cat-file', '-e', SK_MAIN + '^{commit}']); skHow = 'git'; } catch (_) { }
    const skFile = f => git(['show', SK_MAIN + ':' + f]);
    // the Moon CRaTER event-count baseline (CR_MAIN): Git only; without it, its checks fail closed (13e moon.html, 13e sources.html (CRaTER), 13aa, 13ab)
    let crHow = ''; try { git(['cat-file', '-e', CR_MAIN + '^{commit}']); crHow = 'git'; } catch (_) { }
    const crFile = f => git(['show', CR_MAIN + ':' + f]);
    // the Moon LEND neutron-record baseline (LE_MAIN): Git only; without it, its checks fail closed (13e moon.html, 13e sources.html (LEND), 13ac, 13ad)
    let leHow = ''; try { git(['cat-file', '-e', LE_MAIN + '^{commit}']); leHow = 'git'; } catch (_) { }
    const leFile = f => git(['show', LE_MAIN + ':' + f]);
    // the Moon LEND readout-rounding baseline (RD_MAIN): Git only; without it, its checks fail closed (13e moon.html (LEND rounding), 13ae, 13af)
    let rdHow = ''; try { git(['cat-file', '-e', RD_MAIN + '^{commit}']); rdHow = 'git'; } catch (_) { }
    const rdFile = f => git(['show', RD_MAIN + ':' + f]);
    const tabL = '    <a href="animals.html" data-view="animals">Animals</a>\n', menuL = '      <li role="none"><a role="menuitem" href="animals.html" data-page="animals">Animals</a></li>\n', hdr = t => (/<header[\s\S]*?<\/header>/.exec(t) || [''])[0];
    // the Animals guarantees on a page, checked on their own: both links once each, and the header equals BASE_MAIN's except those links
    const animalsHead = (b, base) => { const h0 = hdr(base); return { links: b.split(tabL).length === 2 && b.split(menuL).length === 2, header: h0.length > 200 && unwrapPromise(noTides(hdr(b))).replace(tabL, '').replace(menuL, '') === h0 }; };   // 25 Nov 2026: the Tides lines and the promise wrapper set aside too
    if (!how) { fail++; failed.push('13a'); console.log(`NOT RUN  13a–13e: main ${BASE_MAIN.slice(0, 7)} is not available (no Git metadata here and no BASE_DIR). The comparisons with main were not made.`); }
    else { ok(`13a the baseline is main ${BASE_MAIN.slice(0, 7)} (read from ${how === 'dir' ? 'BASE_DIR' : 'Git'})`, true);
      const mainIdx = mainFile('index.html'), idx = served('index.html');
      const strip = t => noTides(t).replace('    <a href="animals.html" data-view="animals">Animals</a>\n', '').replace('      <li role="none"><a role="menuitem" href="animals.html" data-page="animals">Animals</a></li>\n', '').replace(/style\.css\?v=\d+/, 'style.css?v=X');
      // 13b (24 Nov 2026, Nature context): was 'index.html equals main's except the Animals links and the stylesheet version'. The page now
      // carries the Nature context release, so it is held byte-for-byte to NC_MAIN, and the Animals guarantees are checked on their own.
      // 25 Nov 2026 (organic soil): held to SOIL_MAIN instead of NC_MAIN; the Animals guarantees are still checked on their own.
      // 25 Nov 2026 (Tides navigation): held to TIDES_MAIN; SOIL_MAIN's file plus exactly the two Tides lines and the promise wrapper is TIDES_MAIN's.
      // 27 Nov 2026 (Sky zoom-out Moon picture): held to SK_MAIN; with its three additions set aside and the old skyscene.js key put back, it is TIDES_MAIN's.
      if (!soilHow || !tidesHow || !skHow) { fail++; failed.push('13b'); console.log(`NOT RUN  13b: the baseline ${!soilHow ? SOIL_MAIN.slice(0, 7) : !tidesHow ? TIDES_MAIN.slice(0, 7) : SK_MAIN.slice(0, 7)} is not available.`); }
      else { const tf = tidesFile('index.html'), whole = idx === skFile('index.html') && skIdxOk(idx) && noSkIdx(idx) === tf, step = noKey(unwrapPromise(noTides(tf))) === noKey(soilFile('index.html')) && tf.split(TIDES_TAB).length === 2 && tf.split(TIDES_MENU).length === 2 && tf.includes(PROMISE_SPAN[0]), g = animalsHead(idx, mainIdx);
        ok(`13b index.html is byte-identical to the file at the Sky zoom-out Moon picture baseline ${SK_MAIN.slice(0, 7)}, which holds the moonlight.js tag, the new skyscene.js key and the Moon's-picture paragraph once each; with those set aside it is the file at the Tides baseline ${TIDES_MAIN.slice(0, 7)}, which is the organic-soil baseline ${SOIL_MAIN.slice(0, 7)}'s plus exactly the Tides tab, the Tides Menu item, the promise wrapper and the stylesheet key; it carries the Animals tab link and menu link once each; and its header equals main ${BASE_MAIN.slice(0, 7)}'s except those links`, whole && step && g.links && g.header, { whole, step, links: g.links, header: g.header }); }
      const same = ['aircraft.js', 'wind.js', 'nightlights.js', 'dustrgb.js', 'oceanheat.js', 'sky.js', 'arts.js', 'craft.js', 'moonlight.js', 'sunglobe.js', 'phase1/collector-mac.mjs'];   // 26 Nov 2026: 'moonglobe.js' left this list (Moon height; 13q). 27 Nov 2026: 'skyscene.js' left it (Sky zoom-out Moon picture; 13x)
      // 25 Nov 2026 (organic soil): 'layers.js' and 'phase1/bare-earth-ui.test.cjs' left this list; the soil release adds one Layers row and
      // the Bare Earth suite counts it. Both are held to SOIL_MAIN below; the other 13 files stay on BASE_MAIN.
      const SOIL_SAME = ['layers.js', 'phase1/bare-earth-ui.test.cjs'];
      // 23 Nov 2026 (hub-to-main alignment, Chad's decision G-a): 'phase1/worker.js' left this list. Main's hub file is now the DEPLOYED hub
      // (0.6.24), which is not the file at this suite's pinned baseline and never will be again. The hub is protected instead by
      // phase1/hub-alignment.test.mjs, which holds phase1/worker.js to the recorded deployed hash (phase1/DEPLOYED-HUB.json).
      // Every other file in this list, and checks 13a, 13b, 13d and 13e, are unchanged.
      // 24 Nov 2026 (baseline repair): 'timeline.js' left this list, 'timeline.html' left 13e, and 13d no longer judges the stylesheet's
      // body.tl lines. The Timeline releases of 23 and 24 Nov changed all three, as they should. They are held to main at TL_MAIN by
      // 13f to 13i below, so each is still compared with a pinned commit; only the commit differs. Nothing else moved off BASE_MAIN.
      // 24 Nov 2026 (Nature context): 'app.js' left this list. It is held to NC_MAIN by 13k. The other 15 files stay on BASE_MAIN.
      const diff = same.filter(f => { try { return mainFile(f) !== served(f); } catch (_) { return true; } });
      const soilDiff = soilHow ? SOIL_SAME.filter(f => { try { return soilFile(f) !== served(f); } catch (_) { return true; } }) : SOIL_SAME.map(f => f + ' (baseline not available)');
      ok(`13c Earth now's scripts and the collector are byte-identical to main; the Layers panel and the Bare Earth suite are byte-identical to the organic-soil baseline ${SOIL_MAIN.slice(0, 7)} (the hub: see phase1/hub-alignment.test.mjs; timeline.js: 13g; app.js: 13k; moonglobe.js: 13q; skyscene.js: 13x)`, same.length === 11 && !same.includes('app.js') && !same.includes('moonglobe.js') && !same.includes('skyscene.js') && same.includes('moonlight.js') && diff.length === 0 && soilDiff.length === 0, diff.concat(soilDiff));
      if (ncHow) ok(`13k app.js is byte-identical to the file at the Nature context baseline ${NC_MAIN.slice(0, 7)}`, served('app.js') === ncFile('app.js'));
      else { fail++; failed.push('13k'); console.log(`NOT RUN  13k: the Nature context baseline ${NC_MAIN.slice(0, 7)} is not available.`); }
      const css = served('style.css'), mainCss = mainFile('style.css').split('\n'), cur = new Set(css.split('\n')), isTl = l => /body\.tl/.test(l);
      const gone = mainCss.filter(l => !cur.has(l) && !isTl(l)); ok('13d the shared stylesheet is NOT identical to main: every main line is kept except the header rules changed for five tabs (at most 4 lines, listed on failure); the Animals rules are added (the Timeline\'s body.tl lines: 13i)', gone.length <= 4 && gone.every(l => /\.top \.promise|\.tabs a|\.top\{padding/.test(l)) && css.length > mainCss.join('\n').length, gone);
      if (skHow) ok(`13x skyscene.js is byte-identical to the file at the Sky zoom-out Moon picture baseline ${SK_MAIN.slice(0, 7)}`, served('skyscene.js') === skFile('skyscene.js'));
      else { fail++; failed.push('13x'); console.log(`NOT RUN  13x: the Sky zoom-out Moon picture baseline ${SK_MAIN.slice(0, 7)} is not available.`); }
      if (mhHow) ok(`13q moonglobe.js is byte-identical to the file at the Moon height baseline ${MH_MAIN.slice(0, 7)}`, served('moonglobe.js') === mhFile('moonglobe.js'));
      else { fail++; failed.push('13q'); console.log(`NOT RUN  13q: the Moon height baseline ${MH_MAIN.slice(0, 7)} is not available.`); }
      { const bR = served('moon.html'), b = noRound(bR); if (!mhHow) { fail++; failed.push('13e moon.html (height)'); console.log(`NOT RUN  13e moon.html (height): the baseline ${MH_MAIN.slice(0, 7)} is not available.`); }
        else if (!dvHow) { fail++; failed.push('13e moon.html (temperature)'); console.log(`NOT RUN  13e moon.html (temperature): the baseline ${DV_MAIN.slice(0, 7)} is not available.`); }
        else if (!lrHow) { fail++; failed.push('13e moon.html (LROC)'); console.log(`NOT RUN  13e moon.html (LROC): the baseline ${LR_MAIN.slice(0, 7)} is not available.`); }
        else if (!crHow) { fail++; failed.push('13e moon.html (CRaTER)'); console.log(`NOT RUN  13e moon.html (CRaTER): the baseline ${CR_MAIN.slice(0, 7)} is not available.`); }
        else if (!leHow) { fail++; failed.push('13e moon.html (LEND)'); console.log(`NOT RUN  13e moon.html (LEND): the baseline ${LE_MAIN.slice(0, 7)} is not available.`); }
        else if (!rdHow) { fail++; failed.push('13e moon.html (LEND rounding)'); console.log(`NOT RUN  13e moon.html (LEND rounding): the baseline ${RD_MAIN.slice(0, 7)} is not available.`); }
        else { ok(`13e moon.html (LEND rounding) is byte-identical to the file at the LEND readout-rounding baseline ${RD_MAIN.slice(0, 7)}, which holds its new moonsci.js key exactly once and not the old one`, bR === rdFile('moon.html') && roundOk(bR));
          ok(`13e moon.html (LEND) is byte-identical to the file at the Moon neutron-record baseline ${LE_MAIN.slice(0, 7)}, which holds its three buttons, legend and readout, help-line span and Sources line (with its Details link) exactly once each and the two new script and stylesheet keys`, b === leFile('moon.html') && lendOk(b));
          const b0 = noLend(b); ok(`13e moon.html (CRaTER), with the Moon neutron-record additions set aside and the two old keys put back, is byte-identical to the file at the Moon CRaTER baseline ${CR_MAIN.slice(0, 7)}, which holds its stylesheet link, control row and chart panel, Sources line and script tag exactly once each`, b0 === crFile('moon.html') && craterOk(b0)); }
        { const b = noCrater(noLend(noRound(served('moon.html')))); if (mhHow && dvHow && lrHow && crHow && leHow && rdHow) ok(`13e moon.html with the LEND rounding key put back and the Moon neutron-record and CRaTER additions set aside is byte-identical to the file at the Moon LROC baseline ${LR_MAIN.slice(0, 7)}, which holds each of its six additions exactly once; with them set aside it is the Moon temperature baseline ${DV_MAIN.slice(0, 7)}, which holds each temperature and height addition exactly once; with the temperature additions set aside it is the Moon height baseline ${MH_MAIN.slice(0, 7)}`,
          b === lrFile('moon.html') && lrocOk(b) && noLroc(b) === dvFile('moon.html') && tempOk(noLroc(b)) && heightOk(noLroc(b)) && noTemp(noLroc(b)) === mhFile('moon.html')); } }
      for (const pg of ['moon.html', 'sun.html']) { const a = mainFile(pg), b = pg === 'moon.html' ? noHeight(noTemp(noLroc(noCrater(noLend(noRound(served(pg))))))) : served(pg); const sec = /  <h2 id="animals">[\s\S]*?(?=  <h2 id="search">)/, rel = false;      // 24 Nov 2026: sources.html left this loop for the check below (Nature context)
        ok(`13e ${pg} equals main's except the Animals links and the stylesheet version${pg === 'moon.html' ? ' (and the Moon height additions, set aside)' : ''}${rel ? ', and (release) the one added Animals section with its shortcut in the Sections list, which names all six sources and the omitted Low class and never says private preview' : ''}`, strip(rel ? b.replace(sec, '').replace(' · <a href="#animals">Animals</a>', '') : b) === a.replace(/style\.css\?v=\d+/, 'style.css?v=X') && (!rel || (sec.test(b) && b.split(' · <a href="#animals">Animals</a> · <a href="#search">Search</a>').length === 2 && ['10.5441/001/1.f3550b4f', '10.5281/zenodo.5575189', 'ptt id 98364', '10.5441/001/1.3hp3s250', '10.5061/dryad.vx0k6djp7', '10.5066/P1ETBSYE', 'Low-use class'].every(x => b.includes(x)) && !/private preview/i.test(b)))); }
      if (!mhHow) { fail++; failed.push('13e sources.html (height)'); console.log(`NOT RUN  13e sources.html (height): the baseline ${MH_MAIN.slice(0, 7)} is not available.`); }
      else if (!dvHow) { fail++; failed.push('13e sources.html (temperature)'); console.log(`NOT RUN  13e sources.html (temperature): the baseline ${DV_MAIN.slice(0, 7)} is not available.`); }
      else if (!lrHow) { fail++; failed.push('13e sources.html (LROC)'); console.log(`NOT RUN  13e sources.html (LROC): the baseline ${LR_MAIN.slice(0, 7)} is not available.`); }
      else if (!skHow) { fail++; failed.push('13e sources.html (Sky)'); console.log(`NOT RUN  13e sources.html (Sky): the baseline ${SK_MAIN.slice(0, 7)} is not available.`); }
      else if (!crHow) { fail++; failed.push('13e sources.html (CRaTER)'); console.log(`NOT RUN  13e sources.html (CRaTER): the baseline ${CR_MAIN.slice(0, 7)} is not available.`); }
      else if (!leHow) { fail++; failed.push('13e sources.html (LEND)'); console.log(`NOT RUN  13e sources.html (LEND): the baseline ${LE_MAIN.slice(0, 7)} is not available.`); }
      else { const sl0 = served('sources.html'), sc0 = noLeSrc(sl0), sb0 = noCrSrc(sc0), sb = noSkySrc(sb0), sd = noLrocSources(sb);
        ok(`13e sources.html (LEND) is byte-identical to the file at the Moon neutron-record baseline ${LE_MAIN.slice(0, 7)}, which holds one Moon neutron record section after Moon event counts' and before the Sun globe section, with the unresolved-field, conditional-estimate and display-policy wording and both hashes, and its shortcut after Moon event counts'`, sl0 === leFile('sources.html') && lendSourcesOk(sl0));
        ok(`13e sources.html (CRaTER), with the Moon neutron-record additions set aside, is byte-identical to the file at the Moon CRaTER baseline ${CR_MAIN.slice(0, 7)}, which holds one Moon event-count section before the Sun globe section, with the benchmark qualification, and its shortcut after Moon detailed site's`, sc0 === crFile('sources.html') && craterSourcesOk(sc0));
        ok(`13e sources.html (Sky), with the Moon CRaTER additions set aside, is byte-identical to the file at the Sky zoom-out Moon picture baseline ${SK_MAIN.slice(0, 7)}, which holds one "The Moon's picture." paragraph in the Sky zoom-out section and the two added Data path sentences once each`, sb0 === skFile('sources.html') && skySrcOk(sb0));
        ok(`13e sources.html with the Sky zoom-out Moon picture additions set aside is byte-identical to the file at the Moon LROC baseline ${LR_MAIN.slice(0, 7)}, which holds one Moon detailed-site section before the Sun globe section, its shortcut after Moon temperature's, and the two corrected lighting sentences; with those set aside it is the Moon temperature baseline ${DV_MAIN.slice(0, 7)}, which holds one Moon temperature section and its shortcut; with those set aside it is the Moon height baseline ${MH_MAIN.slice(0, 7)}, which holds one Moon height section before the Sun globe section and one shortcut before Tides'`,
        sb === lrFile('sources.html') && lrocSourcesOk(sb) && sd === dvFile('sources.html') && tempSourcesOk(sd) && noTempSources(sd) === mhFile('sources.html') && heightSourcesOk(noTempSources(sd))); }
      // 13e sources.html (24 Nov 2026, Nature context): byte-identical to NC_MAIN, plus every Animals guarantee the old check made, on its own
      { const b = served('sources.html'), sec = /  <h2 id="animals">[\s\S]*?(?=  <h2 id="search">)/;
        if (!ncHow || !soilHow || !tidesHow) { fail++; failed.push('13e sources.html'); console.log(`NOT RUN  13e sources.html: the baseline ${!soilHow ? SOIL_MAIN.slice(0, 7) : !tidesHow ? TIDES_MAIN.slice(0, 7) : NC_MAIN.slice(0, 7)} is not available.`); }
        else { // 25 Nov 2026 (organic soil): byte-identical to the file at SOIL_MAIN, which already holds the reviewed zebra block (C1a). The
          // block is still checked on its own: present once, on the line after the zebra's source paragraph. Animals guarantees as before.
          const bl = b.split('\n'), at = bl.findIndex(l => l.startsWith('  <p><b>Plains zebra, collar Z3866')), ctxOk = at >= 0 && bl[at + 1] === CTX_SOURCES && b.split(CTX_SOURCES).length === 2;
          const tsf = tidesFile('sources.html'), whole = noHeightSources(noTempSources(noLrocSources(noSkySrc(noCrSrc(noLeSrc(b)))))) === tsf && tidesSourcesOk(tsf) && noKey(noTidesSources(noTides(tsf))) === noKey(soilFile('sources.html')) && tsf.split(TIDES_TAB).length === 2 && tsf.split(TIDES_MENU).length === 2, g = animalsHead(b, mainFile('sources.html')), section = sec.test(b), shortcut = b.split(' · <a href="#animals">Animals</a> · <a href="#search">Search</a>').length === 2,
            ids = ['10.5441/001/1.f3550b4f', '10.5281/zenodo.5575189', 'ptt id 98364', '10.5441/001/1.3hp3s250', '10.5061/dryad.vx0k6djp7', '10.5066/P1ETBSYE', 'Low-use class'].filter(x => !b.includes(x)), noPreview = !/private preview/i.test(b);
          ok(`13e sources.html, with the Moon height section and shortcut set aside, is byte-identical to the file at the Tides baseline ${TIDES_MAIN.slice(0, 7)}, which is the organic-soil baseline ${SOIL_MAIN.slice(0, 7)}'s plus exactly the Tides tab, the Menu item, the stylesheet key, one Tides section before Animals and its one shortcut; the reviewed zebra land-context block is present once, after the zebra's source paragraph; it carries the Animals tab link and menu link once each and main ${BASE_MAIN.slice(0, 7)}'s header except those links; its Animals section, its one shortcut in the Sections list, all six sources and the omitted Low class are present; it never says private preview`, whole && ctxOk && g.links && g.header && section && shortcut && ids.length === 0 && noPreview, { whole, ctxOk, links: g.links, header: g.header, section, shortcut, missing: ids, noPreview }); } }
      // 13j (24 Nov 2026, Nature context): NC_MAIN descends from NC_PARENT and changed no production file but the three above
      { let names = null; try { git(['merge-base', '--is-ancestor', NC_PARENT, NC_MAIN]); names = git(['diff', '--name-only', NC_PARENT, NC_MAIN]).split('\n').filter(Boolean); } catch (_) { }
        if (!names) { fail++; failed.push('13j'); console.log(`NOT RUN  13j: ${NC_PARENT.slice(0, 7)}..${NC_MAIN.slice(0, 7)} cannot be read from Git (or ${NC_PARENT.slice(0, 7)} is not an ancestor). The scope check was not made.`); }
        else { const PAGES = ['app.js', 'index.html', 'sources.html'], TESTS = ['phase1/nature-context-ui.test.cjs', 'phase1/place-rows.test.mjs', 'phase1/place-ui.test.cjs'],
            RECORD = f => /^reviews\/2026-11-24-nature-context-[a-z0-9.-]+\.md$/.test(f) || /^reviews\/evidence\/2026-11-24-nature-context-rc\/[^/]+$/.test(f),
            other = names.filter(f => !PAGES.includes(f) && !TESTS.includes(f) && !RECORD(f));
          ok(`13j ${NC_PARENT.slice(0, 7)}..${NC_MAIN.slice(0, 7)} changes only app.js, index.html and sources.html among production files, plus the three listed tests and the Nature context records (anything else listed on failure)`, other.length === 0 && PAGES.every(f => names.includes(f)) && NC_MAIN !== BASE_MAIN && NC_MAIN !== TL_MAIN, other); } }
      // 13m (25 Nov 2026, organic soil): SOIL_MAIN descends from SOIL_PARENT and its changed paths are EXACTLY the literal SOIL_FILES list
      // (nothing more, nothing missing: index.html and sources.html must change, app.js must not). The retired preview fixture is absent at
      // both anchors and the full table is present with its pinned hash. The integrated tree serves SOIL_MAIN's soil.js and table.
      { let names = null; try { git(['merge-base', '--is-ancestor', SOIL_PARENT, SOIL_MAIN]); names = git(['diff', '--name-only', SOIL_PARENT, SOIL_MAIN]).split('\n').filter(Boolean); } catch (_) { }
        if (!names) { fail++; failed.push('13m'); console.log(`NOT RUN  13m: ${SOIL_PARENT.slice(0, 7)}..${SOIL_MAIN.slice(0, 7)} cannot be read from Git (or ${SOIL_PARENT.slice(0, 7)} is not an ancestor). The scope check was not made.`); }
        else { const extra = names.filter(f => !SOIL_FILES.includes(f)), missing = SOIL_FILES.filter(f => !names.includes(f)), has = (c, f) => { try { git(['cat-file', '-e', c + ':' + f]); return true; } catch (_) { return false; } };
          const fixtureGone = !has(SOIL_PARENT, 'assets/soil/g4-soil-fixture-v1.0.1.json') && !has(SOIL_MAIN, 'assets/soil/g4-soil-fixture-v1.0.1.json') && !fs.existsSync(path.join(ROOT, 'assets/soil/g4-soil-fixture-v1.0.1.json'));
          let tableOk = false; try { const tb = cp.execFileSync('git', ['show', SOIL_MAIN + ':assets/soil/g4-soil-v1.0.1.json'], { cwd: ROOT, maxBuffer: 64e6 }); tableOk = sha(tb) === SOIL_TABLE_SHA && sha(fs.readFileSync(path.join(ROOT, 'assets/soil/g4-soil-v1.0.1.json'))) === SOIL_TABLE_SHA; } catch (_) { }
          const soilJs = served('soil.js') === soilFile('soil.js');
          ok(`13m ${SOIL_PARENT.slice(0, 7)}..${SOIL_MAIN.slice(0, 7)} changes exactly the ${SOIL_FILES.length} listed files (app.js not among them; index.html and sources.html among them); the preview fixture is absent; the full table carries its pinned hash here and at ${SOIL_MAIN.slice(0, 7)}; soil.js here is ${SOIL_MAIN.slice(0, 7)}'s`, extra.length === 0 && missing.length === 0 && !names.includes('app.js') && fixtureGone && tableOk && soilJs && SOIL_MAIN !== NC_MAIN && SOIL_MAIN !== BASE_MAIN, { extra, missing, fixtureGone, tableOk, soilJs }); } }
      // 13n (25 Nov 2026, organic soil): the maintenance that moved these pins is the first commit after SOIL_MAIN, on the path to here, that
      // touches this suite. Its parent is SOIL_MAIN and it changes this suite and nothing else. (It cannot name its own hash; this binds it.)
      { let ok13n = null, info = {}; try { const firsts = git(['log', '--reverse', '--ancestry-path', '--format=%H', SOIL_MAIN + '..HEAD', '--', 'phase1/animals-tab-ui.test.cjs']).split('\n').filter(Boolean);
          const m = firsts[0]; if (m) { const parents = git(['log', '-1', '--format=%P', m]).trim().split(' '), files = git(['diff-tree', '--no-commit-id', '--name-only', '-r', m]).split('\n').filter(Boolean); info = { commit: m.slice(0, 7), parents, files }; ok13n = parents.length === 1 && parents[0] === SOIL_MAIN && files.length === 1 && files[0] === 'phase1/animals-tab-ui.test.cjs'; }
          else { const cur = (() => { try { return git(['diff', '--name-only', SOIL_MAIN, '--', 'phase1/animals-tab-ui.test.cjs']).trim(); } catch (_) { return 'x'; } })(); info = { uncommitted: cur }; ok13n = cur === 'phase1/animals-tab-ui.test.cjs' && git(['diff', '--name-only', SOIL_MAIN]).split('\n').filter(Boolean).every(f => f === 'phase1/animals-tab-ui.test.cjs'); } } catch (_) { }
        if (ok13n === null) { fail++; failed.push('13n'); console.log('NOT RUN  13n: the maintenance commit after SOIL_MAIN could not be read from Git.'); }
        else ok('13n the Animals-suite maintenance after the organic-soil payload changes only this suite, on top of SOIL_MAIN (before it is committed: the working tree differs from SOIL_MAIN in this suite only)', ok13n, info); }
      // 13o (25 Nov 2026, Tides navigation): TIDES_MAIN descends from TIDES_PARENT and its changed paths are EXACTLY the literal TIDES_FILES
      { let names = null; try { git(['merge-base', '--is-ancestor', TIDES_PARENT, TIDES_MAIN]); names = git(['diff', '--name-only', TIDES_PARENT, TIDES_MAIN]).split('\n').filter(Boolean); } catch (_) { }
        if (!names) { fail++; failed.push('13o'); console.log(`NOT RUN  13o: ${TIDES_PARENT.slice(0, 7)}..${TIDES_MAIN.slice(0, 7)} cannot be read from Git (or ${TIDES_PARENT.slice(0, 7)} is not an ancestor). The scope check was not made.`); }
        else { const extra = names.filter(f => !TIDES_FILES.includes(f)), missing = TIDES_FILES.filter(f => !names.includes(f));
          ok(`13o ${TIDES_PARENT.slice(0, 7)}..${TIDES_MAIN.slice(0, 7)} changes exactly the ${TIDES_FILES.length} listed files (app.js, layers.js, soil.js, animals scripts and the hub not among them)`, extra.length === 0 && missing.length === 0 && !names.some(f => /^(app|layers|soil|animals[a-z-]*)\.js$|worker\.js$/.test(f)), { extra, missing }); } }
      // 13p (25 Nov 2026, Tides navigation): the maintenance that added the Tides pins is the first commit after TIDES_MAIN, on the path to
      // here, that touches this suite; its parent is TIDES_MAIN and it changes this suite and nothing else.
      { let ok13p = null, info = {}; try { const firsts = git(['log', '--reverse', '--ancestry-path', '--format=%H', TIDES_MAIN + '..HEAD', '--', 'phase1/animals-tab-ui.test.cjs']).split('\n').filter(Boolean);
          const m = firsts[0]; if (m) { const parents = git(['log', '-1', '--format=%P', m]).trim().split(' '), files = git(['diff-tree', '--no-commit-id', '--name-only', '-r', m]).split('\n').filter(Boolean); info = { commit: m.slice(0, 7), parents, files }; ok13p = parents.length === 1 && parents[0] === TIDES_MAIN && files.length === 1 && files[0] === 'phase1/animals-tab-ui.test.cjs'; }
          else { const cur = (() => { try { return git(['diff', '--name-only', TIDES_MAIN, '--', 'phase1/animals-tab-ui.test.cjs']).trim(); } catch (_) { return 'x'; } })(); info = { uncommitted: cur }; ok13p = cur === 'phase1/animals-tab-ui.test.cjs' && git(['diff', '--name-only', TIDES_MAIN]).split('\n').filter(Boolean).every(f => f === 'phase1/animals-tab-ui.test.cjs'); } } catch (_) { }
        if (ok13p === null) { fail++; failed.push('13p'); console.log('NOT RUN  13p: the maintenance commit after TIDES_MAIN could not be read from Git.'); }
        else ok('13p the Animals-suite maintenance after the Tides navigation payload changes only this suite, on top of TIDES_MAIN (before it is committed: the working tree differs from TIDES_MAIN in this suite only)', ok13p, info); }
      // 13r (26 Nov 2026, Moon height): MH_MAIN descends from MH_PARENT and its changed paths are EXACTLY the literal MH_FILES
      { let names = null; try { git(['merge-base', '--is-ancestor', MH_PARENT, MH_MAIN]); names = git(['diff', '--name-only', MH_PARENT, MH_MAIN]).split('\n').filter(Boolean); } catch (_) { }
        if (!names) { fail++; failed.push('13r'); console.log(`NOT RUN  13r: ${MH_PARENT.slice(0, 7)}..${MH_MAIN.slice(0, 7)} cannot be read from Git (or ${MH_PARENT.slice(0, 7)} is not an ancestor). The scope check was not made.`); }
        else { const extra = names.filter(f => !MH_FILES.includes(f)), missing = MH_FILES.filter(f => !names.includes(f));
          ok(`13r ${MH_PARENT.slice(0, 7)}..${MH_MAIN.slice(0, 7)} changes exactly the ${MH_FILES.length} listed files (index.html, animals.html, style.css, app.js, animals scripts and the hub not among them)`, extra.length === 0 && missing.length === 0 && !names.some(f => /^(app|layers|soil|animals[a-z-]*)\.js$|worker\.js$|^(index|animals|tides)\.html$|^style\.css$/.test(f)), { extra, missing }); } }
      // 13s (26 Nov 2026, Moon height): the maintenance that added the Moon height pins is the first commit after MH_MAIN, on the path to
      // here, that touches this suite; its parent is MH_MAIN and it changes this suite and nothing else.
      { let ok13s = null, info = {}; try { const firsts = git(['log', '--reverse', '--ancestry-path', '--format=%H', MH_MAIN + '..HEAD', '--', 'phase1/animals-tab-ui.test.cjs']).split('\n').filter(Boolean);
          const m = firsts[0]; if (m) { const parents = git(['log', '-1', '--format=%P', m]).trim().split(' '), files = git(['diff-tree', '--no-commit-id', '--name-only', '-r', m]).split('\n').filter(Boolean); info = { commit: m.slice(0, 7), parents, files }; ok13s = parents.length === 1 && parents[0] === MH_MAIN && files.length === 1 && files[0] === 'phase1/animals-tab-ui.test.cjs'; }
          else { const cur = (() => { try { return git(['diff', '--name-only', MH_MAIN, '--', 'phase1/animals-tab-ui.test.cjs']).trim(); } catch (_) { return 'x'; } })(); info = { uncommitted: cur }; ok13s = cur === 'phase1/animals-tab-ui.test.cjs' && git(['diff', '--name-only', MH_MAIN]).split('\n').filter(Boolean).every(f => f === 'phase1/animals-tab-ui.test.cjs'); } } catch (_) { }
        if (ok13s === null) { fail++; failed.push('13s'); console.log('NOT RUN  13s: the maintenance commit after MH_MAIN could not be read from Git.'); }
        else ok('13s the Animals-suite maintenance after the Moon height payload changes only this suite, on top of MH_MAIN (before it is committed: the working tree differs from MH_MAIN in this suite only)', ok13s, info); }
      // 13t (26 Nov 2026, Moon temperature): DV_MAIN descends from DV_PARENT and its changed paths are EXACTLY the literal DV_FILES
      { let names = null; try { git(['merge-base', '--is-ancestor', DV_PARENT, DV_MAIN]); names = git(['diff', '--name-only', DV_PARENT, DV_MAIN]).split('\n').filter(Boolean); } catch (_) { }
        if (!names) { fail++; failed.push('13t'); console.log(`NOT RUN  13t: ${DV_PARENT.slice(0, 7)}..${DV_MAIN.slice(0, 7)} cannot be read from Git (or ${DV_PARENT.slice(0, 7)} is not an ancestor). The scope check was not made.`); }
        else { const extra = names.filter(f => !DV_FILES.includes(f)), missing = DV_FILES.filter(f => !names.includes(f));
          ok(`13t ${DV_PARENT.slice(0, 7)}..${DV_MAIN.slice(0, 7)} changes exactly the ${DV_FILES.length} listed files (index.html, animals.html, style.css, app.js, moonglobe.js, animals scripts and the hub not among them; sources.html and REGISTER.md since the release candidate)`, extra.length === 0 && missing.length === 0 &&
            !names.some(f => /^(app|layers|soil|moonglobe|animals[a-z-]*)\.js$|worker\.js$|^(index|animals|tides)\.html$|^style\.css$/.test(f)), { extra, missing }); } }
      // 13u (26 Nov 2026, Moon temperature): the maintenance that added these pins is the first commit after DV_MAIN, on the path to here,
      // that touches this suite; its parent is DV_MAIN and it changes this suite and nothing else.
      { let ok13u = null, info = {}; try { const firsts = git(['log', '--reverse', '--ancestry-path', '--format=%H', DV_MAIN + '..HEAD', '--', 'phase1/animals-tab-ui.test.cjs']).split('\n').filter(Boolean);
          const m = firsts[0]; if (m) { const parents = git(['log', '-1', '--format=%P', m]).trim().split(' '), files = git(['diff-tree', '--no-commit-id', '--name-only', '-r', m]).split('\n').filter(Boolean); info = { commit: m.slice(0, 7), parents, files }; ok13u = parents.length === 1 && parents[0] === DV_MAIN && files.length === 1 && files[0] === 'phase1/animals-tab-ui.test.cjs'; }
          else { const cur = (() => { try { return git(['diff', '--name-only', DV_MAIN, '--', 'phase1/animals-tab-ui.test.cjs']).trim(); } catch (_) { return 'x'; } })(); info = { uncommitted: cur }; ok13u = cur === 'phase1/animals-tab-ui.test.cjs' && git(['diff', '--name-only', DV_MAIN]).split('\n').filter(Boolean).every(f => f === 'phase1/animals-tab-ui.test.cjs'); } } catch (_) { }
        if (ok13u === null) { fail++; failed.push('13u'); console.log('NOT RUN  13u: the maintenance commit after DV_MAIN could not be read from Git.'); }
        else ok('13u the Animals-suite maintenance after the Moon temperature payload changes only this suite, on top of DV_MAIN (before it is committed: the working tree differs from DV_MAIN in this suite only)', ok13u, info); }
      // 13v (26 Nov 2026, Moon LROC): LR_MAIN descends from LR_PARENT and its changed paths are EXACTLY the literal LR_FILES
      { let names = null; try { git(['merge-base', '--is-ancestor', LR_PARENT, LR_MAIN]); names = git(['diff', '--name-only', LR_PARENT, LR_MAIN]).split('\n').filter(Boolean); } catch (_) { }
        if (!names) { fail++; failed.push('13v'); console.log(`NOT RUN  13v: ${LR_PARENT}..${LR_MAIN} cannot be read from Git (or ${LR_PARENT} is not an ancestor). The scope check was not made.`); }
        else { const extra = names.filter(f => !LR_FILES.includes(f)), missing = LR_FILES.filter(f => !names.includes(f));
          ok(`13v ${LR_PARENT}..${LR_MAIN} changes exactly the ${LR_FILES.length} listed files (no shared script, stylesheet, index.html, animals files or the hub; sources.html and REGISTER.md since the release candidate)`, extra.length === 0 && missing.length === 0 &&
            !names.some(f => /^(app|layers|soil|moonglobe|moonsci|moonlight|craft|animals[a-z-]*)\.js$|worker\.js$|^(index|animals|tides)\.html$|^(style|moonsci)\.css$/.test(f)), { extra, missing }); } }
      // 13w (26 Nov 2026, Moon LROC): the maintenance that added these pins is the first commit after LR_MAIN, on the path to here, that
      // touches this suite; its parent is LR_MAIN and it changes this suite and nothing else.
      { let ok13w = null, info = {}; try { const firsts = git(['log', '--reverse', '--ancestry-path', '--format=%H', LR_MAIN + '..HEAD', '--', 'phase1/animals-tab-ui.test.cjs']).split('\n').filter(Boolean);
          const m = firsts[0]; const full = git(['rev-parse', LR_MAIN]).trim();
          if (m) { const parents = git(['log', '-1', '--format=%P', m]).trim().split(' '), files = git(['diff-tree', '--no-commit-id', '--name-only', '-r', m]).split('\n').filter(Boolean); info = { commit: m.slice(0, 7), parents, files }; ok13w = parents.length === 1 && parents[0] === full && files.length === 1 && files[0] === 'phase1/animals-tab-ui.test.cjs'; }
          else { const cur = (() => { try { return git(['diff', '--name-only', LR_MAIN, '--', 'phase1/animals-tab-ui.test.cjs']).trim(); } catch (_) { return 'x'; } })(); info = { uncommitted: cur }; ok13w = cur === 'phase1/animals-tab-ui.test.cjs' && git(['diff', '--name-only', LR_MAIN]).split('\n').filter(Boolean).every(f => f === 'phase1/animals-tab-ui.test.cjs'); } } catch (_) { }
        if (ok13w === null) { fail++; failed.push('13w'); console.log('NOT RUN  13w: the maintenance commit after LR_MAIN could not be read from Git.'); }
        else ok('13w the Animals-suite maintenance after the Moon LROC payload changes only this suite, on top of LR_MAIN (before it is committed: the working tree differs from LR_MAIN in this suite only)', ok13w, info); }
      // 13y (27 Nov 2026, Sky zoom-out Moon picture): SK_MAIN descends from SK_PARENT and its changed paths are EXACTLY the literal SK_FILES
      { let names = null; try { git(['merge-base', '--is-ancestor', SK_PARENT, SK_MAIN]); names = git(['diff', '--name-only', SK_PARENT, SK_MAIN]).split('\n').filter(Boolean); } catch (_) { }
        if (!names) { fail++; failed.push('13y'); console.log(`NOT RUN  13y: ${SK_PARENT}..${SK_MAIN} cannot be read from Git (or ${SK_PARENT} is not an ancestor). The scope check was not made.`); }
        else { const extra = names.filter(f => !SK_FILES.includes(f)), missing = SK_FILES.filter(f => !names.includes(f));
          ok(`13y ${SK_PARENT.slice(0, 7)}..${SK_MAIN.slice(0, 7)} changes exactly the ${SK_FILES.length} listed files (index.html, skyscene.js and sources.html among them; moonlight.js, moon.html, style.css, the animals files and the hub not)`, extra.length === 0 && missing.length === 0 && !names.includes('moonlight.js') && !names.includes('moon.html') && !names.includes('style.css') && !names.includes('phase1/worker.js'), { extra, missing }); } }
      // 13z (27 Nov 2026, Sky zoom-out Moon picture): the maintenance that added these pins is the first commit after SK_MAIN, on the path to
      // here, that touches this suite; its parent is SK_MAIN and it changes this suite and nothing else.
      { let ok13z = null, info = {}; try { const firsts = git(['log', '--reverse', '--ancestry-path', '--format=%H', SK_MAIN + '..HEAD', '--', 'phase1/animals-tab-ui.test.cjs']).split('\n').filter(Boolean);
          const m = firsts[0]; const full = git(['rev-parse', SK_MAIN]).trim();
          if (m) { const parents = git(['log', '-1', '--format=%P', m]).trim().split(' '), files = git(['diff-tree', '--no-commit-id', '--name-only', '-r', m]).split('\n').filter(Boolean); info = { commit: m.slice(0, 7), parents, files }; ok13z = parents.length === 1 && parents[0] === full && files.length === 1 && files[0] === 'phase1/animals-tab-ui.test.cjs'; }
          else { const cur = (() => { try { return git(['diff', '--name-only', SK_MAIN, '--', 'phase1/animals-tab-ui.test.cjs']).trim(); } catch (_) { return 'x'; } })(); info = { uncommitted: cur }; ok13z = cur === 'phase1/animals-tab-ui.test.cjs' && git(['diff', '--name-only', SK_MAIN]).split('\n').filter(Boolean).every(f => f === 'phase1/animals-tab-ui.test.cjs'); } } catch (_) { }
        if (ok13z === null) { fail++; failed.push('13z'); console.log('NOT RUN  13z: the maintenance commit after SK_MAIN could not be read from Git.'); }
        else ok('13z the Animals-suite maintenance after the Sky zoom-out Moon picture payload changes only this suite, on top of SK_MAIN (before it is committed: the working tree differs from SK_MAIN in this suite only)', ok13z, info); }
      // 13aa (27 Nov 2026, Moon CRaTER event counts): CR_MAIN descends from CR_PARENT and its changed paths are EXACTLY the literal CR_FILES
      { let names = null; try { git(['merge-base', '--is-ancestor', CR_PARENT, CR_MAIN]); names = git(['diff', '--name-only', CR_PARENT, CR_MAIN]).split('\n').filter(Boolean); } catch (_) { }
        if (!names) { fail++; failed.push('13aa'); console.log(`NOT RUN  13aa: ${CR_PARENT}..${CR_MAIN} cannot be read from Git (or ${CR_PARENT} is not an ancestor). The scope check was not made.`); }
        else { const extra = names.filter(f => !CR_FILES.includes(f)), missing = CR_FILES.filter(f => !names.includes(f));
          ok(`13aa ${CR_PARENT.slice(0, 7)}..${CR_MAIN.slice(0, 7)} changes exactly the ${CR_FILES.length} listed files (moon.html, mooncrater.js, mooncrater.css and sources.html among them; craft.js, moonglobe.js, index.html, style.css, the animals files and the hub not)`, extra.length === 0 && missing.length === 0 && !['craft.js', 'moonglobe.js', 'index.html', 'style.css', 'phase1/worker.js'].some(f => names.includes(f)), { extra, missing }); } }
      // 13ab (27 Nov 2026, Moon CRaTER event counts): the maintenance that added these pins is the first commit after CR_MAIN, on the path
      // to here, that touches this suite; its parent is CR_MAIN and it changes this suite and nothing else.
      { let ok13ab = null, info = {}; try { const firsts = git(['log', '--reverse', '--ancestry-path', '--format=%H', CR_MAIN + '..HEAD', '--', 'phase1/animals-tab-ui.test.cjs']).split('\n').filter(Boolean);
          const m = firsts[0]; const full = git(['rev-parse', CR_MAIN]).trim();
          if (m) { const parents = git(['log', '-1', '--format=%P', m]).trim().split(' '), files = git(['diff-tree', '--no-commit-id', '--name-only', '-r', m]).split('\n').filter(Boolean); info = { commit: m.slice(0, 7), parents, files }; ok13ab = parents.length === 1 && parents[0] === full && files.length === 1 && files[0] === 'phase1/animals-tab-ui.test.cjs'; }
          else { const cur = (() => { try { return git(['diff', '--name-only', CR_MAIN, '--', 'phase1/animals-tab-ui.test.cjs']).trim(); } catch (_) { return 'x'; } })(); info = { uncommitted: cur }; ok13ab = cur === 'phase1/animals-tab-ui.test.cjs' && git(['diff', '--name-only', CR_MAIN]).split('\n').filter(Boolean).every(f => f === 'phase1/animals-tab-ui.test.cjs'); } } catch (_) { }
        if (ok13ab === null) { fail++; failed.push('13ab'); console.log('NOT RUN  13ab: the maintenance commit after CR_MAIN could not be read from Git.'); }
        else ok('13ab the Animals-suite maintenance after the Moon CRaTER event-count payload changes only this suite, on top of CR_MAIN (before it is committed: the working tree differs from CR_MAIN in this suite only)', ok13ab, info); }
      // 13ac (27 Nov 2026, Moon neutron record): LE_MAIN descends from LE_PARENT and its changed paths are EXACTLY the literal LE_FILES
      { let names = null; try { git(['merge-base', '--is-ancestor', LE_PARENT, LE_MAIN]); names = git(['diff', '--name-only', LE_PARENT, LE_MAIN]).split('\n').filter(Boolean); } catch (_) { }
        if (!names) { fail++; failed.push('13ac'); console.log(`NOT RUN  13ac: ${LE_PARENT}..${LE_MAIN} cannot be read from Git (or ${LE_PARENT} is not an ancestor). The scope check was not made.`); }
        else { const extra = names.filter(f => !LE_FILES.includes(f)), missing = LE_FILES.filter(f => !names.includes(f));
          ok(`13ac ${LE_PARENT.slice(0, 7)}..${LE_MAIN.slice(0, 7)} changes exactly the ${LE_FILES.length} listed files (moon.html, moonsci.js, moonsci.css and sources.html among them; craft.js, moonglobe.js, moonlroc.js, mooncrater.js, index.html, style.css, the animals files and the hub not)`, extra.length === 0 && missing.length === 0 && !['craft.js', 'moonglobe.js', 'moonlroc.js', 'mooncrater.js', 'index.html', 'style.css', 'phase1/worker.js'].some(f => names.includes(f)), { extra, missing }); } }
      // 13ad (27 Nov 2026, Moon neutron record): the maintenance that added these pins is the first commit after LE_MAIN, on the path to
      // here, that touches this suite; its parent is LE_MAIN and it changes this suite and nothing else.
      { let ok13ad = null, info = {}; try { const firsts = git(['log', '--reverse', '--ancestry-path', '--format=%H', LE_MAIN + '..HEAD', '--', 'phase1/animals-tab-ui.test.cjs']).split('\n').filter(Boolean);
          const m = firsts[0]; const full = git(['rev-parse', LE_MAIN]).trim();
          if (m) { const parents = git(['log', '-1', '--format=%P', m]).trim().split(' '), files = git(['diff-tree', '--no-commit-id', '--name-only', '-r', m]).split('\n').filter(Boolean); info = { commit: m.slice(0, 7), parents, files }; ok13ad = parents.length === 1 && parents[0] === full && files.length === 1 && files[0] === 'phase1/animals-tab-ui.test.cjs'; }
          else { const cur = (() => { try { return git(['diff', '--name-only', LE_MAIN, '--', 'phase1/animals-tab-ui.test.cjs']).trim(); } catch (_) { return 'x'; } })(); info = { uncommitted: cur }; ok13ad = cur === 'phase1/animals-tab-ui.test.cjs' && git(['diff', '--name-only', LE_MAIN]).split('\n').filter(Boolean).every(f => f === 'phase1/animals-tab-ui.test.cjs'); } } catch (_) { }
        if (ok13ad === null) { fail++; failed.push('13ad'); console.log('NOT RUN  13ad: the maintenance commit after LE_MAIN could not be read from Git.'); }
        else ok('13ad the Animals-suite maintenance after the Moon neutron-record payload changes only this suite, on top of LE_MAIN (before it is committed: the working tree differs from LE_MAIN in this suite only)', ok13ad, info); }
      // 13ae (28 Nov 2026, LEND readout rounding): RD_MAIN descends from RD_PARENT and its changed paths are EXACTLY the literal RD_FILES
      { let names = null; try { git(['merge-base', '--is-ancestor', RD_PARENT, RD_MAIN]); names = git(['diff', '--name-only', RD_PARENT, RD_MAIN]).split('\n').filter(Boolean); } catch (_) { }
        if (!names) { fail++; failed.push('13ae'); console.log(`NOT RUN  13ae: ${RD_PARENT}..${RD_MAIN} cannot be read from Git (or ${RD_PARENT} is not an ancestor). The scope check was not made.`); }
        else { const extra = names.filter(f => !RD_FILES.includes(f)), missing = RD_FILES.filter(f => !names.includes(f));
          ok(`13ae ${RD_PARENT.slice(0, 7)}..${RD_MAIN.slice(0, 7)} changes exactly the ${RD_FILES.length} listed files (moon.html and moonsci.js the only served ones; sources.html, moonsci.css, the LEND data file, REGISTER and the hub not)`, extra.length === 0 && missing.length === 0 && !['sources.html', 'moonsci.css', 'assets/moon/lend/lend-alds-2011-2016-R1.bin', 'REGISTER.md', 'phase1/worker.js'].some(f => names.includes(f)), { extra, missing }); } }
      // 13af (28 Nov 2026, LEND readout rounding): the maintenance that added these pins is the first commit after RD_MAIN, on the path to here,
      // that touches this suite; its parent is RD_MAIN and it changes this suite and nothing else.
      { let ok13af = null, info = {}; try { const firsts = git(['log', '--reverse', '--ancestry-path', '--format=%H', RD_MAIN + '..HEAD', '--', 'phase1/animals-tab-ui.test.cjs']).split('\n').filter(Boolean);
          const m = firsts[0]; const full = git(['rev-parse', RD_MAIN]).trim();
          if (m) { const parents = git(['log', '-1', '--format=%P', m]).trim().split(' '), files = git(['diff-tree', '--no-commit-id', '--name-only', '-r', m]).split('\n').filter(Boolean); info = { commit: m.slice(0, 7), parents, files }; ok13af = parents.length === 1 && parents[0] === full && files.length === 1 && files[0] === 'phase1/animals-tab-ui.test.cjs'; }
          else { const cur = (() => { try { return git(['diff', '--name-only', RD_MAIN, '--', 'phase1/animals-tab-ui.test.cjs']).trim(); } catch (_) { return 'x'; } })(); info = { uncommitted: cur }; ok13af = cur === 'phase1/animals-tab-ui.test.cjs' && git(['diff', '--name-only', RD_MAIN]).split('\n').filter(Boolean).every(f => f === 'phase1/animals-tab-ui.test.cjs'); } } catch (_) { }
        if (ok13af === null) { fail++; failed.push('13af'); console.log('NOT RUN  13af: the maintenance commit after RD_MAIN could not be read from Git.'); }
        else ok('13af the Animals-suite maintenance after the LEND readout-rounding payload changes only this suite, on top of RD_MAIN (before it is committed: the working tree differs from RD_MAIN in this suite only)', ok13af, info); }
      // ----- the Timeline's own files, against main at TL_MAIN (the Timeline's latest release)
      const TL_DIR = process.env.TL_DIR || ''; let tlHow = '';
      if (TL_DIR && fs.existsSync(path.join(TL_DIR, 'timeline.html'))) tlHow = 'dir'; else { try { git(['cat-file', '-e', TL_MAIN + '^{commit}']); tlHow = 'git'; } catch (_) { } }
      const tlFile = f => tlHow === 'dir' ? fs.readFileSync(path.join(TL_DIR, f), 'utf8') : git(['show', TL_MAIN + ':' + f]);
      if (!tlHow) { fail++; failed.push('13f'); console.log(`NOT RUN  13f–13i: main ${TL_MAIN.slice(0, 7)} is not available (no Git metadata here and no TL_DIR). The Timeline comparisons were not made.`); }
      else { ok(`13f the Timeline baseline is main ${TL_MAIN.slice(0, 7)} (read from ${tlHow === 'dir' ? 'TL_DIR' : 'Git'}), and it is not the older baseline`, TL_MAIN !== BASE_MAIN);
        // 13g protects: nothing but a Timeline release changes the Timeline's script (it was one of the files in 13c)
        ok('13g timeline.js is byte-identical to main\'s at the Timeline baseline', tlFile('timeline.js') === served('timeline.js'));
        // 13h protects what 13e protected for this page: nothing but a Timeline release changes it, and all the Animals work ever added
        // to it is its two links. The page pins its own stylesheet version, so the version is compared too (13e set it aside).
        { const b = served('timeline.html'), tabL = '    <a href="animals.html" data-view="animals">Animals</a>\n', menuL = '      <li role="none"><a role="menuitem" href="animals.html" data-page="animals">Animals</a></li>\n', hd = t => (/<header[\s\S]*?<\/header>/.exec(t) || [''])[0], oldHd = hd(mainFile('timeline.html'));
          // 25 Nov 2026 (Tides navigation): the Tides tab and Menu item (once each) are set aside, exactly as the Animals lines are
          const tides = b.split(TIDES_TAB).length === 2 && b.split(TIDES_MENU).length === 2, whole = noTides(b) === tlFile('timeline.html'), links = b.split(tabL).length === 2 && b.split(menuL).length === 2, header = oldHd.length > 200 && noTides(hd(b)).replace(tabL, '').replace(menuL, '') === oldHd;
          ok(`13h timeline.html is byte-identical to main's at the Timeline baseline except the Tides tab and Menu item (once each); it carries the Animals tab link and menu link once each; and its header equals main ${BASE_MAIN.slice(0, 7)}'s except those links`, tides && whole && links && header, { tides, whole, links, header }); }
        // 13i protects what 13d protected for these lines, and more: the stylesheet's Timeline rules are exactly the Timeline release's,
        // in the same order (none dropped, none edited, none added by other work)
        { const tl = t => t.split('\n').filter(isTl), a = tl(tlFile('style.css')), b = tl(css), i = a.findIndex((l, k) => l !== b[k]);
          ok('13i the stylesheet\'s body.tl lines are exactly main\'s at the Timeline baseline, in order (first difference listed on failure)', a.length > 100 && a.length === b.length && i < 0, { baseline: a.length, here: b.length, at: i, baselineLine: a[i], hereLine: b[i] }); } } }
    const ctx = await ctxFor(browser, { width: 1280, height: 860 }); await ctx.route('**/' + HUB + '/**', r => r.fulfill({ status: 200, contentType: 'application/json', headers: { 'access-control-allow-origin': '*' }, body: JSON.stringify({ layer: 'x', retrieved_at: new Date().toISOString(), stale_after_s: 10800, source_status: 'ok', cells: {}, record_format: 'rows', record_fields: [], records: [] }) }));
    const page = await ctx.newPage(), reqs = []; page.on('request', r => reqs.push(r.url())); await page.goto(BASE + '/index.html#journey=' + Z, { waitUntil: 'domcontentloaded' }); await page.waitForFunction(() => window.ME && ME.layers, null, { timeout: 30000 }); await page.waitForTimeout(1500);
    const e = await page.evaluate(() => ({ ids: ['tgl-journey', 'journey-choose', 'card-journey', 'replay', 'leg-journey', 'an-globe'].filter(i => document.getElementById(i)), journey: typeof ME.journey, rows: ME.layers.rows.length, soilRows: ME.layers.rows.filter(r => r[0] === 'Organic-soil emissions (modelled)').length, rowTxt: ME.layers.rows.map(r => r[0]).filter(t => /animal|journey/i.test(t)), scripts: [...document.scripts].map(x => x.getAttribute('src') || '').filter(x => /animals/.test(x)),
      txt: /Animal journey/.test(document.body.textContent), panel: document.getElementById('layers-panel').hidden }));
    ok('13f Earth now carries no journey card, switch, chooser, replay bar, Key entry or Layers row, loads no Animals script, and the old link opens nothing; its Layers list has 17 rows, one of them "Organic-soil emissions (modelled)" (organic soil, 25 Nov 2026)', e.ids.length === 0 && e.journey === 'undefined' && e.rows === 17 && e.soilRows === 1 && e.rowTxt.length === 0 && e.scripts.length === 0 && !e.txt && e.panel === true && !reqs.some(u => /assets\/animals\//.test(u)), e);
    await ctx.close(); }

  // ===== 14. Layout (T16 with §A7): the stated target is NO overlap of the globe at any width (bar and switches are in the page flow)
  if (want(14)) for (const [w, h] of [[360, 740], [390, 844], [720, 900], [900, 760], [1100, 800], [1280, 860], [1470, 745]]) { reset(); const { ctx, page } = await open(browser, { width: w, height: h }); await on(page, SH);
    const m = await page.evaluate(() => { const R = e => { const r = e.getBoundingClientRect(); return { l: r.left, t: r.top + scrollY, r: r.right, b: r.bottom + scrollY, w: r.width, h: r.height }; }, hit = (a, b) => a.l < b.r && b.l < a.r && a.t < b.b && b.t < a.b;
      const g = R(document.getElementById('an-globe-box')), bar = R(document.getElementById('replay')), panel = R(document.getElementById('an-panel')), sw = [...document.querySelectorAll('button.an-tgl')].map(R), ctl = [...document.querySelectorAll('#replay button,#replay select,#replay input')].map(R);
      return { over: document.documentElement.scrollWidth - document.documentElement.clientWidth, g, barHit: hit(g, bar), panelHit: hit(g, panel), swMin: Math.min(...sw.map(x => x.h)), ctlMin: Math.min(...ctl.map(x => x.h)), order: g.t < bar.t && (innerWidth <= 900 ? bar.b <= panel.t + 1 : true), side: panel.l >= g.r - 1 }; });
    ok(`14a ${w} px: nothing overflows sideways`, m.over <= 0, m.over);
    ok(`14b ${w} px: the replay bar and the switch panel cover none of the globe (target: no overlap)`, !m.barHit && !m.panelHit && m.g.w >= 300 && m.g.h >= 240, m);
    ok(`14c ${w} px: ${w <= 900 ? 'globe, then the bar, then the switches' : 'the switches sit beside the globe, the bar under it'}; every switch and bar control is at least 44 px high`, m.order && (w <= 900 || m.side) && m.swMin >= 44 && m.ctlMin >= 44, m);
    let reach = true; for (const id of IDS) { await page.locator(tgl(id)).scrollIntoViewIfNeeded(); const top = await page.evaluate(i => { const b = document.getElementById(i), r = b.getBoundingClientRect(), e = document.elementFromPoint(r.left + 20, r.top + r.height / 2); return !!e && (e === b || b.contains(e)); }, 'tgl-' + id); reach = reach && top; }
    ok(`14d ${w} px: the page scrolls to every switch and each can be pressed (nothing lies over it)`, reach);
    await page.click(tgl(Z)); await settle(page, Z); const s = await state(page); ok(`14e ${w} px: a switch pressed at this width works`, checked(s).join() === Z && s.scene === 3, checked(s));
    await ctx.close(); }

  // ===== 15. The study cards
  if (want(15)) { reset(); const { ctx, page } = await open(browser);
    const c = await page.evaluate(() => [...document.querySelectorAll('.an-study')].map(s => ({ id: s.dataset.journey, state: s.querySelector('[data-f="state"]').textContent, title: s.querySelector('[data-f="title"]').textContent, lic: s.querySelector('[data-f="lic"]').textContent, cons: s.querySelector('[data-f="cons"]').textContent, pop: s.querySelector('[data-f="pop"]').textContent, sample: s.querySelector('[data-f="sample"]').textContent, go: s.querySelector('a.an-go').getAttribute('href') })));
    ok('15a each card is filled from its verified manifest, links to its own switch, and keeps the fixed "Not available yet" states and the sample-size sentence', c.length === IDS.length && c.every(x => x.title === JOUR[x.id].m.title && /verified/.test(x.state) && x.lic.includes(JOUR[x.id].m.licence) && /^Not available yet\./.test(x.cons) && /^Not available yet\./.test(x.pop) && /not a population estimate/.test(x.sample) && x.go === '#journey=' + x.id), c);
    const txt = await page.evaluate(() => document.querySelector('main').textContent);
    ok('15b the page says the globe shows no current observations and that the backdrop is not from a journey\'s dates; it does not send the reader to Earth now for the replay', /shows no current observations/.test(txt) && /not from a journey's dates/.test(txt) && !/Choose this journey on Earth now/.test(txt) && /Dated archive\./.test(txt) && /None of it is a live feed/.test(txt) && !/private preview|not released/i.test(txt), null);
    const air = await page.evaluate(() => [...document.querySelectorAll('.an-doc h3')].map(h => h.textContent)); ok('15c the cards are grouped Land, Sea, Air', air.join() === 'Land,Sea,Air', air);
    await ctx.close(); reset(); S.over[JOUR[W].e.manifest] = { body: Buffer.from('{"x":1}') }; const o = await open(browser);
    const bad = await o.page.evaluate(id => { const s = document.getElementById(id); return [s.querySelector('[data-f="state"]').textContent, s.querySelector('[data-f="facts"]').hidden]; }, W);
    ok('15d a card whose manifest does not verify says so and shows no figure', /could not be verified/.test(bad[0]) && bad[1] === true, bad); await o.ctx.close(); }

  // ===== 16. Phone: a press that switches a journey on brings the globe into view (GPT's Stage 1 review, finding 2)
  if (want(16)) { const FAILED = 'The journey file could not be loaded. Nothing is drawn.';
    const toSwitch = async (page, id) => { await page.evaluate(i => document.getElementById('tgl-' + i).scrollIntoView({ block: 'center' }), id); await page.waitForTimeout(80); };
    const seen = s => s.box.top >= 0 && s.box.top <= 12 && s.box.bottom <= s.vh;
    // where a thing sits on the screen: the browser keeps what is on screen in place when content above it changes height, so 'the page did not move' is checked on an element in view, not on the scroll offset
    const topOf = (page, sel) => page.evaluate(q => Math.round(document.querySelector(q).getBoundingClientRect().top), sel);
    for (const [w, h] of [[390, 740], [360, 560], [390, 844]]) { reset(); const { ctx, page, errs } = await open(browser, { width: w, height: h }); const tag = `${w}×${h}`; let s = await state(page);
      ok(`16a ${tag}: nothing scrolls at page load`, s.y === 0 && s.scroll === null, [s.y, s.scroll]);
      const g = gate(); S.over[JOUR[SH].j.file] = { hold: g.p }; await toSwitch(page, SH); const y0 = (await state(page)).y; await page.focus(tgl(SH)); await page.keyboard.press('Space'); await settle(page, SH, 'loading'); await page.waitForTimeout(150); s = await state(page);
      ok(`16b ${tag}: at the press itself, before the journey has loaded, the globe is brought to the top of the screen, whole; one scroll, without animation under reduced motion; the loading line is beside the globe and in view; focus stays on the switch`,
        y0 > 100 && seen(s) && s.scroll && s.scroll.n === 1 && s.scroll.behavior === 'auto' && s.beside && s.beside.text === 'White shark loading…' && s.beside.inView && s.focus === 'tgl-' + SH, { y0, y: s.y, box: s.box, scroll: s.scroll, beside: s.beside, focus: s.focus });
      const CARD = '#' + W; await page.evaluate(q => document.querySelector(q).scrollIntoView({ block: 'start' }), CARD); await page.waitForTimeout(100); const yDown = (await state(page)).y, c0 = await topOf(page, CARD); g.go(); delete S.over[JOUR[SH].j.file]; await settle(page, SH); await page.waitForTimeout(400); s = await state(page); const c1 = await topOf(page, CARD);
      ok(`16c ${tag}: the visitor scrolled away while it loaded; the late answer does NOT pull the page back`, yDown > 200 && Math.abs(c1 - c0) <= 2 && s.box.bottom < 0 && s.scroll.n === 1 && s.scene === 3, { yDown, c0, c1, box: s.box, n: s.scroll.n });
      await page.evaluate(() => { ME.journey.setSpeed(3600); ME.journey.play(); }); await page.waitForTimeout(600); s = await state(page); const c2 = await topOf(page, CARD);
      ok(`16d ${tag}: playback never scrolls the page`, s.playing === true && Math.abs(c2 - c1) <= 2 && s.scroll.n === 1, [c1, c2]);
      await toSwitch(page, SH); const t1 = await topOf(page, tgl(SH)); await page.focus(tgl(SH)); await page.keyboard.press('Space'); await settle(page, null, 'off'); await page.waitForTimeout(150); s = await state(page); const t2 = await topOf(page, tgl(SH));
      ok(`16e ${tag}: switching off does not take the page to the globe: the switch stays where it was on screen`, Math.abs(t2 - t1) <= 2 && s.box.bottom < 0 && s.scroll.n === 1 && checked(s).length === 0, [t1, t2, s.scroll]);
      // a journey that loads at once: the globe and the top of the replay bar are on screen
      await toSwitch(page, Z); await page.click(tgl(Z)); await settle(page, Z); await page.waitForTimeout(200); s = await state(page);
      ok(`16f ${tag}: once shown, the whole globe and the start of the replay bar are on screen`, seen(s) && s.barTop !== null && s.barTop < s.vh && s.scroll.n === 2 && s.beside === null, { box: s.box, barTop: s.barTop, vh: s.vh });
      const link = await page.evaluate(() => { const a = document.querySelector('.an-toswitches a'), r = a.getBoundingClientRect(); return { shown: getComputedStyle(a.parentElement).display !== 'none', h: r.height, inView: r.top >= 0 && r.bottom <= innerHeight, href: a.getAttribute('href') }; });
      await page.click('.an-toswitches a'); await page.waitForTimeout(200); const back = await page.evaluate(() => { const r = document.getElementById('an-panel').getBoundingClientRect(); return r.top >= -1 && r.top < innerHeight; }); s = await state(page);
      ok(`16g ${tag}: a link beside the globe goes back to the switches (at least 44 px high, on screen with the globe); it switches nothing and does not count as a reveal`, link.shown && link.h >= 44 && link.inView && link.href === '#an-panel' && back && s.choice === Z && s.scroll.n === 2, [link, back]);
      // rapid switching, and off while loading
      const g2 = gate(); S.over[JOUR[W].j.file] = { hold: g2.p }; await toSwitch(page, W); await page.click(tgl(W)); await page.waitForTimeout(100); const a1 = await state(page); await toSwitch(page, SH); await page.click(tgl(SH)); await settle(page, SH); await page.waitForTimeout(150); const a2 = await state(page); g2.go(); delete S.over[JOUR[W].j.file]; await page.waitForTimeout(400); s = await state(page);
      ok(`16h ${tag}: two presses in a row: each press reveals the globe once; the superseded answer scrolls nothing and draws nothing`, seen(a1) && a1.scroll.n === 3 && seen(a2) && a2.scroll.n === 4 && s.scroll.n === 4 && s.y === a2.y && checked(s).join() === SH && s.n === JOUR[SH].d.t.length, [a1.scroll, a2.scroll, s.scroll]);
      await page.click(tgl(SH), { force: true }).catch(() => {}); await page.evaluate(() => { if (ME.journey.state().choice) ME.journey.select(null); }); await page.waitForTimeout(100);
      // failure: the message is beside the globe, on screen; the row's Retry reveals the globe again
      S.over[JOUR[SH].j.file] = { status: 500 }; await toSwitch(page, SH); await page.click(tgl(SH)); await done(page); s = await state(page); const nFail = s.scroll.n;
      ok(`16i ${tag}: a journey that fails after the reveal: its message is beside the globe and on screen (not only on its row below); no further scroll`, seen(s) && s.beside && s.beside.text === `White shark could not be shown. ${FAILED}` && s.beside.inView && nFail === 5 && s.switches[SH].retry === true && checked(s).length === 0, { beside: s.beside, box: s.box, n: nFail });
      delete S.over[JOUR[SH].j.file]; await page.evaluate(i => document.querySelector(`.an-sw[data-journey="${i}"] [data-f="sw-retry"]`).scrollIntoView({ block: 'center' }), SH); await page.waitForTimeout(80); await page.click(`.an-sw[data-journey="${SH}"] [data-f="sw-retry"]`); await settle(page, SH); await page.waitForTimeout(150); s = await state(page);
      ok(`16i2 ${tag}: the row's Retry reveals the globe again, once, and the journey is shown`, seen(s) && s.scroll.n === 6 && s.scene === 3 && s.beside === null, [s.scroll, s.box]);
      ok(`16i3 ${tag}: no page error`, errs.length === 0, errs); await ctx.close(); }
    { reset(); const { ctx, page } = await open(browser, { width: 390, height: 740 }, '#journey=' + W); await page.waitForTimeout(400); const s = await state(page);
      const inView = await page.evaluate(i => { const r = document.getElementById(i).getBoundingClientRect(); return r.top >= 0 && r.bottom <= innerHeight; }, 'tgl-' + W);
      ok('16j phone, a link to one switch: the switch is on screen and focused; the page is not taken to the globe; nothing is on', s.focus === 'tgl-' + W && inView && s.scroll === null && s.y > 100 && checked(s).length === 0, [s.y, s.scroll, inView]); await ctx.close(); }
    { reset(); const { ctx, page } = await open(browser, { width: 390, height: 740 }, '', { extra: { reducedMotion: 'no-preference' } }); await toSwitch(page, Z); await page.click(tgl(Z)); await settle(page, Z); await page.waitForFunction(() => { const r = document.getElementById('an-globe-box').getBoundingClientRect(); return r.top >= 0 && r.top <= 12; }, null, { timeout: 8000 }).catch(() => {}); const s = await state(page);
      ok('16k phone without the reduced-motion setting: the reveal is a smooth scroll and ends with the globe on screen', s.scroll && s.scroll.behavior === 'smooth' && s.scroll.n === 1 && seen(s), [s.scroll, s.box]); await ctx.close(); }
    { reset(); const { ctx, page } = await open(browser, { width: 1280, height: 600 }); await page.evaluate(i => document.getElementById('tgl-' + i).scrollIntoView({ block: 'center' }), W); const y0 = (await state(page)).y; await page.click(tgl(W)); await settle(page, W); const s = await state(page);
      ok('16l desktop (switches beside the globe): a press does not scroll the page', s.scroll === null && s.y === y0, [s.y, y0, s.scroll]); await ctx.close(); }
    { reset(); const noGL = ctx => ctx.addInitScript(() => { const g = HTMLCanvasElement.prototype.getContext; HTMLCanvasElement.prototype.getContext = function (t, ...a) { return /webgl/.test(t) ? null : g.call(this, t, ...a); }; });
      const { ctx, page } = await open(browser, { width: 390, height: 740 }, '', { pre: noGL }); await toSwitch(page, Z); const y0 = (await state(page)).y; await page.click(tgl(Z), { force: true }); await page.waitForTimeout(300); const s = await state(page);
      ok('16m phone with no usable globe: a press on an unavailable switch does not scroll', s.scroll === null && s.y === y0 && checked(s).length === 0, [s.y, y0]); await ctx.close(); } }

  // ===== 17. The shared list's Retry has its own bounded request (GPT's Stage 1 review, finding 1)
  if (want(17)) { const CATN = 'journeys-R1.catalog.json', LIST_BAD = 'The list of journeys could not be verified. No journey can be shown until it verifies.', badCat = Buffer.from(CAT.toString().replace('"schema": 1', '"schema": 1 '));
    const listError = async (browser, vp) => { reset(); const o = await open(browser, vp); S.q[CATN] = [{ body: badCat }]; await o.page.click(tgl(W)); await done(o.page); const s = await state(o.page); if (s.integrity !== LIST_BAD) throw new Error('17 setup: list error not reached: ' + s.integrity); S.log = []; return o; };
    const aborted = o => o.failedReqs.filter(f => f[0] === CATN && /ERR_ABORTED/.test(f[1])).length;
    { // an old Retry FAILS after a newer journey has verified and loaded
      const o = await listError(browser), g = gate(); S.q[CATN] = [{ hold: g.p, status: 500 }]; await o.page.click('#an-integrity-retry'); await o.page.waitForFunction(() => ME.journey.state().listBusy, null, { timeout: 5000 }); const busy = await state(o.page);
      await o.page.click(tgl(Z)); await settle(o.page, Z); const before = await state(o.page); g.go(); await o.page.waitForTimeout(700); const s = await state(o.page);
      ok('17a an old Retry that fails after a newer journey has verified and loaded changes nothing: no list error, nothing said, the journey still shown', s.integrity === null && s.catErr === '' && s.globeNote === '' && s.say === before.say && /^Plains zebra shown\./.test(s.say) && s.choice === Z && s.status === 'ready' && s.scene === 3 && s.listBusy === false, { integrity: s.integrity, say: s.say, bsay: before.say, note: s.globeNote, catErr: s.catErr, choice: s.choice, status: s.status, scene: s.scene, busy: s.listBusy });
      ok('17b while the Retry runs its button says Checking and is marked busy; the later selection aborts the Retry\'s own request', busy.retryBtn[0] === 'Checking…' && busy.retryBtn[1] === 'true' && aborted(o) >= 1, [busy.retryBtn, o.failedReqs]); await o.ctx.close(); }
    { // an old Retry SUCCEEDS after a newer failure of the list
      const o = await listError(browser), g = gate(); S.q[CATN] = [{ hold: g.p }, { body: badCat }]; await o.page.click('#an-integrity-retry'); await o.page.waitForFunction(() => ME.journey.state().listBusy, null, { timeout: 5000 });
      await o.page.click(tgl(Z)); await done(o.page); const before = await state(o.page); g.go(); await o.page.waitForTimeout(700); const s = await state(o.page);
      ok('17c an old Retry that succeeds late does not clear a newer list error or say the list verified', before.integrity === LIST_BAD && s.integrity === LIST_BAD && s.say === before.say && /^Plains zebra could not be shown\./.test(s.say) && !/verified\. Journeys can/.test(s.say) && checked(s).length === 0 && s.scene === 0, [before.say, s.say, s.integrity]); await o.ctx.close(); }
    { // Retry, then Retry
      const o = await listError(browser), g = gate(); S.q[CATN] = [{ hold: g.p, status: 500 }, {}]; await o.page.click('#an-integrity-retry'); await o.page.waitForFunction(() => ME.journey.state().listBusy, null, { timeout: 5000 }); await o.page.click('#an-integrity-retry');
      await o.page.waitForFunction(() => document.getElementById('an-integrity').hidden, null, { timeout: 10000 }); const before = await state(o.page); g.go(); await o.page.waitForTimeout(700); const s = await state(o.page);
      ok('17d Retry pressed twice: the newer Retry decides; the older one\'s late failure changes and says nothing; its request was aborted', before.integrity === null && before.say === 'The list of journeys verified. Journeys can be switched on.' && s.integrity === null && s.say === before.say && s.listBusy === false && s.retryBtn[0] === 'Retry' && aborted(o) >= 1, [before.say, s.say, s.integrity]);
      ok('17e a Retry of the list switches nothing on, draws nothing, and requests only the list', checked(s).length === 0 && s.scene === 0 && s.choice === null && s.scroll === null && S.log.length === 2 && S.log.every(n => n === CATN), S.log); await o.ctx.close(); }
    { // Retry, then leaving the page
      const o = await listError(browser), g = gate(); S.q[CATN] = [{ hold: g.p }]; await o.page.click('#an-integrity-retry'); await o.page.waitForFunction(() => ME.journey.state().listBusy, null, { timeout: 5000 }); const before = await state(o.page);
      await o.page.evaluate(() => window.dispatchEvent(new PageTransitionEvent('pagehide', { persisted: true }))); await o.page.waitForTimeout(150); const mid = await state(o.page); g.go(); await o.page.waitForTimeout(700); const s = await state(o.page);
      ok('17f leaving the page cancels a running Retry: its request is aborted, the button is back to Retry, and its late answer changes and says nothing', mid.listBusy === false && mid.retryBtn[0] === 'Retry' && mid.retryBtn[1] === null && aborted(o) >= 1 && s.integrity === LIST_BAD && s.say === before.say && s.listBusy === false, [mid.retryBtn, s.say, s.integrity]); await o.ctx.close(); }
    { // the globe stops while a Retry runs
      const o = await listError(browser), g = gate(); S.q[CATN] = [{ hold: g.p }]; await o.page.click('#an-integrity-retry'); await o.page.waitForFunction(() => ME.journey.state().listBusy, null, { timeout: 5000 });
      await o.page.evaluate(() => { const cv = document.querySelector('#an-globe canvas'), gl = cv.getContext('webgl2') || cv.getContext('webgl'), ext = gl && gl.getExtension('WEBGL_lose_context'); if (ext) ext.loseContext(); else cv.dispatchEvent(new Event('webglcontextlost', { cancelable: true })); });
      await o.page.waitForFunction(() => ME.animalsGlobe.state().globe === 'lost', null, { timeout: 15000 }); await o.page.waitForTimeout(200); const mid = await state(o.page); g.go(); await o.page.waitForTimeout(600); const s = await state(o.page);
      ok('17g the globe stops while a Retry runs: the Retry is cancelled and its late answer changes nothing', mid.listBusy === false && s.integrity === LIST_BAD && !/verified\. Journeys can/.test(s.say) && s.listBusy === false, [mid.listBusy, s.say]); await o.ctx.close(); }
    { // a request that never answers
      const o = await listError(browser), never = new Promise(() => {}); const limit = await o.page.evaluate(() => { const w = ME.journey.J.WAIT_MS; ME.journey.J.WAIT_MS = 900; return w; });
      S.q[CATN] = [{ hold: never }]; const t0 = Date.now(); await o.page.click('#an-integrity-retry'); await o.page.waitForFunction(() => ME.journey.state().listBusy, null, { timeout: 5000 });
      const ended = await o.page.waitForFunction(() => !ME.journey.state().listBusy, null, { timeout: 6000 }).then(() => true, () => false); const s = await state(o.page);
      ok('17h a Retry whose request never answers ends at the time limit (the page\'s own limit is ' + limit + ' ms; 900 ms set for this check): the list error is said as a failure to load, the button is back to Retry, nothing is drawn', ended && Date.now() - t0 < 5000 && limit >= 5000 && s.integrity === 'The list of journeys could not be loaded. No journey can be shown until it loads.' && s.say === s.integrity && s.retryBtn[0] === 'Retry' && s.scene === 0 && checked(s).length === 0, [ended, s.integrity, s.say, limit]);
      await o.page.click('#an-integrity-retry'); await o.page.waitForFunction(() => document.getElementById('an-integrity').hidden, null, { timeout: 10000 }).catch(() => {}); await on(o.page, SH); const s2 = await state(o.page);
      ok('17i after that, a Retry that is answered verifies the list and a journey can be shown; a journey load is not disturbed by the Retry\'s controller', s2.integrity === null && checked(s2).join() === SH && s2.scene === 3 && o.errs.length === 0, [s2.integrity, o.errs]); await o.ctx.close(); }
    {
      const o = await listError(browser, { width: 390, height: 740 }); await o.page.evaluate(() => document.getElementById('an-integrity-retry').scrollIntoView({ block: 'center' })); const s0 = await state(o.page); await o.page.click('#an-integrity-retry'); await o.page.waitForFunction(() => document.getElementById('an-integrity').hidden, null, { timeout: 10000 }); const s = await state(o.page);
      ok('17j phone: the list\'s Retry does not scroll the page to the globe', s.scroll.n === s0.scroll.n && s.box.bottom < 0 && s.integrity === null, [s.y, s0.y, s.scroll]); await o.ctx.close(); } }

  // ===== 18. The bird (stage 2; Part B: B8, B9, B12, B13, B16 and §11a). Expected states are worked out here from the display file.
  if (want(18)) { reset(); const T = JOUR[BIRD], D = T.d, J = T.j, n = D.t.length, RULE = T.m.gap_rule.max_join_seconds, P = D.withheld, R0 = J.record_first_s, R1 = J.record_last_s;
    const nextFix = s => { for (let i = 0; i < n; i++) if (D.t[i] > s) return D.t[i]; return Infinity; };
    const H = P.map(p => ({ from: p[0], to: nextFix(p[1]), p })), hidAt = s => H.find(h => s >= h.from && s < h.to) || null;
    const at = (page, times) => page.evaluate(ts => ts.map(x => { ME.journey.seek(x); const s = ME.journey.state(); return { t: x, rt: s.rt, i: s.i, hidden: s.hidden, bar: s.bar, mv: s.objects.markerVisible, fx: s.objects.fixesShown, ln: s.objects.lineShown, range: +document.getElementById('replay-range').value, text: document.getElementById('replay').textContent }; }), times);
    const { ctx, page, errs } = await open(browser); S.log = []; await page.focus(tgl(BIRD)); await page.keyboard.press('Space'); await settle(page, BIRD); await page.waitForTimeout(300); let s = await state(page);
    ok('18a the bird opens at the start of the recording, inside the first withheld period: no marker, no accuracy, nothing drawn yet; the bar and the announcement say fixes are withheld; three objects on the globe; its own files requested once',
      s.rt === R0 && s.hidden === true && s.objects.markerVisible === false && s.objects.fixesShown === 0 && s.objects.lineShown === 0 && s.scene === 3 && s.playing === false && !/accuracy/i.test(s.bar) && !/displayed fix 2/.test(s.bar.split(' · ')[1]) &&
      s.bar === `Replay time (recorded) ${utc(R0)} · Fixes near the tagging site are withheld: 86 fixes between 23 Jun 2008 17:58:44 UTC and 29 Jun 2008 00:01:14 UTC, within 5 km of the tagging-site reference point, are not shown. No marker is shown · Next displayed fix 29 Jun 2008 01:30:54 UTC` &&
      s.say === 'Waved albatross shown. Replay is at the start of the recording. The first fixes are withheld, so no marker is shown yet.' && s.note.startsWith('Replay: recorded 23 Jun 2008 to 15 Sep 2008.') && S.log.filter(x => x === T.j.file).length === 1, { bar: s.bar, say: s.say, obj: s.objects, rt: s.rt });
    ok('18b the row carries the manifest\'s sentences and the tag\'s accuracy statement; the switch\'s line is the accepted label, as the manifest has it', s.switches[BIRD].obs.includes(T.m.card.shown) && s.switches[BIRD].obs.includes(T.m.card.accuracy) && s.switches[BIRD].obs.includes(T.m.card.done) &&
      (await page.evaluate(id => document.querySelector(`.an-sw[data-journey="${id}"] [data-f="sw-label"]`).textContent, BIRD)) === T.m.label_line && T.m.label_line === 'Recorded movements of one breeding adult, 23 June to 15 September 2008.', s.switches[BIRD].obs.slice(0, 160));
    // every withheld period: at its start, just before the next displayed fix, exactly at it, and just before the period
    const times = []; for (const h of H) { times.push(h.from, h.p[1], h.to - 1); if (h.to !== Infinity) times.push(h.to); if (h.from - 1 >= R0) times.push(h.from - 1); }
    let r = await at(page, times), bad = [];
    for (const x of r) { const h = hidAt(x.t), i = lastAt(D.t, x.t);
      const want = h ? { hidden: true, mv: false, acc: false } : { hidden: false, mv: i >= 0, acc: i >= 0 };
      const acc = / · Tag's accuracy estimate ([\d.]+) m/.exec(x.bar);
      if (x.hidden !== want.hidden || x.mv !== want.mv || !!acc !== want.acc || (acc && +acc[1] !== D.acc[i]) || x.i !== i || x.fx !== i + 1 || x.ln !== joinsTo(D, RULE, i) || (h && (!x.bar.includes(`${h.p[2]} fixes between ${utc(h.p[0])} and ${utc(h.p[1])}`) || /Last displayed fix|tried/.test(x.bar))) || (!h && /withheld/.test(x.bar))) bad.push([x.t, x.hidden, x.mv, x.bar.slice(0, 200)]); }
    ok(`18c all ${H.length} withheld periods, at ${r.length} times: hidden from the first withheld time (inclusive) to the next displayed fix (exclusive); the marker and its accuracy are absent throughout and return exactly at that fix; track drawn before the period stays; no line into or out of it`, bad.length === 0 && r.length >= 4 * H.length, bad.slice(0, 3));
    // the failed attempt that lies inside a hidden span (after a period's last withheld fix, before the next displayed fix)
    const fin = D.failed_t.filter(f => hidAt(f)); r = await at(page, fin.concat(fin.map(f => f + 1)));
    ok('18d the one failed attempt inside a hidden span: withholding takes precedence; no "tried" wording, no marker, no accuracy', fin.length === 1 && r.every(x => x.hidden && !x.mv && !/tried|accuracy/i.test(x.bar) && /are withheld/.test(x.bar)), r.map(x => x.bar.slice(0, 160)));
    // a failed attempt in a visible joined step: said only once replay time reaches it
    const fv = D.failed_t.filter(f => !hidAt(f)), f0 = fv[0], i0 = lastAt(D.t, f0); r = await at(page, [f0 - 1, f0, f0 + 60, D.t[i0 + 1]]);
    ok('18e a failed attempt in a displayed, joined step: nothing before it; from the attempt on, "The tag tried for a position at … and got none", with the marker still on the earlier fix, named as the last displayed fix with its accuracy; gone at the next fix',
      fv.length === 10 && D.j[i0 + 1] === 1 && !/tried/.test(r[0].bar) && r[1].bar.includes(`The tag tried for a position at ${utc(f0)} and got none`) && r[2].bar.includes(`The tag tried for a position at ${utc(f0)} and got none`) && r[1].i === i0 && r[1].mv && r[1].bar.includes(`Last displayed fix ${utc(D.t[i0])}`) && r[1].bar.includes(`Tag's accuracy estimate ${D.acc[i0]} m`) && !/tried/.test(r[3].bar) && r[3].i === i0 + 1, r.map(x => x.bar));
    // the long step with no row of any kind in the source
    const longs = []; for (let i = 0; i < n - 1; i++) if (D.t[i + 1] - D.t[i] > RULE && !H.some(h => h.from > D.t[i] && h.from < D.t[i + 1])) longs.push(i);
    r = await at(page, longs.map(i => D.t[i] + 60));
    ok('18f the 9-hour step: "No position and no attempt is in the source for 9 h 0 min 14 s after it"; the marker stays on the earlier fix; the step is not drawn', longs.length === 1 && D.t[longs[0] + 1] - D.t[longs[0]] === 32414 && r[0].bar.includes('No position and no attempt is in the source for 9 h 0 min 14 s after it') && r[0].mv && r[0].i === longs[0] && D.j[longs[0] + 1] === 0, r.map(x => x.bar));
    // every stop of the slider, and one second after each: the three wordings each in their own state only; never the older journeys' wording
    const stops = [...new Set([R0, ...D.t, ...P.map(p => p[0]), R1])].sort((a, b) => a - b), sweep = stops.concat(stops.filter(x => x < R1).map(x => x + 1), D.failed_t, D.failed_t.map(x => x + 1)); r = await at(page, sweep); bad = []; let nHid = 0, nTried = 0, nLong = 0;
    for (const x of r) { const h = hidAt(x.t), i = lastAt(D.t, x.t), next = i < n - 1 ? D.t[i + 1] : Infinity, tried = !h && D.failed_t.some(f => f > D.t[i] && f < next && f <= x.t), long = !h && i >= 0 && i < n - 1 && next - D.t[i] > RULE && !H.some(q => q.from > D.t[i] && q.from < next);
      nHid += h ? 1 : 0; nTried += tried ? 1 : 0; nLong += long ? 1 : 0;
      if (/was recorded|No fix is displayed|tracking record|recorded fix\b/i.test(x.bar.replace('Replay time (recorded)', '')) || /are withheld/.test(x.bar) !== !!h || /tried for a position/.test(x.bar) !== tried || /is in the source for/.test(x.bar) !== long || x.mv !== (!h && i >= 0) || x.hidden !== !!h || x.fx !== i + 1 || x.ln !== joinsTo(D, RULE, i) ||
        /migrat|foraging trip|incubat|at the colony|at the nest/i.test(x.text)) bad.push([x.t, x.bar.slice(0, 220)]); }
    ok(`18g B12 at all ${stops.length} slider stops, every listed failed attempt, and one second after each (${r.length} times): withheld, failed-attempt and long-gap wording each appear only in their own state (${nHid}, ${nTried}, ${nLong} times); "No fix was recorded" and the older wordings never appear; marker, fix marks and line are as the file says; none of the not-said words is on the bar`, bad.length === 0 && nHid >= 2 * P.length && nTried === 20 && nLong === 2, bad.slice(0, 3));
    // B9: hidden after a seek, a speed change and a pause
    const mid = P[0][0] + 86400; await page.evaluate(x => { ME.journey.seek(x); ME.journey.setSpeed(3600); ME.journey.play(); }, mid); await page.waitForTimeout(500); const playing = await state(page);
    await page.evaluate(() => ME.journey.pause()); const paused = await state(page), barText = await page.evaluate(() => document.getElementById('replay').textContent + document.getElementById('an-status').textContent);
    ok('18h B9 inside a withheld period after a seek, a speed change, while playing and after a pause: no marker and no accuracy text anywhere on the bar', playing.playing === true && playing.hidden && !playing.objects.markerVisible && paused.playing === false && paused.hidden && !paused.objects.markerVisible && paused.rt > mid && !/accuracy estimate/i.test(barText), [playing.bar, paused.bar]);
    // the slider
    await page.evaluate(x => ME.journey.seek(x), D.t[0]); await page.focus('#replay-range'); await page.keyboard.press('Home'); const k0 = await state(page); await page.keyboard.press('ArrowRight'); const k1 = await state(page);
    const iB = lastAt(D.t, P[1][0]); await page.evaluate(x => ME.journey.seek(x), D.t[iB]); await page.keyboard.press('ArrowRight'); const k2 = await state(page); await page.keyboard.press('ArrowRight'); const k3 = await state(page); await page.keyboard.press('End'); const k4 = await state(page);
    const rng = await page.evaluate(() => { const r = document.getElementById('replay-range'); return [r.max, document.querySelector('label[for="replay-range"]').textContent, r.getAttribute('aria-valuetext')]; });
    ok('18i the slider\'s stops are the displayed fixes and the start of each withheld period: Home is the start of the recording (withheld); the next stop is the first displayed fix; from the fix before a period the next stop is the period\'s start (withheld), then the next displayed fix; End is the end of the recording',
      k0.rt === R0 && k0.hidden && k1.rt === D.t[0] && !k1.hidden && k1.i === 0 && k2.rt === P[1][0] && k2.hidden && k3.rt === H[1].to && !k3.hidden && k4.rt === R1 && +rng[0] === stops.length - 1 && stops.length === n + P.length && /start of each withheld period/.test(rng[1]) && rng[2] === k4.bar, [k0.rt, k1.rt, k2.rt, k3.rt, k4.rt, rng[0], stops.length]);
    ok('18j at the last displayed fix, which is also the last source row, the bar says the displayed record ends here, with that fix\'s accuracy', k4.i === n - 1 && k4.bar === `Replay time (recorded) ${utc(R1)} · Last displayed fix: displayed record ends here, ${utc(D.t[n - 1])} · Tag's accuracy estimate ${D.acc[n - 1]} m`, k4.bar);
    // play to the end, and again
    await page.evaluate(x => { ME.journey.setSpeed(604800 * 8); ME.journey.seek(x); }, R1 - 86400 * 2); await page.click('#replay-play'); await page.waitForFunction(() => !ME.journey.state().playing, null, { timeout: 30000 }); const e1 = await state(page);
    await page.click('#replay-play'); await page.waitForTimeout(60); await page.evaluate(() => ME.journey.pause()); const e2 = await state(page);
    ok('18k Play runs to the end of the recording and stops; Play again starts from the start of the recording', e1.rt === R1 && e1.i === n - 1 && e1.play === 'Play' && e2.rt >= R0 && e2.rt < D.t[0] + 86400 * 30, [e1.rt, e2.rt]);
    // B16: the view holds the displayed journey
    const inView = async pg => pg.evaluate(([la, lo]) => { ME.journey.goArea(); const g = ME.animalsGlobe.raw(), cv = document.querySelector('#an-globe canvas').getBoundingClientRect(); let out = 0;
      for (let i = 0; i < la.length; i += 5) { const c = g.getScreenCoords(la[i], lo[i], 0.004); if (!(c.x >= 0 && c.x <= cv.width && c.y >= 0 && c.y <= cv.height)) out++; } return [out, Math.round(cv.width), Math.round(cv.height)]; }, [D.lat, D.lon]);
    const v1 = await inView(page);
    ok('18l B16 desktop: "Journey area" puts every sampled displayed fix inside the globe\'s box', v1[0] === 0, v1);
    ok('18l2 the card under the globe: the label, the counts and the withholding statement come from the manifest; the recording period and the displayed fixes are stated apart; no land-map row',
      await page.evaluate(([id, m]) => { const c = document.getElementById(id), f = k => c.querySelector(`[data-f="${k}"]`).textContent; return c.querySelector('h4').textContent === m.label && f('shown') === m.label_line + ' ' + m.card.shown && f('notdrawn') === m.card.done + ' ' + m.withholding.statement && /^Recording: 23 Jun 2008 17:58:44 UTC to 15 Sep 2008 13:30:18 UTC; the replay covers all of it\. First displayed fix 29 Jun 2008 01:30:54 UTC\. Last displayed fix 15 Sep 2008 13:30:18 UTC\.$/.test(f('period')) && f('unc').startsWith(m.accuracy_note) && f('place').includes('Punta Cevallos') && f('place').includes('Nest stage: egg') && c.querySelector('[data-f="land"]').closest('tr').hidden && !/migrat|foraging trip|incubat|at the colony|at the nest/i.test(c.textContent) && /nine were used in the paper's analysis/.test(c.textContent); }, [BIRD, T.m]));
    // back to an older journey: nothing of the bird's wording or frame is left
    await page.click(tgl(Z)); await settle(page, Z); const z = await state(page), zr = await page.evaluate(() => [document.getElementById('replay-range').max, document.querySelector('label[for="replay-range"]').textContent]);
    ok('18n after the bird, the zebra is as before: its own stops (one per fix), its own label on the slider, no accuracy or withheld wording, no hidden state', +zr[0] === JOUR[Z].d.t.length - 1 && zr[1] === 'Recorded fix (arrow keys step from fix to fix)' && z.hidden === false && !/accuracy|withheld/.test(z.bar) && z.bar.includes('First recorded fix') && z.scene === 3 && z.n === JOUR[Z].d.t.length, [zr, z.bar]);
    ok('18o no page error', errs.length === 0, errs); await ctx.close();
    { reset(); const o = await open(browser, { width: 390, height: 740 }); await o.page.evaluate(i => document.getElementById('tgl-' + i).scrollIntoView({ block: 'center' }), BIRD); await o.page.click(tgl(BIRD)); await settle(o.page, BIRD); await o.page.waitForTimeout(300); const v = await inView(o.page), s2 = await state(o.page);
      ok('18p B16 at 390 px: every sampled displayed fix is inside the globe\'s box; the press brought the globe into view although no marker is shown', v[0] === 0 && s2.box.top >= 0 && s2.box.top <= 12 && s2.box.bottom <= s2.vh && s2.hidden === true && s2.scroll && s2.scroll.n === 1, [v, s2.box]); await o.ctx.close(); }
    // B8: a trailing withheld period (fixture: the last three displayed fixes become a withheld period)
    { reset(); S.fx = fixture(BIRD, (d, m, jr) => { const k = d.n - 3, a = d.t[k], b = d.t[d.n - 1]; for (const f of ['t', 'lat', 'lon', 'acc', 'j']) d[f] = d[f].slice(0, k); d.n = k; d.withheld.push([a, b, 3]);
        const keep = d.failed_t.filter(x => x < a || x > b); d.failed_t = keep; jr.failed_listed = keep.length; jr.fixes = k; jr.last_fix_s = d.t[k - 1]; jr.fixes_withheld += 3; jr.withheld_periods += 1; jr.steps_joined = d.j.reduce((x, y) => x + y, 0); });
      const o = await open(browser), fd = S.fx.d, last = fd.withheld[fd.withheld.length - 1]; await on(o.page, BIRD);
      const rr = await at(o.page, [last[0] - 1, last[0], last[1], R1 - 1, R1]); await o.page.focus('#replay-range'); await o.page.keyboard.press('End'); const kEnd = await state(o.page);
      await o.page.evaluate(x => { ME.journey.setSpeed(604800 * 8); ME.journey.seek(x); }, fd.t[fd.n - 1] - 86400); await o.page.click('#replay-play'); await o.page.waitForFunction(() => !ME.journey.state().playing, null, { timeout: 30000 }); const pEnd = await state(o.page);
      ok('18m B8 a trailing withheld period (fixture): the hidden state runs through the end of the recording, inclusive; the slider\'s End and Play both reach that end; no marker and no accuracy there; the bar says the recording ends in the period',
        !rr[0].hidden && rr[0].mv && rr.slice(1).every(x => x.hidden && !x.mv && !/accuracy/.test(x.bar) && /The recording ends in this withheld period/.test(x.bar)) && kEnd.rt === R1 && kEnd.hidden && pEnd.rt === R1 && pEnd.hidden && !pEnd.objects.markerVisible && pEnd.objects.fixesShown === fd.n, [rr.map(x => [x.hidden, x.mv]), kEnd.rt, pEnd.rt, R1]); await o.ctx.close(); } }

  // ===== 19. The bird's file is verified before anything is drawn (B11, B14, §11a structure checks). Fixtures are re-pinned (harness).
  if (want(19)) { const UNV = 'Journey file could not be verified. Nothing is drawn.';
    const refused = async (id, mutate, re) => { reset(); S.fx = fixture(id, mutate); const o = await open(browser); await o.page.click(tgl(id)); await done(o.page); const s = await state(o.page); await o.ctx.close();
      return { ok: s.scene === 0 && checked(s).length === 0 && s.switches[id].obs === UNV && s.err[id] && re.test(s.err[id].detail), detail: s.err[id] && s.err[id].detail, scene: s.scene }; };
    const loads = async (id, mutate) => { reset(); S.fx = fixture(id, mutate); const o = await open(browser); await o.page.click(tgl(id)); await done(o.page); const s = await state(o.page); await o.ctx.close(); return s.scene === 3 && s.status === 'ready'; };
    let res = []; for (const f of ['acc', 'j', 'withheld', 'failed_t']) res.push([f, await refused(BIRD, d => { delete d[f]; }, new RegExp(`lacks "${f}"`))]);
    ok('19a §11a the bird requires its new fields: a display file without acc, j, withheld or failed_t is refused, never read as an older journey', res.every(x => x[1].ok), res.filter(x => !x[1].ok));
    res = [['short', d => { d.acc = d.acc.slice(1); }], ['negative', d => { d.acc[7] = -1; }], ['text', d => { d.acc[7] = '4.2'; }], ['null', d => { d.acc[7] = null; }]]; const rb = []; for (const [nm, mu] of res) rb.push([nm, await refused(BIRD, mu, /accuracy estimates/)]);
    ok('19b B11 accuracy: a wrong length, a negative, a non-number and a missing entry are each refused', rb.every(x => x[1].ok), rb.filter(x => !x[1].ok));
    const D = JOUR[BIRD].d, kP = (() => { for (let i = 1; i < D.n; i++) if (D.withheld.some(p => p[0] > D.t[i - 1] && p[0] < D.t[i])) return i; })();
    // a step that IS within the time rule and is flagged joined, with a withheld period placed between its two fixes
    const kJ = (() => { for (let i = 5; i < D.n; i++) if (D.j[i] === 1 && D.t[i] - D.t[i - 1] > 100 && !D.failed_t.some(f => f > D.t[i - 1] && f < D.t[i])) return i; })();
    const c1 = await refused(BIRD, (d, m, jr) => { d.withheld.push([d.t[kJ - 1] + 10, d.t[kJ - 1] + 20, 2]); d.withheld.sort((x, y) => x[0] - y[0]); jr.fixes_withheld += 2; jr.withheld_periods += 1; }, /joined across a withheld period/);
    const c1b = await refused(BIRD, (d, m, jr) => { d.j[kP] = 1; jr.steps_joined += 1; }, /further apart than the rule/);
    const c2 = await refused(BIRD, (d, m, jr) => { const i = d.j.indexOf(1); d.j[i] = 0; }, /number of joined steps/);
    const c3 = await refused(BIRD, d => { d.j[0] = 1; }, /join flags are missing or malformed/);
    ok('19c join flags: a join across a withheld period although the two fixes are within the time rule; a join over the time rule; a count that differs from the manifest; and a malformed array are each refused', c1.ok && c1b.ok && c2.ok && c3.ok, [c1, c1b, c2, c3]);
    const w = [['a displayed fix inside a period', (d) => { d.withheld[1][1] = d.t[kP]; }, /inside a withheld period/], ['periods out of order', d => { const x = d.withheld[2]; d.withheld[2] = d.withheld[3]; d.withheld[3] = x; }, /out of order, overlap/],
      ['a count that differs', d => { d.withheld[1][2] += 1; }, /withheld counts do not match/], ['a period before the recording', d => { d.withheld[0][0] -= 10; }, /out of order, overlap or lie outside/], ['a coordinate smuggled into a period', d => { d.withheld[1].push(-1.39); }, /withheld period is malformed/],
      ['a non-integer time', d => { d.withheld[1][0] += 0.5; }, /withheld period is malformed/]]; const rw = []; for (const [nm, mu, re] of w) rw.push([nm, await refused(BIRD, mu, re)]);
    ok('19d withheld periods: a displayed fix inside one, periods out of order, a wrong count, a period outside the recording, an extra value in a period and a non-integer time are each refused', rw.every(x => x[1].ok), rw.filter(x => !x[1].ok));
    const fl = [['at a fix', d => { d.failed_t[0] = d.t[lastAt(d.t, d.failed_t[0])]; }], ['inside a period', d => { d.failed_t[0] = d.withheld[0][0] + 5; }], ['not increasing', d => { d.failed_t[1] = d.failed_t[0]; }], ['one missing', d => { d.failed_t.pop(); }], ['outside the recording', d => { d.failed_t[d.failed_t.length - 1] = 2e9; }]]; const rf = [];
    for (const [nm, mu] of fl) rf.push([nm, await refused(BIRD, mu, /failed-attempt time/)]);
    ok('19e failed attempts: a time at a fix, inside a stored period, out of order, missing, or outside the recording is each refused', rf.every(x => x[1].ok), rf.filter(x => !x[1].ok));
    const m1 = await refused(BIRD, (d, m, jr) => { delete jr.record_first_s; }, /recording period in the manifest/), m2 = await refused(BIRD, (d, m, jr) => { jr.record_last_s = d.t[d.n - 1] - 1; }, /recording period in the manifest/);
    ok('19f a manifest without a usable recording period is refused', m1.ok && m2.ok, [m1, m2]);
    // the older journeys verify exactly as before
    const a1 = await refused(SH, d => { delete d.lc; }, /quality classes/), a2 = await refused(SH, d => { delete d.j; }, /join flags are missing/), a3 = await refused(Z, d => { d.j = d.t.map(() => 0); }, /quality classes/), a4 = await refused(W, d => { d.lc = d.lc.slice(1); }, /quality classes/);
    ok('19g the older journeys verify as before: an Argos file without its classes or its join flags is refused; an older-schema file that gains join flags without classes is refused', a1.ok && a2.ok && a3.ok && a4.ok, [a1, a2, a3, a4]);
    ok('19h an unchanged copy of each file, re-pinned the same way, still loads (the harness is not what refuses)', (await loads(BIRD, () => { })) && (await loads(SH, () => { })) && (await loads(Z, () => { })));
    // B14 for the bird: a changed display file and a changed manifest (real pins)
    reset(); { const o = await open(browser); const bad = Buffer.from(real(JOUR[BIRD].j.file)); bad[bad.length - 40] = bad[bad.length - 40] === 0x31 ? 0x32 : 0x31; S.over[JOUR[BIRD].j.file] = { body: bad }; await o.page.click(tgl(BIRD)); await done(o.page); let s = await state(o.page); const e1 = s.scene === 0 && s.switches[BIRD].obs === UNV && /display file does not match/.test(s.err[BIRD].detail);
      delete S.over[JOUR[BIRD].j.file]; S.over[JOUR[BIRD].e.manifest] = { body: Buffer.from(JSON.stringify({ ...JOUR[BIRD].m, label: 'x' })) }; S.log = []; await o.page.click(`.an-sw[data-journey="${BIRD}"] [data-f="sw-retry"]`); await done(o.page); s = await state(o.page);
      ok('19i B14 the bird\'s display file with one digit changed, and its manifest changed, are each refused with nothing drawn; with a bad manifest the display file is never requested', e1 && s.scene === 0 && /manifest does not match/.test(s.err[BIRD].detail) && !S.log.includes(JOUR[BIRD].j.file), [e1, s.err]); await o.ctx.close(); } }
  } catch (e) { fail++; console.log('FAIL  suite error: ' + (e && e.stack || e).toString().slice(0, 900)); }
  await browser.close(); srv.close(); clearTimeout(wd);
  if (BREAK) { const hit = failed.some(n => n.startsWith(EXPECT[BREAK])); console.log(hit ? `BREAK CAUGHT  ${BREAK} (at "${EXPECT[BREAK]}"; ${fail} checks failed)` : `BREAK MISSED  ${BREAK}: expected a failure at "${EXPECT[BREAK]}"; failed: ${failed.slice(0, 6).join(' | ') || 'none'}`); process.exit(hit ? 0 : 1); }
  console.log(`\nanimals-tab-ui: ${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
})();
