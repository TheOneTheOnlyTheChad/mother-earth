#!/bin/bash
# LEND readout-rounding candidate validation runner (from the LEND RC runner). Every exit code is captured into rc immediately after its command
# (the preview runner read $? after a $(date) substitution on the same line, so it always logged exit=0).
W=${W:-/tmp/wt-rd}; V=${V:-/tmp/val-rd}; cd "$W" || exit 9
export NODE_PATH=/home/claude/node_modules:/home/claude/spike/node_modules
now() { TZ=UTC date +%H:%M:%S; }
log() { echo "$(now) $*" >> "$V/summary.txt"; }
step() { local name=$1; shift; "$@" > "$V/$name.log" 2>&1; local rc=$?; log "$name exit=$rc | $(grep -E 'passed|failed|OK|match|CAUGHT|MISSED' "$V/$name.log" | tail -1 | cut -c1-160)"; }

for b in le-moon-key-old le-moon-legend-edited le-sources-edited cr-moon-panel-edited moon-page-edited; do BREAK=$b step animals-brk-$b node phase1/animals-tab-ui.test.cjs; done
for s in moon-globe moon-lit moon-lro-path moon-diviner-ui moon-lroc-ui moon-crater-ui skycraft-ui sky-moon-texture-ui sun-globe; do step $s node phase1/$s.test.cjs; done
step moon-light node phase1/moon-light.test.mjs
LOLA_SRC=/home/claude/lolasrc step moon-height-ui node phase1/moon-height-ui.test.cjs
for s in timeline-ui tides-nav backdrop-layer dustrgb-ui nature-context-ui quakes-ships-status-ui ships-retain-ui soil-ui fire-status-ui freshness-wording-ui optional-layers-status-ui night-lights-ui timeline-mixed-assets kept-ui ux-round1 osmc-reliability-ui tides-ui smoke-fixes; do step $s node phase1/$s.test.cjs; done
step timeline-changes-build node phase1/timeline-changes-build.test.mjs
log ALLDONE
